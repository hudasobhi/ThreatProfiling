#!/usr/bin/env python3
"""Top-level training entry point.

Equivalent to ``scripts/04_train.py``; provided because the reproducibility
specification lists ``train.py`` at the repository root.

    python train.py --config configs/default.yaml
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> int:
    args = sys.argv[1:]
    # Friendly alias documented in README; the underlying script accepts the
    # configured seed list or explicit integer seeds.
    if "--seeds" in args:
        i = args.index("--seeds")
        if i + 1 < len(args) and args[i + 1].lower() == "all":
            del args[i + 1]
    cmd = [sys.executable, str(ROOT / "scripts" / "04_train.py")] + args
    return subprocess.call(cmd)


if __name__ == "__main__":
    raise SystemExit(main())
