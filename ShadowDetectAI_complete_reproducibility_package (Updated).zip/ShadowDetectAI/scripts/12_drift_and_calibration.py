#!/usr/bin/env python3
"""Step 12 - drift robustness and adaptive calibration (Figures 9 and 10).

Figure 9 tracks detection accuracy across successive weekly windows while a
subset of test users undergo gradual, benign role changes.  Figure 10
compares the alert volume of a fixed threshold with the adaptive PSI-driven
threshold of Eq. (33) during a simulated organisational reorganisation.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch  # noqa: E402

from shadowdetectai.calibration.adaptive_threshold import AdaptiveThreshold  # noqa: E402
from shadowdetectai.calibration.psi_drift import PSIReference  # noqa: E402
from shadowdetectai.data.dataset import build_dataloader  # noqa: E402
from shadowdetectai.data.materialize import build_window_frame, channel_slices  # noqa: E402
from shadowdetectai.evaluation.drift_robustness import (  # noqa: E402
    adaptive_alert_volume, alert_volume_per_window, drift_curve)
from shadowdetectai.models.build import make_model  # noqa: E402
from shadowdetectai.training.checkpoints import load_checkpoint  # noqa: E402
from shadowdetectai.utils.config import get, load_config  # noqa: E402
from shadowdetectai.utils.io import write_csv_dicts  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--calibration-config", default=str(ROOT / "configs" / "calibration.yaml"))
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--checkpoints", default=str(ROOT / "results" / "raw_runs"))
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    cfg = load_config(args.config)
    cal = load_config(args.calibration_config)
    dims = cfg["encoder"]["channel_dims"]
    order = list(cfg["encoder"]["channel_order"])
    slices = channel_slices(dims, order)
    frame = build_window_frame(args.processed, args.config, "test")
    loader = build_dataloader(frame, slices, shuffle=False,
                              batch_size=int(get(cfg, "training.batch_size", 256)))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = make_model(cfg).to(device)
    ckpt = Path(args.checkpoints) / f"seed{args.seed}_best.pt"
    print(f"[..] checkpoint: {ckpt} "
          f"({'found' if ckpt.exists() else 'MISSING - run scripts/04_train.py'})")
    if ckpt.exists():
        load_checkpoint(ckpt, model)

    logits, labels, windows = [], [], []
    model.eval()
    with torch.no_grad():
        for batch in loader:
            batch = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}
            out = model(batch)
            logits.extend(out["logit"].detach().cpu().numpy().tolist())
            labels.extend(batch["label"].detach().cpu().numpy().astype(int).tolist())
            windows.extend(batch["window_index"].detach().cpu().numpy().tolist())

    curve = drift_curve(windows, labels, logits, method="ShadowDetectAI (proposed)")
    rows = [{"method": curve.method, "window": w, "accuracy": round(a, 4)}
            for w, a in zip(curve.windows, curve.accuracy)]
    write_csv_dicts(Path(args.out) / "figure09_drift_accuracy.csv", rows)
    print(f"[ok] drift curve over {len(curve.windows)} windows")

    base_tau = float(get(cal, "drift.base_threshold", 0.5))
    fixed = alert_volume_per_window(windows, logits, base_tau)
    adaptive = adaptive_alert_volume(
        windows, logits, logits, base_tau,
        lambda_drift=float(get(cal, "drift.lambda_drift", 0.1)),
        n_bins=int(get(cal, "drift.n_bins", 10)))
    arows = [{"window": w, "fixed_threshold_alerts": fixed[w],
              "adaptive_threshold_alerts": adaptive[w]}
             for w in sorted(fixed)]
    write_csv_dicts(Path(args.out) / "figure10_alert_volume.csv", arows)
    print(f"[ok] alert-volume comparison written")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
