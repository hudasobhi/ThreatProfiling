#!/usr/bin/env python3
"""Step 6 - train and evaluate the six comparison baselines (Table 8).

    python scripts/06_run_baselines.py --baselines graphch lan
"""
from __future__ import annotations

import argparse
import sys
from typing import Dict, List
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np  # noqa: E402
import torch  # noqa: E402

from shadowdetectai.data.dataset import build_dataloader  # noqa: E402
from shadowdetectai.data.materialize import build_window_frame, channel_slices  # noqa: E402
from shadowdetectai.evaluation.metrics import classification_metrics, mean_std  # noqa: E402
from shadowdetectai.models.build import make_model  # noqa: E402
from shadowdetectai.training.trainer import TrainConfig, Trainer  # noqa: E402
from shadowdetectai.utils.config import get, load_config  # noqa: E402
from shadowdetectai.utils.io import write_csv_dicts  # noqa: E402

ALL_BASELINES = ["graphch", "lan", "double_layer", "vggm", "exai", "gaspar_mlp"]

#: The method names the paper prints in Table 8.
DISPLAY_NAMES = {
    "graphch": "GraphCH",
    "lan": "LAN",
    "double_layer": "Double Layer Detection",
    "vggm": "VGGM",
    "exai": "EXAI",
    "gaspar_mlp": "Gaspar et al.",
}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--baselines", nargs="*", default=ALL_BASELINES)
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--seeds", type=int, nargs="*", default=None)
    args = ap.parse_args()

    rows: List[Dict[str, object]] = []
    per_seed_rows: List[Dict[str, object]] = []
    for name in args.baselines:
        cfg_path = ROOT / "configs" / "baselines" / f"{name}.yaml"
        cfg = load_config(cfg_path)
        seeds = args.seeds or list(get(cfg, "seeds.list", [42]))
        dims = cfg["encoder"]["channel_dims"]
        order = list(cfg["encoder"]["channel_order"])
        slices = channel_slices(dims, order)

        train_frame = build_window_frame(args.processed, cfg_path, "train")
        val_frame = build_window_frame(args.processed, cfg_path, "validation")
        test_frame = build_window_frame(args.processed, cfg_path, "test")

        train_loader = build_dataloader(train_frame, slices,
                                        batch_size=int(get(cfg, "training.batch_size", 256)))
        val_loader = build_dataloader(val_frame, slices, shuffle=False,
                                      batch_size=int(get(cfg, "training.batch_size", 256)))
        test_loader = build_dataloader(test_frame, slices, shuffle=False,
                                       batch_size=int(get(cfg, "training.batch_size", 256)))

        per_seed = []
        for seed in seeds:
            tcfg = TrainConfig.from_dict(get(cfg, "training", {}) or {})
            tcfg.seed = seed
            tcfg.output_dir = str(ROOT / "results" / "raw_runs" / name)
            model = make_model(cfg)
            trainer = Trainer(model, tcfg)
            trainer.fit(train_loader, val_loader)
            metrics = trainer.evaluate(test_loader)
            metrics["seed"] = seed
            per_seed.append(metrics)
            print(f"[ok] {name} seed {seed}: AUC {metrics['auc_roc']:.4f}")

        # One wide row per baseline, in the same column layout as Table 8,
        # so that evaluate_all.py can merge the rows into a single table.
        row: Dict[str, object] = {"method": DISPLAY_NAMES.get(name, name)}
        for key in ("auc_roc", "precision", "recall", "f1"):
            stats = mean_std([m[key] for m in per_seed])
            row[key] = round(stats["mean"], 4)
            row[f"{key}_std"] = round(stats["std"], 4)
        row["fidelity"] = ""
        rows.append(row)

        for m in per_seed:
            per_seed_rows.append({
                "seed": m.get("seed"),
                "method": DISPLAY_NAMES.get(name, name),
                "auc_roc": round(m["auc_roc"], 4),
                "precision": round(m["precision"], 4),
                "recall": round(m["recall"], 4),
                "f1": round(m["f1"], 4),
            })

    out = Path(args.out) / "table08_baselines.csv"
    write_csv_dicts(out, rows)
    write_csv_dicts(Path(args.out) / "table08_baseline_per_seed.csv", per_seed_rows)
    print(f"[ok] wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
