#!/usr/bin/env python3
"""Step 7 - exhaustive grid search for the six baselines (Table 7).

Hyper-parameters for each baseline are selected by exhaustive grid search over
the search spaces reported in the original publications, evaluated on the
**validation** partition AUC-ROC; the best-performing configuration is then
applied to the test partition without further modification (Section 6.3).
"""
from __future__ import annotations

import argparse
import itertools
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch  # noqa: E402

from shadowdetectai.data.dataset import build_dataloader  # noqa: E402
from shadowdetectai.data.materialize import build_window_frame, channel_slices  # noqa: E402
from shadowdetectai.models.build import make_model  # noqa: E402
from shadowdetectai.training.trainer import TrainConfig, Trainer  # noqa: E402
from shadowdetectai.utils.config import deep_merge, get, load_config  # noqa: E402
from shadowdetectai.utils.io import write_csv_dicts  # noqa: E402

ALL_BASELINES = ["graphch", "lan", "double_layer", "vggm", "exai", "gaspar_mlp"]


def grid_points(grid: dict):
    """Cartesian product of a grid dictionary."""
    keys = list(grid.keys())
    for values in itertools.product(*(grid[k] for k in keys)):
        yield dict(zip(keys, values))


def apply_grid(cfg: dict, point: dict) -> dict:
    """Overlay a grid point onto the config."""
    out = deep_merge(cfg, {"model": {k: v for k, v in point.items()
                                     if k in ("hidden_dim", "num_layers", "num_heads",
                                              "dropout", "latent_dim", "n_components")}})
    if "learning_rate" in point:
        out = deep_merge(out, {"training": {"learning_rate": point["learning_rate"]}})
    if "window_hours" in point:
        out = deep_merge(out, {"data": {"window_hours": point["window_hours"]}})
    return out


#: How each grid parameter is named in the paper's Table 7 selection column.
SELECTION_LABELS = {
    "learning_rate": "LR",
    "num_layers": "Layers",
    "hidden_dim": "Dim",
    "num_heads": "Heads",
    "window_hours": "Window",
    "dropout": "Dropout",
    "n_components": "Components",
    "latent_dim": "Latent dim",
}


def describe_selection(point: Dict[str, object]) -> str:
    """The paper's description of a selected configuration.

    Table 7 prints, for example, ``LR=0.0003; Layers=2; Dim=128``.
    """
    parts = []
    for key, label in SELECTION_LABELS.items():
        if key not in point:
            continue
        value = point[key]
        if key == "learning_rate":
            parts.append(f"{label}={value}")
        elif key == "window_hours":
            parts.append(f"{label}={value} h")
        else:
            parts.append(f"{label}={value}")
    return "; ".join(parts)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--baselines", nargs="*", default=ALL_BASELINES)
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    # The union of the six grids, which is the column layout of Table 7.
    GRID_COLUMNS = ["learning_rate", "num_layers", "hidden_dim", "num_heads",
                    "window_hours", "dropout", "n_components", "latent_dim"]
    rows: List[Dict[str, object]] = []
    trials: List[Dict[str, object]] = []
    selected_rows: List[Dict[str, object]] = []
    for name in args.baselines:
        cfg_path = ROOT / "configs" / "baselines" / f"{name}.yaml"
        cfg = load_config(cfg_path)
        grid = get(cfg, "grid", {}) or {}
        dims = cfg["encoder"]["channel_dims"]
        order = list(cfg["encoder"]["channel_order"])
        slices = channel_slices(dims, order)
        val_frame = build_window_frame(args.processed, cfg_path, "validation")
        val_loader = build_dataloader(val_frame, slices, shuffle=False,
                                      batch_size=int(get(cfg, "training.batch_size", 256)))

        best = (-1.0, None)
        for point in grid_points(grid):
            trial = apply_grid(cfg, point)
            tcfg = TrainConfig.from_dict(get(trial, "training", {}) or {})
            tcfg.seed = args.seed
            tcfg.output_dir = str(ROOT / "results" / "raw_runs" / "grid" / name)
            model = make_model(trial)
            trainer = Trainer(model, tcfg)
            trainer.fit(val_loader, val_loader, epochs=tcfg.epochs)
            auc = float(trainer.evaluate(val_loader).get("auc_roc", -1.0))
            trials.append({"baseline": name,
                           **{c: (point.get(c, "") if c in point else "")
                              for c in GRID_COLUMNS},
                           "val_auc_roc": round(auc, 4),
                           "selected": 0})
            print(f"[..] {name} {point} -> val AUC {auc:.4f}")
            if auc > best[0]:
                best = (auc, point)
        print(f"[ok] {name}: best {best[1]} (val AUC {best[0]:.4f})")

        # One row per baseline: the selected configuration, in the column
        # layout Table 7 prints.
        chosen = best[1] or {}
        for t in trials:
            if t["baseline"] == name:
                t["selected"] = 1
        selected_rows.append({
            "baseline": name,
            **{c: (chosen.get(c, "") if c in chosen else "") for c in GRID_COLUMNS},
            "selected": describe_selection(chosen),
            "val_auc_roc": round(best[0], 4),
        })

    out = Path(args.out) / "table07_baseline_grid_search.csv"
    write_csv_dicts(out, selected_rows)
    write_csv_dicts(Path(args.out) / "table07_grid_trials.csv", trials)
    print(f"[ok] wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
