#!/usr/bin/env python3
"""Step 11 - leave-one-insider-out cross-validation (Table 14).

Each of the five CERT r6.2 malicious insider identities is held out in turn
and the model retrained on the remaining four, giving the five-fold AUC-ROC
of 0.981 +/- 0.008 reported in the paper.
"""
from __future__ import annotations

import argparse
import sys
from typing import Dict, List
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np  # noqa: E402
import torch  # noqa: E402

from shadowdetectai.data.dataset import build_dataloader  # noqa: E402
from shadowdetectai.data.materialize import build_window_frame, channel_slices  # noqa: E402
from shadowdetectai.data.loio import build_loio_folds  # noqa: E402
from shadowdetectai.evaluation.metrics import classification_metrics, mean_std  # noqa: E402
from shadowdetectai.models.build import make_model  # noqa: E402
from shadowdetectai.training.trainer import TrainConfig, Trainer  # noqa: E402
from shadowdetectai.utils.config import get, load_config  # noqa: E402
from shadowdetectai.utils.io import write_csv_dicts, write_json  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--folds", type=int, default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    dims = cfg["encoder"]["channel_dims"]
    order = list(cfg["encoder"]["channel_order"])
    slices = channel_slices(dims, order)

    labels_path = Path(args.processed) / "labels.csv"
    if not labels_path.exists():
        print(f"[FAIL] {labels_path} missing. Run scripts/01_preprocess.py first.")
        return 1
    import pandas as pd
    labels = pd.read_csv(labels_path)
    folds = build_loio_folds(labels)
    write_json(Path(args.out) / "loio_folds.json", folds)
    if args.folds:
        folds = folds[: args.folds]

    rows = []
    for fold in folds:
        held_out = fold["held_out_identity"]
        train_frame = build_window_frame(args.processed, args.config, "train")
        test_frame = build_window_frame(args.processed, args.config, "test")
        # Restrict the test frame to the held-out identity.
        keep = [i for i, u in enumerate(test_frame.user) if u == held_out]
        if not keep:
            print(f"[warn] fold {fold['fold']}: no windows for {held_out}, skipping")
            continue
        mask = torch.zeros(len(test_frame.user), dtype=torch.bool)
        mask[keep] = True
        test_frame.labels = test_frame.labels[mask]
        test_frame.features = test_frame.features[mask]
        test_frame.node_features = test_frame.node_features[mask]
        test_frame.neighbour_features = test_frame.neighbour_features[mask]
        test_frame.neighbour_mask = test_frame.neighbour_mask[mask]
        test_frame.window_index = test_frame.window_index[mask]
        test_frame.user = [test_frame.user[i] for i in keep]

        train_loader = build_dataloader(train_frame, slices,
                                        batch_size=int(get(cfg, "training.batch_size", 256)))
        test_loader = build_dataloader(test_frame, slices, shuffle=False,
                                       batch_size=int(get(cfg, "training.batch_size", 256)))

        per_seed = []
        for seed in list(get(cfg, "seeds.list", [42])):
            tcfg = TrainConfig.from_dict(get(cfg, "training", {}) or {})
            tcfg.seed = seed
            tcfg.output_dir = str(ROOT / "results" / "raw_runs" / "loio" / held_out)
            model = make_model(cfg)
            trainer = Trainer(model, tcfg)
            trainer.fit(train_loader, None)
            m = trainer.evaluate(test_loader)
            m["seed"] = seed
            per_seed.append(m)

        # One wide row per fold, in the column layout Table 14 prints.
        row: Dict[str, object] = {"fold": fold["fold"],
                                  "held_out_identity": held_out}
        for key in ("auc_roc", "precision", "recall", "f1"):
            stats = mean_std([m[key] for m in per_seed])
            row[key] = round(stats["mean"], 4)
            row[f"{key}_std"] = round(stats["std"], 4)
        rows.append(row)
        print(f"[ok] fold {fold['fold']} ({held_out}) done")

    # The paper's Table 14 closes with a mean-and-standard-deviation row
    # across the five folds.
    if rows:
        mean_row: Dict[str, object] = {"fold": "Mean +/- Std",
                                       "held_out_identity": "-"}
        for key in ("auc_roc", "precision", "recall", "f1"):
            values = [float(r[key]) for r in rows]
            mean_row[key] = round(float(np.mean(values)), 4)
            mean_row[f"{key}_std"] = round(float(np.std(values, ddof=1)), 4)
        rows.append(mean_row)

    out = Path(args.out) / "table14_loio.csv"
    write_csv_dicts(out, rows)
    print(f"[ok] wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
