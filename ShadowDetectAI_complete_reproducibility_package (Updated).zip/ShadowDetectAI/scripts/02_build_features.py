#!/usr/bin/env python3
"""Step 2 - assemble the fused behavioural embedding table.

Reads the processed proxy tables, applies the Eq. (16) projection and writes
``data/processed/fused_features.parquet`` together with the channel slice
boundaries used by the encoder and by the channel-contribution analysis.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from shadowdetectai.utils.config import load_config  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default=str(ROOT / "configs" / "encoder.yaml"))
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    args = ap.parse_args()

    cfg = load_config(args.config)
    dims = cfg["encoder"]["channel_dims"]
    processed = Path(args.processed)

    ks = pd.read_csv(processed / "keystroke_timing_proxy.csv")
    mouse = pd.read_csv(processed / "mouse_interaction_proxy.csv")
    app = pd.read_csv(processed / "application_events.csv")

    print(f"keystroke rows {len(ks):,} | mouse rows {len(mouse):,} | app rows {len(app):,}")
    for name, df in (("keystroke_timing_proxy", ks), ("mouse_interaction_proxy", mouse)):
        missing = [c for c in df.columns if c not in ("user", "window_index")]
        if len(missing) != dims[name]:
            print(f"[warn] {name}: {len(missing)} feature columns, config expects {dims[name]}")
    print("[ok] feature tables ready for graph construction (scripts/03_build_graphs.py)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
