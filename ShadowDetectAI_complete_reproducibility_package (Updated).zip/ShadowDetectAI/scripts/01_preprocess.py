#!/usr/bin/env python3
"""Step 1 - build the processed feature tables and the partition manifest."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", default=str(ROOT / "data" / "raw" / "cert.r6.2"))
    args, rest = ap.parse_known_args()
    cmd = [sys.executable, str(ROOT / "data" / "preprocess.py"), "--input", args.input]
    return subprocess.call(cmd + rest)


if __name__ == "__main__":
    raise SystemExit(main())
