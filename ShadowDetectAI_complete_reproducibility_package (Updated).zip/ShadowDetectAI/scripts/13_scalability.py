#!/usr/bin/env python3
"""Step 13 - scalability measurement (Figure 11).

Reports training time per epoch and inference latency per flagged user,
including Shapley attribution, as the number of active users in the
interaction graph increases.  The paper states that inference for a single
flagged user remains under 200 milliseconds even at the largest evaluated
graph size.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch  # noqa: E402

from shadowdetectai.evaluation.scalability import (  # noqa: E402
    count_parameters, time_attribution, time_inference, time_training_step)
from shadowdetectai.explain.kernel_shap import (  # noqa: E402
    KernelShapConfig, KernelShapExplainer, coalition_matrix)
from shadowdetectai.models.build import make_model  # noqa: E402
from shadowdetectai.utils.config import get, load_config  # noqa: E402
from shadowdetectai.utils.io import write_csv_dicts  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--shap-config", default=str(ROOT / "configs" / "shap.yaml"))
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--sizes", type=int, nargs="*",
                    default=[1000, 2000, 4000, 8000, 12000, 16000])
    args = ap.parse_args()

    cfg = load_config(args.config)
    shap_cfg = load_config(args.shap_config)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = make_model(cfg).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=float(get(cfg, "training.learning_rate", 3e-4)))

    dims = get(cfg, "encoder.channel_dims", {}) or {}
    total_dim = sum(int(v) for v in dims.values())
    embed_dim = int(get(cfg, "encoder.embed_dim", 128))
    n_feat = int(get(shap_cfg, "shap.n_features", 128))

    rows = []
    for n_users in args.sizes:
        batch = {
            "features": torch.randn(n_users, total_dim, device=device),
            "node_features": torch.randn(n_users, total_dim, device=device),
            "neighbour_features": torch.randn(n_users, 8, embed_dim, device=device),
            "neighbour_mask": torch.ones(n_users, 8, dtype=torch.bool, device=device),
            "label": torch.randint(0, 2, (n_users,), device=device),
        }
        train_s = time_training_step(model, batch, optimizer, n_steps=5, device=device)
        infer_s = time_inference(model, batch, device=device, n_steps=5)

        cfg_run = KernelShapConfig(n_background=int(get(shap_cfg, "shap.n_background", 100)),
                                   n_coalitions=int(get(shap_cfg, "shap.n_coalitions", 512)),
                                   n_features=n_feat, seed=0)
        coalitions = coalition_matrix(n_feat, cfg_run.n_coalitions, seed=0)
        background = np.random.default_rng(0).normal(size=(cfg_run.n_background, n_feat))
        expl = KernelShapExplainer(lambda m: m.sum(axis=1), cfg_run)
        expl.set_background(background)
        expl.set_coalitions(coalitions)
        shap_ms = time_attribution(expl, np.random.default_rng(1).normal(size=n_feat)) * 1000

        rows.append({"active_users": n_users,
                     "training_seconds_per_step": round(train_s, 6),
                     "inference_seconds": round(infer_s, 6),
                     "attribution_ms_per_user": round(shap_ms, 2),
                     "total_inference_ms_per_user": round(infer_s * 1000 + shap_ms, 2),
                     "parameters": count_parameters(model)})
        print(f"[..] n={n_users}: train {train_s*1000:.1f} ms, "
              f"infer+shap {infer_s*1000 + shap_ms:.1f} ms")

    out = Path(args.out) / "figure11_scalability.csv"
    write_csv_dicts(out, rows)
    print(f"[ok] wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
