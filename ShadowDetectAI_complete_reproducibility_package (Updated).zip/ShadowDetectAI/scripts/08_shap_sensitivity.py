#!/usr/bin/env python3
"""Step 8 - KernelSHAP sensitivity analysis (Table 4).

Panel A fixes the coalition samples at 512 and sweeps the background samples
over {50, 100, 200, 500}; Panel B fixes the background samples at 100 and
sweeps the coalition samples over {128, 256, 512, 1024}.  The stabilisation
thresholds are a fidelity change below 0.003 and a top-3 recall change below
0.01 relative to the next larger configuration.

Values are mean +/- std across ten runs.

**The fidelity is the real thing.**  It is Eq. (30) computed against the
trained model's own logit, using the trained model as the KernelSHAP value
function and the benign training windows as the background distribution, as
Table 6 specifies.  The top-3 contribution recall needs the manual
behavioural-driver annotations, which are not redistributed; pass them with
``--annotations`` and the column is computed, otherwise it is reported as
missing rather than as a fabricated number.
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch  # noqa: E402

from shadowdetectai.data.dataset import build_dataloader  # noqa: E402
from shadowdetectai.data.materialize import build_window_frame, channel_slices  # noqa: E402
from shadowdetectai.explain.kernel_shap import (  # noqa: E402
    KernelShapConfig, KernelShapExplainer, coalition_matrix)
from shadowdetectai.explain.topk_recall import mean_topk_recall  # noqa: E402
from shadowdetectai.training.checkpoints import load_checkpoint  # noqa: E402
from shadowdetectai.utils.config import get, load_config  # noqa: E402
from shadowdetectai.utils.io import write_csv_dicts  # noqa: E402
from shadowdetectai.models.build import make_model  # noqa: E402


def load_annotations(path: Optional[str]) -> Dict[str, List[int]]:
    """Read the manual behavioural-driver annotations.

    The file is a CSV with the columns ``user`` and ``drivers``, where
    ``drivers`` is a semicolon-separated list of feature indices.
    """
    if not path or not Path(path).exists():
        return {}
    out: Dict[str, List[int]] = {}
    with open(path, "r", encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            drivers = [int(x) for x in str(row.get("drivers", "")).split(";")
                       if x.strip().isdigit()]
            out[str(row["user"])] = drivers
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--sensitivity-config", default=str(ROOT / "configs" / "shap.yaml"))
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--checkpoints", default=str(ROOT / "results" / "raw_runs"))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--annotations", default=None,
                    help="CSV of the manual behavioural-driver annotations "
                         "(user, drivers). Without it the top-3 recall is "
                         "reported as missing.")
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--runs", type=int, default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    sens_cfg = load_config(args.sensitivity_config)
    sens = sens_cfg.get("sensitivity", {}) or {}
    n_runs = args.runs or int(get(sens, "stabilisation.n_runs", 10))
    background_sizes = list(get(sens, "background_samples", [50, 100, 200, 500]))
    coalition_sizes = list(get(sens, "coalition_samples", [128, 256, 512, 1024]))

    dims = cfg["encoder"]["channel_dims"]
    order = list(cfg["encoder"]["channel_order"])
    slices = channel_slices(dims, order)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = make_model(cfg).to(device)
    ckpt = Path(args.checkpoints) / f"seed{args.seed}_best.pt"
    if ckpt.exists():
        load_checkpoint(ckpt, model)
    else:
        print(f"[warn] {ckpt} not found; the fidelity will be measured against "
              "an untrained model. Run scripts/04_train.py first.")

    train_frame = build_window_frame(args.processed, args.config, "train")
    test_frame = build_window_frame(args.processed, args.config, "test")
    train_labels = train_frame.labels.detach().cpu().numpy()
    benign = train_frame.features.detach().cpu().numpy()[train_labels == 0]
    if benign.shape[0] < max(background_sizes):
        print(f"[FAIL] only {benign.shape[0]} benign training windows; "
              f"{max(background_sizes)} are needed. Run scripts/01_preprocess.py first.")
        return 1

    test_labels = test_frame.labels.detach().cpu().numpy()
    test_features = test_frame.features.detach().cpu().numpy()
    test_users = list(test_frame.user)
    flagged = np.where(test_labels == 1)[0]
    if flagged.size == 0:
        print("[FAIL] the test partition has no malicious window")
        return 1

    annotations = load_annotations(args.annotations)
    if not annotations:
        print("[warn] no behavioural-driver annotations supplied; the top-3 "
              "contribution recall cannot be computed and is reported as missing.")

    def score_fn(m: np.ndarray) -> np.ndarray:
        """The model's own score for a batch of feature vectors."""
        with torch.no_grad():
            tensor = torch.as_tensor(m, dtype=torch.float32, device=device)
            node = tensor.unsqueeze(1)
            out = model({
                "features": tensor,
                "node_features": node,
                "neighbour_features": node,
                "neighbour_mask": torch.zeros((tensor.shape[0], 1), dtype=torch.bool,
                                              device=device),
                "label": torch.zeros(tensor.shape[0], dtype=torch.long, device=device),
                "window_index": torch.zeros(tensor.shape[0], dtype=torch.long,
                                            device=device),
            })
            return out["logit"].detach().cpu().numpy()

    def evaluate(n_bg: int, n_coal: int) -> Dict[str, float]:
        fidelities: List[float] = []
        recalls: List[float] = []
        latencies: List[float] = []
        for run in range(n_runs):
            config = KernelShapConfig(n_background=n_bg, n_coalitions=n_coal,
                                      n_features=test_features.shape[1], seed=run)
            coalitions = coalition_matrix(test_features.shape[1], n_coal, seed=run)
            t0 = time.perf_counter()
            run_fid: List[float] = []
            run_rank: List[List[int]] = []
            run_gt: List[List[int]] = []
            for idx in flagged:
                x = test_features[idx]
                explainer = KernelShapExplainer(score_fn, config)
                explainer.set_background(benign[:n_bg])
                explainer.set_coalitions(coalitions)
                phi, baseline = explainer.explain(x, return_baseline=True)
                logit = float(score_fn(x.reshape(1, -1))[0])
                denom = abs(logit)
                fid = 1.0 if denom < 1e-12 else float(
                    1.0 - abs(baseline + float(phi.sum()) - logit) / denom)
                run_fid.append(fid)
                run_rank.append(list(np.argsort(-np.abs(phi))))
                gt = annotations.get(str(test_users[idx]))
                if gt:
                    run_gt.append(gt)
            latencies.append((time.perf_counter() - t0) / max(len(flagged), 1) * 1000)
            fidelities.append(float(np.mean(run_fid)))
            if run_gt:
                recalls.append(mean_topk_recall(run_rank, run_gt, k=3))
        return {
            "attribution_fidelity": float(np.mean(fidelities)) if fidelities else float("nan"),
            "fidelity_std": float(np.std(fidelities, ddof=1)) if len(fidelities) > 1 else 0.0,
            "top3_recall": float(np.mean(recalls)) if recalls else float("nan"),
            "top3_recall_std": float(np.std(recalls, ddof=1)) if len(recalls) > 1 else 0.0,
            "latency_ms_per_user": float(np.mean(latencies)) if latencies else float("nan"),
            "latency_std": float(np.std(latencies, ddof=1)) if len(latencies) > 1 else 0.0,
        }

    rows: List[Dict[str, object]] = []
    for n_bg in background_sizes:
        r = evaluate(n_bg, 512)
        rows.append({"panel": "A", "background_samples": n_bg, "coalition_samples": 512,
                     **{k: ("" if isinstance(v, float) and np.isnan(v) else round(v, 4))
                        for k, v in r.items()}})
        print(f"[..] panel A bg={n_bg} -> fidelity {r['attribution_fidelity']:.3f}")

    for n_coal in coalition_sizes:
        r = evaluate(100, n_coal)
        rows.append({"panel": "B", "background_samples": 100, "coalition_samples": n_coal,
                     **{k: ("" if isinstance(v, float) and np.isnan(v) else round(v, 4))
                        for k, v in r.items()}})
        print(f"[..] panel B coal={n_coal} -> fidelity {r['attribution_fidelity']:.3f}")

    out = Path(args.out) / "table04_shap_sensitivity.csv"
    write_csv_dicts(out, rows)
    print(f"[ok] wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
