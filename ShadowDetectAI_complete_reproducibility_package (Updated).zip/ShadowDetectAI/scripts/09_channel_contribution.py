#!/usr/bin/env python3
"""Step 9 - behavioural channel contribution analysis (Table 10 and Figure 8).

Computes the pairwise Pearson correlations and normalised mutual information
between the three channel feature vectors on the training partition, and the
per-channel share of the Shapley attribution magnitude over the correctly
detected malicious users of the test partition.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from shadowdetectai.evaluation.channel_analysis import (  # noqa: E402
    channel_attribution_proportions, channel_attribution_sds,
    pairwise_normalized_mi, pairwise_pearson, pearson_ci)
from shadowdetectai.utils.io import write_csv_dicts  # noqa: E402

CHANNELS = ["keystroke_timing_proxy", "mouse_interaction_proxy",
            "application_sequencing"]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--attributions", default=None,
                    help="optional .npz of per-user attribution vectors")
    ap.add_argument("--partition", default="train",
                    help="the partition the correlations are computed on "
                         "(the paper says the training partition)")
    args = ap.parse_args()

    processed = Path(args.processed)
    ks = pd.read_csv(processed / "keystroke_timing_proxy.csv")
    mouse = pd.read_csv(processed / "mouse_interaction_proxy.csv")
    app = pd.read_csv(processed / "application_events.csv")

    key = ["user", "window_index"]
    merged = ks.merge(mouse, on=key, how="outer")
    if "partition" in merged.columns:
        merged = merged[merged["partition"] == args.partition]
        print(f"[..] correlations computed on the {args.partition} partition "
              f"({len(merged):,} rows)")
    vectors = {
        "keystroke_timing_proxy": merged[[c for c in ks.columns if c not in key]].to_numpy(dtype=float),
        "mouse_interaction_proxy": merged[[c for c in mouse.columns if c not in key]].to_numpy(dtype=float),
    }
    if "application_sequencing" in app.columns:
        vectors["application_sequencing"] = merged[["n_app_events"]].fillna(0).to_numpy(dtype=float)
    else:
        vectors["application_sequencing"] = np.zeros((len(merged), 1))

    pearson = pairwise_pearson(vectors)
    nmi = pairwise_normalized_mi(vectors)
    n_obs = len(merged)

    rows = []
    for (a, b), r in pearson.items():
        lo, hi = pearson_ci(r, n=n_obs)
        rows.append({"pair": f"{a} vs {b}", "pearson_mean": round(float(r), 4),
                     "pearson_ci_low": round(lo, 4), "pearson_ci_high": round(hi, 4),
                     "normalized_mi": ("" if not np.isfinite(nmi.get((a, b), np.nan))
                                       else round(float(nmi[(a, b)]), 4))})
        print(f"[..] {a} vs {b}: pearson {r:.3f} [{lo:.3f}, {hi:.3f}]")

    out = Path(args.out) / "table10a_channel_correlations.csv"
    write_csv_dicts(out, rows)

    if args.attributions and Path(args.attributions).exists():
        data = np.load(args.attributions)
        attrs = data["attributions"]
        slices = {"keystroke_timing_proxy": slice(0, 8),
                  "mouse_interaction_proxy": slice(8, 14),
                  "application_sequencing": slice(14, attrs.shape[1])}
        props = channel_attribution_proportions(list(attrs), slices)
        sds = channel_attribution_sds(list(attrs), slices)
        t10 = [{"channel": k,
                "mean_abs_shapley_proportion": round(v, 4),
                "sd_across_detected_malicious_users": round(sds.get(k, float("nan")), 4)}
               for k, v in props.items()]
        total = sum(v for v in props.values())
        if total > 0:
            t10.append({"channel": "Total",
                        "mean_abs_shapley_proportion": round(total, 4),
                        "sd_across_detected_malicious_users": ""})
        write_csv_dicts(Path(args.out) / "table10_channel_attribution.csv", t10)
        print(f"[ok] wrote Table 10 ({t10})")
    else:
        print("[warn] no attribution file supplied; Table 10 was not regenerated")

    print(f"[ok] wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
