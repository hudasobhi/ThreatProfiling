#!/usr/bin/env python3
"""Step 3 - build the dynamic interaction graphs for the three partitions."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from shadowdetectai.data.graph_builder import build_window_graph  # noqa: E402
from shadowdetectai.data.partition import (  # noqa: E402
    partition_manifest, split_windows)
from shadowdetectai.utils.io import ensure_dir, write_json  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--out", default=str(ROOT / "data" / "processed" / "graphs"))
    args = ap.parse_args()

    processed = Path(args.processed)
    app = pd.read_csv(processed / "application_events.csv")
    manifest = partition_manifest(app.assign(timestamp=pd.to_datetime(app["timestamp"])),
                                  window_hours=24)
    part = split_windows(app["window_index"], manifest, window_hours=24)
    app = app.assign(partition=part.values)

    out_dir = ensure_dir(Path(args.out))
    summary = []
    for name, grp in app.groupby("partition", sort=True):
        first_window = grp["window_index"].min()
        sub = grp[grp["window_index"] == first_window]
        graph = build_window_graph(sub)
        summary.append({"partition": name, "first_window": int(first_window),
                        "n_users": graph.n_users, "n_resources": graph.n_resources,
                        "n_edges": int(graph.edges.shape[0])})
        print(f"{name}: window {first_window} -> {graph.n_users} users, "
              f"{graph.n_resources} resources, {graph.edges.shape[0]} edges")
    write_json(out_dir / "graph_summary.json", summary)
    print(f"[ok] graph summary written to {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
