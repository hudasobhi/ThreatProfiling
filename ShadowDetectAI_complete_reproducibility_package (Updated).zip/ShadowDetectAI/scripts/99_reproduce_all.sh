#!/usr/bin/env bash
# Reproduce every table and figure of the paper, in order.
#
#   bash scripts/99_reproduce_all.sh                 # full run
#   bash scripts/99_reproduce_all.sh --skip-download # corpus already extracted
#
# Steps are numbered to match the paper: 01-02 data and features, 03 graphs,
# 04 training, 05-07 evaluation and baselines, 08-13 analysis and figures,
# 14-15 the triage study.
#
# Everything is written under results/reproduced/.  The paper's reported
# values live in results/tables/ and are never touched by this script -
# they are the targets the run is compared against.
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="${PWD}/src:${PYTHONPATH:-}"

REPRODUCED="${PWD}/results/reproduced"
mkdir -p "$REPRODUCED"

SKIP_DOWNLOAD=0
for arg in "$@"; do
  case "$arg" in
    --skip-download) SKIP_DOWNLOAD=1 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

run() { echo; echo "=== $* ==="; "$@"; }

if [[ "$SKIP_DOWNLOAD" -eq 0 ]]; then
  echo "=== 00 download CERT r6.2 ==="
  echo "The corpus requires manual acceptance on the KiltHub record:"
  echo "  https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247"
  echo "Place the archive at data/raw/cert.r6.2.zip, then re-run with --skip-download."
  exit 1
fi

run python3 scripts/01_preprocess.py --tables "$REPRODUCED"
run python3 scripts/02_build_features.py
run python3 scripts/03_build_graphs.py   # writes data/processed/graphs/
run python3 scripts/04_train.py --config configs/default.yaml
run python3 scripts/05_evaluate.py --config configs/default.yaml --out "$REPRODUCED"
run python3 scripts/06_run_baselines.py --out "$REPRODUCED"
run python3 scripts/07_grid_search_baselines.py --out "$REPRODUCED"
run python3 scripts/08_shap_sensitivity.py --out "$REPRODUCED"
run python3 scripts/09_channel_contribution.py --out "$REPRODUCED"
run python3 scripts/10_ablation.py --out "$REPRODUCED"
run python3 scripts/11_loio_cv.py --out "$REPRODUCED"
run python3 scripts/12_drift_and_calibration.py --out "$REPRODUCED"
run python3 scripts/13_scalability.py --out "$REPRODUCED"
run python3 scripts/14_triage_alert_pool.py --out "$REPRODUCED"
run python3 scripts/15_triage_analysis.py --out "$REPRODUCED"

# The figures are built from the regenerated tables, so a figure cannot
# drift away from the table it illustrates.
run python3 figures/make_figures.py

echo
echo "=== comparing reproduced values against the paper's reported values ==="
python3 compare_results.py --expected results/tables --reproduced "$REPRODUCED" \
  --tolerance 0.02 || true
echo
echo "All steps complete. See results/reproduced/ for the regenerated tables."
