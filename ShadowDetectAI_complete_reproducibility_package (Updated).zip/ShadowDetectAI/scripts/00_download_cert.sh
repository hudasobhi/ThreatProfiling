#!/usr/bin/env bash
# Fetch the CMU CERT r6.2 insider threat corpus.
#
# The KiltHub record requires acceptance of the dataset terms, so either pass
# the direct URL that the download button resolves to, or point at an archive
# you downloaded manually:
#
#     bash scripts/00_download_cert.sh --local /path/to/cert.r6.2.zip
set -euo pipefail
cd "$(dirname "$0")/.."
python3 data/download.py "$@"
