#!/usr/bin/env python3
"""Step 14 - build the 20-alert triage pool and the allocation schedule
(Tables 12 and the counterbalancing schedule).

The pool is exhaustive rather than sampled: it contains every confirmed
detection of the seed-42 test-partition run, supplemented with
validation-partition alerts until the composition of ten true-positive and ten
false-positive alerts is reached.  The practice block of five alerts is drawn
from the validation partition and excluded from the twenty timed alerts.
"""
from __future__ import annotations

import argparse
import sys
from typing import List
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from shadowdetectai.triage.alert_pool import (  # noqa: E402
    Alert, build_alert_pool, pool_composition, split_practice_block)
from shadowdetectai.triage.allocation import allocate, verify_allocation  # noqa: E402
from shadowdetectai.utils.io import write_csv_dicts, write_json  # noqa: E402


def load_alerts(path: Path) -> list:
    """Read alerts from a CSV with the triage-pool columns."""
    import csv

    out = []
    if not path.exists():
        return out
    with open(path, "r", encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            out.append(Alert(
                alert_id=row.get("alert_id", ""),
                partition=row.get("partition", ""),
                is_true_positive=bool(int(row.get("is_true_positive", 0))),
                user=row.get("user", ""),
                window_index=int(row.get("window_index", 0)),
                score=float(row.get("score", 0.0)),
                deviation_count=int(row.get("deviation_count", 0)),
                ground_truth_label=int(row.get("ground_truth_label", 0)),
            ))
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--test-alerts",
                    default=str(ROOT / "results" / "reproduced" / "triage_test_alerts.csv"),
                    help="the confirmed alerts of the seed-42 test run, written "
                         "by scripts/05_evaluate.py")
    ap.add_argument("--validation-alerts",
                    default=str(ROOT / "results" / "reproduced" / "triage_validation_alerts.csv"),
                    help="the candidate validation-partition alerts, written by "
                         "scripts/05_evaluate.py")
    ap.add_argument("--study", default=str(ROOT / "triage_study"),
                    help="where the alert pool, the counterbalancing schedule "
                         "and the allocation check are written")
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated Table 12 is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--participants", type=int, default=10)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    test_alerts = load_alerts(Path(args.test_alerts))
    val_alerts = load_alerts(Path(args.validation_alerts))
    if not test_alerts and not val_alerts:
        print("[FAIL] no alert CSVs found. Run scripts/05_evaluate.py first to "
              "export the confirmed detections.")
        return 1

    pool = build_alert_pool(test_alerts, val_alerts)
    practice = split_practice_block(pool)
    out = Path(args.study)
    write_csv_dicts(out / "alerts" / "alert_pool_20.csv",
                    [a.as_dict() for a in pool])
    write_csv_dicts(out / "alerts" / "practice_block_5.csv",
                    [a.as_dict() for a in practice])

    schedules = allocate(pool, n_participants=args.participants, seed=args.seed)
    write_csv_dicts(out / "protocol" / "counterbalancing_schedule.csv",
                    [s.as_dict() for s in schedules])

    check = verify_allocation(pool, schedules)
    write_json(out / "results" / "allocation_check.json", check)

    # Table 12: the design of the study, as the paper prints it.
    comp = pool_composition(pool)
    # Self-check of the two invariants the paper states for Table 12.
    n_attribution = sum(len(s.attribution_alerts) for s in schedules)
    n_no_attribution = sum(len(s.no_attribution_alerts) for s in schedules)
    n_first_attribution = sum(1 for s in schedules
                              if s.condition_order[0] == "attribution")
    n_participants = len(schedules)
    expected_attribution = comp["total"] * n_participants // 2
    problems: List[str] = []
    if n_attribution != expected_attribution:
        problems.append(f"{n_attribution} attribution trials, expected "
                        f"{expected_attribution}")
    if n_no_attribution != expected_attribution:
        problems.append(f"{n_no_attribution} no-attribution trials, expected "
                        f"{expected_attribution}")
    if n_first_attribution * 2 != n_participants:
        problems.append(f"the condition order is not counterbalanced "
                        f"({n_first_attribution}/{n_participants} start with "
                        f"the attribution condition)")
    if problems:
        for p in problems:
            print(f"[FAIL] {p}")
        return 1
    print(f"[ok] {n_attribution} attribution trials and {n_no_attribution} "
          f"no-attribution trials across {n_participants} participants; "
          f"the condition order is counterbalanced "
          f"{n_first_attribution}/{n_participants - n_first_attribution}")
    table12 = [
        {"design_element": "Distinct alerts in the pool",
         "value": f"{comp['total']}; ten true-positive detections and ten "
                  f"false-positive detections"},
        {"design_element": "Alerts presented per participant",
         "value": f"{comp['total']} in total; ten in the attribution condition "
                  f"and ten in the no-attribution condition"},
        {"design_element": "Timed trials per participant",
         "value": str(comp["total"])},
        {"design_element": "True-positive alerts",
         "value": "Ten; eight from the test partition (the eight confirmed true "
                  "positives of the seed-42 run reported in Table 9) and two "
                  "from the validation partition"},
        {"design_element": "False-positive alerts",
         "value": "Ten; one from the test partition (the single false positive "
                  "reported in Table 9) and nine from the validation partition"},
        {"design_element": "Composition within each condition",
         "value": "Five true-positive and five false-positive alerts, so the "
                  "difficulty mix is identical in the two conditions"},
        {"design_element": "Condition assignment of an individual alert",
         "value": "Rotated across participants, so that each of the twenty "
                  "alerts appears in the attribution condition for five "
                  "participants and in the no-attribution condition for five "
                  "participants, and every participant therefore sees all "
                  "twenty alerts exactly once"},
        {"design_element": "Order of conditions",
         "value": "Counterbalanced; five participants completed the attribution "
                  "condition first and five completed the no-attribution "
                  "condition first"},
        {"design_element": "Practice block",
         "value": "Five alerts drawn from the validation partition, completed "
                  "immediately after orientation and excluded from the twenty "
                  "timed alerts"},
        {"design_element": "Label provenance of validation-partition stimuli",
         "value": "All validation-partition stimuli derive from the single "
                  "malicious insider identity assigned to that partition "
                  "(Table 5)"},
    ]
    write_csv_dicts(Path(args.out) / "table12_triage_allocation.csv", table12)
    print(f"[ok] pool: {pool_composition(pool)}")
    print(f"[ok] allocation check: {check['ok']}")
    if not check["ok"]:
        for p in check["problems"]:
            print(f"     {p}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
