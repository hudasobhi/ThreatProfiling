#!/usr/bin/env python3
"""Step 10 - ablation study (Table 11 and Figure 13).

Each component is removed in turn and the model retrained.  The rows are:
removing the keystroke proxy channel, the mouse proxy channel, the
application usage channel, the keystroke and mouse channels together, the
temporal smoothness regulariser, the learned attention, and the Shapley
attribution layer.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch  # noqa: E402

from shadowdetectai.data.dataset import build_dataloader  # noqa: E402
from shadowdetectai.data.materialize import build_window_frame, channel_slices  # noqa: E402
from shadowdetectai.evaluation.attribution_eval import (  # noqa: E402
    model_attribution_fidelity)
from shadowdetectai.evaluation.metrics import classification_metrics, mean_std  # noqa: E402
from shadowdetectai.models.build import make_model  # noqa: E402
from shadowdetectai.training.trainer import TrainConfig, Trainer  # noqa: E402
from shadowdetectai.utils.config import get, load_config  # noqa: E402
from shadowdetectai.utils.io import write_csv_dicts  # noqa: E402

ABLATIONS = ["no_keystroke_proxy", "no_mouse_proxy", "no_application_channel",
             "no_keystroke_and_mouse", "no_smoothness_reg", "no_attention",
             "no_shapley_layer"]

#: The configuration names the paper prints in Table 11.  The comparison
#: against the target table keys on this label, so it must match exactly.
ABLATION_LABELS = {
    "__full__": "Full ShadowDetectAI",
    "no_keystroke_proxy": "Without keystroke proxy channel only",
    "no_mouse_proxy": "Without mouse proxy channel only",
    "no_application_channel": "Without application usage channel only",
    "no_keystroke_and_mouse": "Without keystroke and mouse channels (both)",
    "no_smoothness_reg": "Without temporal smoothness regularizer (Eq. 24)",
    "no_attention": "Uniform attention (Eq. 20 replaced by mean pooling)",
    "no_shapley_layer": "Without Shapley attribution layer",
}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--ablations", nargs="*", default=ABLATIONS)
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--max-fidelity-users", type=int, default=20)
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    rows = []
    for name in ["__full__"] + list(args.ablations):
        if name == "__full__":
            cfg_path = ROOT / "configs" / "default.yaml"
            cfg = load_config(cfg_path)
            label = ABLATION_LABELS["__full__"]
        else:
            cfg_path = ROOT / "configs" / "ablation" / f"{name}.yaml"
            cfg = load_config(cfg_path)
            label = ABLATION_LABELS.get(name, name.replace("_", " "))
        dims = cfg["encoder"]["channel_dims"]
        order = list(cfg["encoder"]["channel_order"])
        slices = channel_slices(dims, order)
        train_frame = build_window_frame(args.processed, cfg_path, "train")
        val_frame = build_window_frame(args.processed, cfg_path, "validation")
        test_frame = build_window_frame(args.processed, cfg_path, "test")
        train_loader = build_dataloader(train_frame, slices,
                                        batch_size=int(get(cfg, "training.batch_size", 256)))
        val_loader = build_dataloader(val_frame, slices, shuffle=False,
                                      batch_size=int(get(cfg, "training.batch_size", 256)))
        test_loader = build_dataloader(test_frame, slices, shuffle=False,
                                       batch_size=int(get(cfg, "training.batch_size", 256)))

        per_seed = []
        first_model = None
        for seed in list(get(cfg, "seeds.list", [42])):
            tcfg = TrainConfig.from_dict(get(cfg, "training", {}) or {})
            tcfg.seed = seed
            tcfg.output_dir = str(ROOT / "results" / "raw_runs" / "ablation" / name)
            model = make_model(cfg)
            if first_model is None:
                first_model = model
            trainer = Trainer(model, tcfg)
            trainer.fit(train_loader, val_loader)
            m = trainer.evaluate(test_loader)
            m["seed"] = seed
            per_seed.append(m)

        auc = mean_std([m["auc_roc"] for m in per_seed])
        f1 = mean_std([m["f1"] for m in per_seed])

        # The attribution fidelity of Eq. (30) for this configuration.  The
        # Shapley ablation reports it as not applicable, because removing
        # the attribution layer removes the quantity being measured.
        fidelity = None
        fidelity_std = 0.0
        if name != "no_shapley_layer":
            try:
                fidelity = model_attribution_fidelity(
                    first_model, test_frame, train_frame, device,
                    n_background=int(get(cfg, "shap.n_background", 100)),
                    n_coalitions=int(get(cfg, "shap.n_coalitions", 512)),
                    max_users=args.max_fidelity_users)
            except Exception as exc:
                print(f"[warn] {label}: fidelity not computed ({exc})")
        else:
            fidelity_std = 0.0
        rows.append({"configuration": label,
                     "auc_roc_mean": round(auc["mean"], 4),
                     "auc_roc_std": round(auc["std"], 4),
                     "fidelity_mean": ("" if fidelity is None
                                       else round(fidelity, 4)),
                     "fidelity_std": ("" if fidelity is None
                                      else round(fidelity_std, 4))})
        print(f"[ok] {label}: AUC {auc['mean']:.4f} +/- {auc['std']:.4f}")

    out = Path(args.out) / "table11_ablation.csv"
    write_csv_dicts(out, rows)
    print(f"[ok] wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
