#!/usr/bin/env python3
"""Evaluate a trained checkpoint on the test partition.

Outputs every metric the paper reports, plus the confusion matrix, the
per-class results, the inference time, the parameter count and FLOPs when the
optional ``fvcore`` dependency is installed.

    python test.py --config configs/default.yaml --checkpoint results/raw_runs/seed42_best.pt
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

import torch  # noqa: E402

from shadowdetectai.data.dataset import build_dataloader  # noqa: E402
from shadowdetectai.data.materialize import build_window_frame, channel_slices  # noqa: E402
from shadowdetectai.evaluation.confusion import class_report, confusion_matrix  # noqa: E402
from shadowdetectai.evaluation.metrics import classification_metrics  # noqa: E402
from shadowdetectai.evaluation.scalability import (  # noqa: E402
    count_parameters, estimate_flops, time_inference)
from shadowdetectai.models.build import make_model  # noqa: E402
from shadowdetectai.training.checkpoints import load_checkpoint  # noqa: E402
from shadowdetectai.utils.config import get, load_config  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--checkpoint", default=str(ROOT / "results" / "raw_runs" / "seed42_best.pt"))
    ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"))
    args = ap.parse_args()

    cfg = load_config(args.config)
    dims = cfg["encoder"]["channel_dims"]
    order = list(cfg["encoder"]["channel_order"])
    slices = channel_slices(dims, order)
    frame = build_window_frame(args.processed, args.config, "test")
    loader = build_dataloader(frame, slices, shuffle=False,
                              batch_size=int(get(cfg, "training.batch_size", 256)))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = make_model(cfg).to(device)
    ckpt = Path(args.checkpoint)
    if not ckpt.is_file():
        raise FileNotFoundError(
            f"Checkpoint not found: {ckpt}. Train the model first; refusing to "
            "report metrics from an untrained model as an evaluation.")
    load_checkpoint(ckpt, model)

    model.eval()
    logits, labels = [], []
    t0 = time.perf_counter()
    with torch.no_grad():
        for batch in loader:
            batch = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}
            out = model(batch)
            logits.extend(out["logit"].detach().cpu().numpy().tolist())
            labels.extend(batch["label"].detach().cpu().numpy().astype(int).tolist())
    elapsed = time.perf_counter() - t0

    metrics = classification_metrics(logits, labels, threshold=args.threshold)
    report = {
        "metrics": {k: (None if isinstance(v, float) and np.isnan(v) else v)
                    for k, v in metrics.items()},
        "confusion_matrix": confusion_matrix(labels, logits, args.threshold),
        "per_class": class_report(labels, logits, args.threshold),
        "inference_seconds_total": elapsed,
        "inference_seconds_per_sample": elapsed / max(len(labels), 1),
        "parameter_count": count_parameters(model),
        "flops": estimate_flops(model, next(iter(loader))),
        "checkpoint": str(ckpt),
    }
    print(json.dumps(report, indent=2, default=float))

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "test_report.json", "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, default=float)
    print(f"[ok] wrote {out_dir / 'test_report.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
