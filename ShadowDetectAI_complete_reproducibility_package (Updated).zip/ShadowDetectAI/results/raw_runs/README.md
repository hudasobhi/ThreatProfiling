# Raw-run artifact status

No original training run logs, checkpoints, model weights, predictions, logits, or per-seed confusion matrices were present in the supplied repository archive. Do not interpret the absence of files as zero-valued results.

`paper_reported_seed_level_auc.csv` contains only the ten ShadowDetectAI/LAN paired AUC-ROC values explicitly printed in the manuscript's Table 8 note. They are transcribed paper values, not raw run artifacts, and all other per-seed metrics are intentionally blank because they were not published in the manuscript.

`evidence_manifest.json` records this status in machine-readable form. See `docs/evidence_inventory.md` for the complete evidence boundary and what must be requested from the authors.


## Per-seed audit template

`per_seed_results_template.csv` lists all ten manuscript seeds and the expected result/artifact fields. It is intentionally not filled with inferred values. When a real run is performed, `scripts/05_evaluate.py` writes seed-specific prediction CSVs, confusion matrices, and metrics under `results/reproduced/per_seed/`; `scripts/04_train.py` writes training logs, summaries, and checkpoints under the configured raw-run directory. Keep the raw-run artifacts and record the corpus checksum and environment for any claimed reproduction.
