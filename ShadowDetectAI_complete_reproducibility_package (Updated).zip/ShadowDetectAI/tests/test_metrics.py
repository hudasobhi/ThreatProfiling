"""The evaluation metrics and their averaging (Section 5.5, Eq. 38)."""
from __future__ import annotations

import numpy as np

from shadowdetectai.evaluation.confusion import confusion_matrix
from shadowdetectai.evaluation.metrics import (
    classification_metrics, mean_std, precision_recall_f1, roc_auc)


def test_roc_auc_of_a_perfect_ranker():
    y = [0, 0, 1, 1]
    s = [0.1, 0.2, 0.8, 0.9]
    assert abs(roc_auc(y, s) - 1.0) < 1e-12


def test_roc_auc_of_a_random_ranker_is_near_half():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 2, 2000)
    s = rng.random(2000)
    assert 0.4 < roc_auc(y, s) < 0.6


def test_precision_recall_f1_on_a_known_case():
    y = [1, 1, 0, 0]
    s = [0.9, 0.8, 0.2, 0.1]
    out = precision_recall_f1(y, s, threshold=0.5)
    assert out["tp"] == 2 and out["tn"] == 2
    assert abs(out["precision"] - 1.0) < 1e-12
    assert abs(out["recall"] - 1.0) < 1e-12


def test_confusion_matrix_counts_add_up():
    y = [1, 1, 0, 0, 0]
    s = [0.9, 0.1, 0.7, 0.2, 0.3]
    cm = confusion_matrix(y, s, threshold=0.5)
    assert cm["TP"] + cm["FP"] + cm["FN"] + cm["TN"] == len(y)


def test_mean_and_standard_deviation_across_seeds():
    stats = mean_std([0.9, 1.0, 0.8])
    assert abs(stats["mean"] - 0.9) < 1e-12
    assert stats["n"] == 3
    assert stats["std"] > 0


def test_f1_is_the_harmonic_mean_of_precision_and_recall():
    y = [1, 1, 0, 0]
    s = [0.9, 0.1, 0.7, 0.2]
    m = classification_metrics(y, s, threshold=0.5)
    p, r = m["precision"], m["recall"]
    assert abs(m["f1"] - (2 * p * r / (p + r))) < 1e-12
