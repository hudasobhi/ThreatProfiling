"""The shipped YAML configs must agree with the paper's tables."""
from __future__ import annotations

from pathlib import Path

import pytest

from shadowdetectai.utils.config import get, load_config

ROOT = Path(__file__).resolve().parents[1]
PAPER_SEEDS = [42, 123, 256, 512, 1024, 999, 777, 333, 111, 888]


def test_default_config_matches_table_6():
    cfg = load_config(ROOT / "configs" / "default.yaml")
    assert get(cfg, "training.optimizer") == "adam"
    assert get(cfg, "training.learning_rate") == 0.0003
    assert get(cfg, "training.batch_size") == 256
    assert get(cfg, "training.epochs") == 60
    assert get(cfg, "model.num_heads") == 4
    assert get(cfg, "model.embed_dim") == 128
    assert get(cfg, "seeds.list") == PAPER_SEEDS
    assert get(cfg, "framework.version") == "2.1"


def test_shap_config_matches_table_6_and_table_4():
    cfg = load_config(ROOT / "configs" / "shap.yaml")
    assert get(cfg, "shap.n_background") == 100
    assert get(cfg, "shap.n_coalitions") == 512
    assert get(cfg, "shap.n_features") == 128
    assert get(cfg, "sensitivity.background_samples") == [50, 100, 200, 500]
    assert get(cfg, "sensitivity.coalition_samples") == [128, 256, 512, 1024]


@pytest.mark.parametrize("name", ["graphch", "lan", "double_layer", "vggm", "exai",
                                  "gaspar_mlp"])
def test_baseline_configs_have_a_grid_and_a_selected_value(name):
    cfg = load_config(ROOT / "configs" / "baselines" / f"{name}.yaml")
    grid = get(cfg, "grid")
    assert grid, f"{name} has no search grid"
    assert get(cfg, "training.learning_rate") is not None
    # The selected learning rate must be reachable from the grid.
    lr = get(cfg, "training.learning_rate")
    assert lr in grid["learning_rate"], (
        f"{name}: selected LR {lr} is not in the grid {grid['learning_rate']}")


@pytest.mark.parametrize("name", ["no_keystroke_proxy", "no_mouse_proxy",
                                  "no_application_channel",
                                  "no_keystroke_and_mouse", "no_attention",
                                  "no_smoothness_reg", "no_shapley_layer"])
def test_ablation_configs_declare_expected_values(name):
    cfg = load_config(ROOT / "configs" / "ablation" / f"{name}.yaml")
    assert get(cfg, "expected.auc_roc") is not None


def test_reported_table_numbers_are_present():
    """The shipped target tables carry the paper's reported values."""
    import csv

    path = ROOT / "results" / "tables" / "table08_detection_performance.csv"
    with open(path, "r", encoding="utf-8", newline="") as fh:
        rows = list(csv.DictReader(fh))
    by_method = {r["method"]: r for r in rows}
    assert by_method["ShadowDetectAI (proposed)"]["auc_roc"] == "0.987"
    assert by_method["LAN"]["auc_roc"] == "0.966"
    assert by_method["ShadowDetectAI (proposed)"]["fidelity"] == "0.943"
