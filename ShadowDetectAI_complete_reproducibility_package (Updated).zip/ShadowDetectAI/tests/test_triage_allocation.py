"""The triage allocation invariants of Section 6.4 and Table 12."""
from __future__ import annotations

from shadowdetectai.triage.alert_pool import (
    Alert, build_alert_pool, pool_composition, split_practice_block)
from shadowdetectai.triage.allocation import allocate, verify_allocation


def _alert(i, tp=True, partition="test"):
    return Alert(f"a{i:02d}", partition, tp, f"u{i}", i, 0.9 if tp else 0.1,
                 3, 1 if tp else 0)


def _pool():
    test = [_alert(i, tp=(i < 8)) for i in range(9)]   # 8 TP + 1 FP
    val = [_alert(100 + i, tp=(i < 5), partition="validation") for i in range(14)]
    return test, val


def test_pool_reaches_the_target_composition():
    test, val = _pool()
    pool = build_alert_pool(test, val)
    comp = pool_composition(pool)
    assert comp["total"] == 20
    assert comp["true_positive"] == 10
    assert comp["false_positive"] == 10


def test_pool_is_exhausted_from_the_test_partition_first():
    test, val = _pool()
    pool = build_alert_pool(test, val)
    comp = pool_composition(pool)
    assert comp["from_test"] == 9
    assert comp["from_validation"] == 11


def test_practice_block_comes_from_the_validation_partition():
    test, val = _pool()
    pool = build_alert_pool(test, val)
    practice = split_practice_block(pool)
    assert len(practice) == 5
    assert all(a.partition == "validation" for a in practice)


def test_every_alert_appears_in_each_condition_five_times():
    test, val = _pool()
    pool = build_alert_pool(test, val)
    schedules = allocate(pool, n_participants=10, seed=42)
    check = verify_allocation(pool, schedules)
    assert check["ok"], check["problems"]
    counts = {}
    for sch in schedules:
        for a in sch.attribution_alerts:
            counts[a] = counts.get(a, 0) + 1
    assert set(counts.values()) == {5}


def test_conditions_are_counterbalanced():
    test, val = _pool()
    pool = build_alert_pool(test, val)
    schedules = allocate(pool, n_participants=10, seed=42)
    first = [s.condition_order[0] for s in schedules]
    assert first.count("attribution") == 5
    assert first.count("no_attribution") == 5
