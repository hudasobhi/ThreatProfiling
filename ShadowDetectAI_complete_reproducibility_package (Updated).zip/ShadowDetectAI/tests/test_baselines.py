"""Every baseline must be importable and expose the common interface."""
from __future__ import annotations

import pytest

from shadowdetectai.baselines import BASELINE_TYPES, BaselineModel


def test_all_six_baselines_are_registered():
    assert set(BASELINE_TYPES) == {"graphch", "lan", "double_layer", "vggm",
                                   "exai", "gaspar_mlp"}


@pytest.mark.parametrize("name", sorted(BASELINE_TYPES))
def test_baseline_is_a_baseline_model(name):
    cls = BASELINE_TYPES[name]
    assert issubclass(cls, BaselineModel)


def test_baseline_source_contains_no_third_party_import():
    """The paper states the baselines were implemented from scratch."""
    import ast
    from pathlib import Path

    import shadowdetectai.baselines as pkg

    root = Path(pkg.__file__).parent
    for path in root.glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
                root_mod = node.module.split(".")[0]
                assert root_mod in ("torch", "numpy", "__future__",
                                    "shadowdetectai", "typing"), \
                    f"{path.name} imports third-party module {node.module}"
