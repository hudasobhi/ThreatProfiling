"""Guard the proxy claim: no hardware biometric field may be read.

The paper states (Section 4.1, Table 3 and the Ethical Considerations
statement) that the keystroke and mouse channels are built exclusively from
activity-log quantities and that no key press, key release, pointer-coordinate
or click-pressure telemetry is read, transmitted or stored at any stage.

This test is the code-level counterpart of that claim.
"""
from __future__ import annotations

import ast
from pathlib import Path

import pytest

from shadowdetectai.data.cert_loader import (
    ACTIVITY_LOGS, CHANNEL_SOURCE, FORBIDDEN_FIELDS, assert_no_hardware_fields)

ROOT = Path(__file__).resolve().parents[1]
FEATURE_MODULES = [
    ROOT / "src" / "shadowdetectai" / "features" / "keystroke_timing_proxy.py",
    ROOT / "src" / "shadowdetectai" / "features" / "mouse_interaction_proxy.py",
    ROOT / "src" / "shadowdetectai" / "features" / "application_sequence.py",
    ROOT / "src" / "shadowdetectai" / "features" / "proxy_mapping.py",
]


def test_forbidden_field_guard_rejects_hardware_columns():
    assert_no_hardware_fields(["timestamp", "user", "activity", "resource"])
    with pytest.raises(AssertionError):
        assert_no_hardware_fields(["timestamp", "key_press_time"])
    with pytest.raises(AssertionError):
        assert_no_hardware_fields(["timestamp", "click_x", "click_y"])


def test_only_the_five_activity_logs_are_used():
    assert set(ACTIVITY_LOGS) == {"logon", "file", "email", "device", "http"}
    assert set(CHANNEL_SOURCE.values()) <= {"logon", "device", "file+email+http"}


@pytest.mark.parametrize("path", FEATURE_MODULES)
def test_feature_modules_never_name_a_hardware_field(path: Path):
    """No feature module may reference a forbidden hardware field name."""
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    identifiers = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
    identifiers |= {node.attr for node in ast.walk(tree) if isinstance(node, ast.Attribute)}
    # 'release' and 'press' also appear in prose inside docstrings; only the
    # executable identifiers are checked.
    offenders = [i for i in identifiers
                 if any(f in i.lower() for f in FORBIDDEN_FIELDS)
                 and not i.lower().startswith("forbidden")]
    assert not offenders, f"{path.name} references hardware fields: {offenders}"


def test_timing_proxies_ignore_any_hardware_column():
    """The dwell and flight proxies must depend only on record timestamps.

    This is a behavioural check rather than a textual one: a session carrying
    extra hardware-telemetry columns must yield exactly the same feature
    vector as the same session without them.
    """
    import numpy as np
    import pandas as pd

    from shadowdetectai.features.keystroke_timing_proxy import (
        session_keystroke_features)
    from shadowdetectai.features.mouse_interaction_proxy import (
        session_mouse_features)

    t0 = pd.Timestamp("2023-05-01 09:00:00")
    base = pd.DataFrame({
        "timestamp": [t0 + pd.Timedelta(seconds=5.0 * i) for i in range(8)],
        "user": ["u1"] * 8,
        "activity": ["Logon"] * 8,
        "resource": ["PC1"] * 8,
    })
    contaminated = base.copy()
    contaminated["key_press_time"] = np.arange(8, dtype=float)
    contaminated["key_release_time"] = np.arange(8, dtype=float) * 2
    contaminated["pointer_x"] = np.arange(8, dtype=float) * 3
    contaminated["pointer_y"] = np.arange(8, dtype=float) * 4
    contaminated["click_pressure"] = np.arange(8, dtype=float) * 5

    assert np.allclose(session_keystroke_features(base),
                       session_keystroke_features(contaminated))
    assert np.allclose(session_mouse_features(base),
                       session_mouse_features(contaminated))


def test_the_proxy_modules_document_the_absence_of_hardware_telemetry():
    """The modules must say in prose that no hardware telemetry is read."""
    from shadowdetectai.features import (
        application_sequence, keystroke_timing_proxy, mouse_interaction_proxy)

    for module in (keystroke_timing_proxy, mouse_interaction_proxy,
                   application_sequence):
        doc = (module.__doc__ or "").lower()
        assert any(term in doc for term in
                   ("key press", "key release", "pointer", "hardware")), (
            f"{module.__name__} does not document the absence of hardware telemetry")
