"""The PSI drift metric and the adaptive threshold of Eq. (33)."""
from __future__ import annotations

import numpy as np

from shadowdetectai.calibration.adaptive_threshold import (
    AdaptiveThreshold, fit_base_threshold)
from shadowdetectai.calibration.psi_drift import (
    PSIReference, population_stability_index)


def test_psi_is_zero_for_identical_distributions():
    rng = np.random.default_rng(0)
    x = rng.normal(size=5000)
    assert abs(population_stability_index(x, x, n_bins=10)) < 1e-9


def test_psi_grows_with_drift():
    rng = np.random.default_rng(0)
    ref = rng.normal(0, 1, 5000)
    near = population_stability_index(ref, rng.normal(0, 1, 5000))
    far = population_stability_index(ref, rng.normal(3, 1, 5000))
    assert far > near


def test_psi_reference_stores_its_histogram():
    rng = np.random.default_rng(0)
    ref = PSIReference.fit(rng.normal(size=2000))
    assert ref.reference_probs.shape[0] == ref.n_bins
    assert abs(float(ref.reference_probs.sum()) - 1.0) < 1e-9


def test_adaptive_threshold_scales_with_psi():
    policy = AdaptiveThreshold(tau_0=0.5, lambda_drift=0.1)
    assert abs(policy.apply(0.0) - 0.5) < 1e-12
    assert abs(policy.apply(1.0) - 0.55) < 1e-12
    assert policy.apply(2.0) > policy.apply(1.0)


def test_base_threshold_respects_the_target_fpr():
    rng = np.random.default_rng(0)
    scores = rng.random(10000)
    tau = fit_base_threshold(scores, target_fpr=0.01)
    assert 0.0 < tau < 1.0
    assert (scores >= tau).mean() <= 0.011
