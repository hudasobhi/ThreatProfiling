"""Shared pytest fixtures and path setup for the test suite."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def pytest_configure(config):  # pragma: no cover
    config.addinivalue_line("markers", "torch: requires PyTorch")
