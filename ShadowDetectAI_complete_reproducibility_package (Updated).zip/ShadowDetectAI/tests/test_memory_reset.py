"""The cold-start memory reset required at each partition boundary (Section 6.1)."""
from __future__ import annotations

import torch

from shadowdetectai.evaluation.leakage_checks import check_memory_reset
from shadowdetectai.models.memory import MemoryStore


def test_memory_starts_at_zero():
    store = MemoryStore(memory_dim=8)
    assert store.state_norm() == 0.0
    assert torch.all(store.get("u1") == 0)


def test_reset_clears_every_state():
    store = MemoryStore(memory_dim=4)
    store.set("u1", torch.ones(4), time=0.0)
    store.set("u2", torch.ones(4) * 2, time=1.0)
    assert store.state_norm() > 0
    store.reset_memory()
    assert store.state_norm() == 0.0
    assert len(store) == 0
    assert check_memory_reset(store.snapshot())["ok"]


def test_no_state_survives_a_partition_boundary():
    store = MemoryStore(memory_dim=4)
    store.set("u1", torch.ones(4), time=0.0)
    store.reset_memory()               # end of the training partition
    assert torch.all(store.get("u1") == 0)
    store.reset_memory()               # end of the validation partition
    assert torch.all(store.get("u1") == 0)


def test_elapsed_time_is_monotone():
    store = MemoryStore(memory_dim=2)
    store.set("u1", torch.ones(2), time=100.0)
    assert store.elapsed("u1", 150.0) == 50.0
    assert store.elapsed("u1", 90.0) == 0.0
