"""The comparison against the paper's tables must not be able to pass by
accident.

``compare_results.py`` exists to tell the reader which of the paper's
reported numbers this code reproduces.  The failure mode it has to rule out
is a table whose columns do not line up with the target, which would leave
nothing to compare and would be reported as a pass.
"""
from __future__ import annotations

import csv
import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

_spec = importlib.util.spec_from_file_location(
    "compare_results", ROOT / "compare_results.py")
compare_results = importlib.util.module_from_spec(_spec)
sys.modules["compare_results"] = compare_results
_spec.loader.exec_module(compare_results)


def _rows(tmp_path: Path, name: str, rows):
    path = tmp_path / name
    with open(path, "w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    return path


def test_a_matching_table_produces_no_deviation(tmp_path):
    expected = _rows(tmp_path, "expected.csv", [
        {"method": "LAN", "auc_roc": "0.966", "auc_roc_std": "0.002"}])
    reproduced = _rows(tmp_path, "reproduced.csv", [
        {"method": "LAN", "auc_roc": "0.967", "auc_roc_std": "0.002"}])
    diffs, unmatched, missing = compare_results.compare(
        compare_results.read_csv(expected),
        compare_results.read_csv(reproduced),
        tolerance=0.02)
    assert len(diffs) == 2
    assert not [d for d in diffs if d[4]], "0.001 is inside the tolerance"
    assert not unmatched
    assert not missing


def test_a_deviation_above_the_tolerance_is_flagged(tmp_path):
    expected = _rows(tmp_path, "expected.csv", [
        {"method": "LAN", "auc_roc": "0.966"}])
    reproduced = _rows(tmp_path, "reproduced.csv", [
        {"method": "LAN", "auc_roc": "0.900"}])
    diffs, _, missing = compare_results.compare(
        compare_results.read_csv(expected),
        compare_results.read_csv(reproduced),
        tolerance=0.02)
    assert [d for d in diffs if d[4]], "0.066 must be flagged"
    assert not missing


def test_a_column_that_is_not_reproduced_is_reported_as_missing(tmp_path):
    """The silent-skip failure mode.

    The reproduced table simply does not carry the ``fidelity`` column.  The
    comparison must say so rather than quietly comparing nothing.
    """
    expected = _rows(tmp_path, "expected.csv", [
        {"method": "ShadowDetectAI (proposed)", "auc_roc": "0.987",
         "fidelity": "0.943"}])
    reproduced = _rows(tmp_path, "reproduced.csv", [
        {"method": "ShadowDetectAI (proposed)", "auc_roc": "0.987"}])
    diffs, _, missing = compare_results.compare(
        compare_results.read_csv(expected),
        compare_results.read_csv(reproduced),
        tolerance=0.02)
    assert len(diffs) == 1, "the AUC-ROC is comparable and must be compared"
    assert len(missing) == 1
    assert "fidelity" in missing[0]


def test_an_empty_cell_counts_as_missing(tmp_path):
    expected = _rows(tmp_path, "expected.csv", [
        {"method": "GraphCH", "fidelity": "0.5"}])
    reproduced = _rows(tmp_path, "reproduced.csv", [
        {"method": "GraphCH", "fidelity": ""}])
    _, _, missing = compare_results.compare(
        compare_results.read_csv(expected),
        compare_results.read_csv(reproduced),
        tolerance=0.02)
    assert len(missing) == 1


def test_a_row_with_no_reproduced_counterpart_is_unmatched(tmp_path):
    expected = _rows(tmp_path, "expected.csv", [
        {"method": "LAN", "auc_roc": "0.966"}])
    reproduced = _rows(tmp_path, "reproduced.csv", [
        {"method": "GraphCH", "auc_roc": "0.958"}])
    diffs, unmatched, missing = compare_results.compare(
        compare_results.read_csv(expected),
        compare_results.read_csv(reproduced),
        tolerance=0.02)
    assert not diffs
    assert unmatched == ["LAN"]
    assert not missing


def test_every_shipped_target_table_is_keyed_by_a_known_column():
    """Each target table must be comparable against a reproduced copy."""
    for path in sorted((ROOT / "results" / "tables").glob("*.csv")):
        rows = compare_results.read_csv(path)
        assert rows, f"{path.name} is empty"
        keys = compare_results.key_columns(rows)
        assert keys, f"{path.name} has no key column"
        assert all(k in rows[0] for k in keys)


def test_every_numeric_column_of_a_target_table_is_compared_by_default():
    """No target column may be silently excluded from the comparison."""
    for path in sorted((ROOT / "results" / "tables").glob("*.csv")):
        rows = compare_results.read_csv(path)
        for column in rows[0]:
            if column in compare_results.key_columns(rows):
                continue
            values = [compare_results.to_float(r.get(column, "")) for r in rows]
            if all(v is None for v in values):
                continue          # a text column, deliberately not compared
            assert column in compare_results.NUMERIC_COLUMNS, (
                f"{path.name}: the numeric column '{column}' is not in "
                f"NUMERIC_COLUMNS, so it would be skipped by the comparison")
