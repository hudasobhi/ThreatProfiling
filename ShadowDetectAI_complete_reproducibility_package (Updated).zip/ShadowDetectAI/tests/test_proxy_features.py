"""The three behavioural proxy channels produce the shapes the paper states."""
from __future__ import annotations

import numpy as np
import pandas as pd

from shadowdetectai.features.keystroke_timing_proxy import (
    KEYSTROKE_FEATURE_DIM, inter_record_intervals, session_keystroke_features)
from shadowdetectai.features.mouse_interaction_proxy import (
    MOUSE_FEATURE_DIM, session_mouse_features, shannon_entropy)
from shadowdetectai.features.proxy_mapping import TABLE_3, table_3_rows


def _session(n=10, step=5.0):
    t0 = pd.Timestamp("2023-05-01 09:00:00")
    return pd.DataFrame({
        "timestamp": [t0 + pd.Timedelta(seconds=step * i) for i in range(n)],
        "user": ["u1"] * n,
        "activity": ["Logon"] * n,
        "resource": ["PC1"] * n,
    })


def test_keystroke_proxy_has_eight_components():
    assert KEYSTROKE_FEATURE_DIM == 8
    vec = session_keystroke_features(_session())
    assert vec.shape == (8,)
    assert np.all(np.isfinite(vec))


def test_inter_record_intervals_match_the_equations():
    s = _session(n=5, step=4.0)
    iv = inter_record_intervals(s)
    # Eq. (11): d_i = tau_{i+1} - tau_i, i = 1 .. T_u - 1  ->  4 values
    assert np.allclose(iv["dwell"], [4.0, 4.0, 4.0, 4.0])
    # Eq. (12): l_i = tau_{i+2} - tau_i, i = 1 .. T_u - 2  ->  3 values
    assert np.allclose(iv["flight"], [8.0, 8.0, 8.0])


def test_mouse_proxy_entropy_and_width():
    assert MOUSE_FEATURE_DIM == 6
    vec = session_mouse_features(_session())
    assert vec.shape == (6,)
    assert np.all(np.isfinite(vec))


def test_shannon_entropy_of_a_uniform_histogram():
    assert abs(shannon_entropy(np.ones(4)) - np.log(4)) < 1e-9
    assert shannon_entropy(np.zeros(0)) == 0.0


def test_table_3_has_three_channels_and_one_excluded_row():
    assert len(TABLE_3) == 3
    rows = table_3_rows()
    assert len(rows) == 4
    assert "explicitly excluded" in rows[-1][2].lower()
