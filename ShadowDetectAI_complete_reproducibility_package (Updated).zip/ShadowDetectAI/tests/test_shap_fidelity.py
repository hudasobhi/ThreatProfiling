"""Attribution fidelity and the KernelSHAP machinery (Section 4.3)."""
from __future__ import annotations

import numpy as np
import pytest

from shadowdetectai.explain.attribution import rank_contributions
from shadowdetectai.explain.fidelity import fidelity, mean_fidelity
from shadowdetectai.explain.kernel_shap import (
    KernelShapConfig, KernelShapExplainer, coalition_matrix, kernel_shap)


def test_fidelity_is_one_for_an_exact_reconstruction():
    assert abs(fidelity(2.0, 2.0) - 1.0) < 1e-12
    assert abs(fidelity(1.0, 2.0) - 0.5) < 1e-12


def test_mean_fidelity_over_a_set():
    assert abs(mean_fidelity([2.0, 2.0], [2.0, 2.0]) - 1.0) < 1e-12


def test_kernel_shap_on_an_additive_model():
    """For a purely additive model the Shapley values recover the weights."""
    rng = np.random.default_rng(0)
    d = 6
    weights = rng.normal(size=d)
    coalitions = coalition_matrix(d, 4096, seed=1)

    def value_function(m):
        return m @ weights

    phi = kernel_shap(value_function(coalitions), coalitions)
    assert np.allclose(phi, weights, atol=0.15)


def test_shapley_values_reconstruct_the_model_output():
    """The KernelSHAP decomposition must add up to the model's own output.

    For an additive model the exact Shapley values are the weights
    themselves, and the baseline plus the contributions must reproduce the
    prediction.  This is the property Eq. (30)'s fidelity measures, so a
    regression that drops the intercept or the Shapley kernel weights
    silently destroys it.
    """
    rng = np.random.default_rng(0)
    d = 10
    weights = rng.normal(size=d)
    background = rng.normal(size=(200, d))
    cfg = KernelShapConfig(n_background=100, n_coalitions=4096, n_features=d, seed=3)
    expl = KernelShapExplainer(lambda m: m @ weights, cfg)
    expl.set_background(background)

    x = rng.normal(size=d)
    # The explainer keeps the first n_background rows, so the mean that
    # matters is the one it actually uses.
    bg_mean = expl.background_mean
    phi, baseline = expl.explain(x, return_baseline=True)
    prediction = float(x @ weights)

    # With background-mean imputation the marginal contribution of a feature
    # is its weight times its deviation from the background.
    assert np.allclose(phi, weights * (x - bg_mean), atol=0.15)
    # The baseline is the model's output on the background distribution.
    assert abs(baseline - float(bg_mean @ weights)) < 0.05
    # The decomposition reconstructs the prediction.
    assert abs((baseline + float(phi.sum())) - prediction) < 0.05
    # And Eq. (30) reports perfect fidelity.
    assert fidelity(float(phi.sum()), prediction, baseline) > 0.99


def test_shapley_weights_follow_the_coalition_sizes():
    """The regression weight must be read from the coalition, not sampled."""
    from shadowdetectai.explain.kernel_shap import _shapley_weights

    # Two coalitions of size 1 among 3 players: weight = (n-1)/(C(n,1)*1*(n-1)).
    coalitions = np.array([[1, 0, 0], [0, 1, 0], [1, 1, 1], [0, 0, 0]],
                          dtype=float)
    w = _shapley_weights(coalitions, 3)
    assert w[0] == w[1], "two coalitions of the same size must share a weight"
    assert w[2] == w[3] == 1.0 / 4.0, "the empty and full coalitions have weight 1/(n+1)"
    # (n-1) / (C(n,1) * 1 * (n-1)) = 2 / 6
    assert w[0] == pytest.approx(1.0 / 3.0)


def test_explainer_requires_a_background():
    expl = KernelShapExplainer(lambda m: m.sum(axis=1), KernelShapConfig())
    try:
        expl.explain(np.zeros(4))
    except RuntimeError:
        return
    raise AssertionError("explain must refuse to run without a background")


def test_top_contributors_are_ranked_by_magnitude():
    values = np.array([0.1, -0.9, 0.5, 0.05])
    top = rank_contributions(values, top_k=2)
    assert list(top) == [1, 2]
