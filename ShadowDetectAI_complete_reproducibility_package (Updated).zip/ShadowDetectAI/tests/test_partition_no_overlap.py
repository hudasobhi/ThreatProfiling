"""The three partitions must be chronologically disjoint (Section 6.1)."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from shadowdetectai.data.partition import (
    PARTITION_MONTHS, PARTITION_ORDER, partition_manifest, split_windows)

ROOT = Path(__file__).resolve().parents[1]


def _dummy_events():
    return pd.DataFrame({"timestamp": pd.to_datetime(
        ["2023-01-01", "2023-07-01", "2024-01-01", "2024-06-01"])})


def test_partition_month_ranges_are_contiguous():
    assert PARTITION_MONTHS["train"] == tuple(range(1, 14))
    assert PARTITION_MONTHS["validation"] == (14, 15)
    assert PARTITION_MONTHS["test"] == tuple(range(16, 19))
    covered = []
    for name in PARTITION_ORDER:
        covered.extend(PARTITION_MONTHS[name])
    assert covered == list(range(1, 19)), "the 18 months must be covered exactly once"


def test_partition_windows_do_not_overlap():
    events = _dummy_events()
    manifest = partition_manifest(events, window_hours=24)
    windows = pd.Series(range(0, 640))
    parts = split_windows(windows, manifest, window_hours=24)
    sets = {name: set(parts[parts == name].index) for name in PARTITION_ORDER}
    for i, a in enumerate(PARTITION_ORDER):
        for b in PARTITION_ORDER[i + 1:]:
            assert not (sets[a] & sets[b]), f"{a} and {b} overlap"


def test_manifest_is_persisted_as_json():
    manifest = partition_manifest(_dummy_events(), window_hours=24)
    payload = json.loads(manifest.to_json())
    assert payload["cold_start_memory"] is True
    assert payload["no_gap_month"] is True
    assert set(payload["bounds"]) == set(PARTITION_ORDER)


def test_shipped_manifest_matches_the_paper():
    path = ROOT / "data" / "splits" / "partition_manifest.json"
    if not path.exists():
        return
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert set(payload["bounds"]) == {"train", "validation", "test"}
