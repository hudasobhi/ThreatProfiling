# Data and proxy mapping

This is the machine-readable form of the paper's Table 3 and Ethical
Considerations statement.  `src/shadowdetectai/features/proxy_mapping.py` is
the single source of truth and this document is generated from it by hand to
match.

## Table 3 — log source → proxy channel

| CERT r6.2 log source read | Proxy statistic computed | Channel name used throughout the manuscript |
|---|---|---|
| Logon and session activity records (timestamped) | Inter-event interval distribution inside a session window; mean, standard deviation, median and ninetieth percentile of the interval | Keystroke timing proxy channel |
| Device (USB) activity records (timestamped) | Frequency distribution of device events and their inter-event intervals; Shannon entropy of the interval histogram | Mouse interaction proxy channel |
| File, email and HTTP activity records (timestamped) | Categorical resource-access embedding with sinusoidal session-position encoding, aggregated by a single-layer GRU | Application usage sequencing channel |
| None; no hardware sensor field exists in the release and none is read | Not applicable | Explicitly excluded; reported in the Ethical Considerations statement |

## The equations, and what they are not

| Equation | Definition | Is it a hardware measurement? |
|---|---|---|
| Eq. (11) `d_i = τ_{i+1} − τ_i` | interval between the timestamps of two consecutive log records of one session | **No.** `τ` is an activity-log record timestamp. |
| Eq. (12) `l_i = τ_{i+2} − τ_i` | interval spanned by three consecutive log records of one session | **No.** |
| Eq. (13) `k_t` | eight statistics of the two interval arrays above | **No.** |
| Eq. (14) `H_v` | Shannon entropy of the device-event frequency histogram | **No.** Device records are USB connect/disconnect events; the channel treats their frequency distribution as a coarse proxy for interaction rate and says so. |
| Eq. (15) `e_i` | learned resource embedding + sinusoidal session position | **No.** |

## Construct validity

The mapping from logon records to a *keystroke timing proxy* and from USB
device records to a *mouse interaction proxy* is a modelling choice, not a
measurement of typing or pointing.  The revised manuscript states this
explicitly in Section 4.1: the construct validity of both mappings is a
stated limitation, the empirical basis for retaining the channels rests on
the single-channel ablations of Table 11 and the per-channel attribution
magnitudes of Table 10, and not on any direct measurement of keystroke or
mouse dynamics.

`tests/test_no_hardware_fields.py` enforces the same claim in code:

* the runtime guard `assert_no_hardware_fields` rejects any event table with
  a hardware-sounding column;
* the feature modules are checked for forbidden identifiers in their ASTs;
* the proxy computation is verified to be **invariant** to the presence of
  extra hardware-telemetry columns — a session carrying `key_press_time`,
  `key_release_time`, `pointer_x`, `pointer_y` and `click_pressure` yields
  exactly the same feature vector as the same session without them.
