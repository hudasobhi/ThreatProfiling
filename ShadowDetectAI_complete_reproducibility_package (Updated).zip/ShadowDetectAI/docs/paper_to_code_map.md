# Paper-to-code map

Every equation, table and figure of the paper, and the file and function that
implements it.

## Equations

| Eq. | Meaning | File | Symbol |
|---|---|---|---|
| (1) | user event sequence | `src/shadowdetectai/data/windowing.py` | `assign_windows` |
| (2) | event tuple (τ, channel, resource, proxy) | `src/shadowdetectai/data/cert_loader.py` | `load_events` |
| (3) | window length / feature dimensionality | `configs/encoder.yaml` | `encoder.channel_dims` |
| (4) | dynamic graph G_t = (V_t, E_t) | `src/shadowdetectai/data/graph_builder.py` | `build_window_graph` |
| (5) | edge creation | `src/shadowdetectai/data/graph_builder.py` | `build_window_graph` |
| (6) | adjacency matrix | `src/shadowdetectai/data/graph_builder.py` | `WindowGraph.adjacency` |
| (7) | node feature matrix | `src/shadowdetectai/data/materialize.py` | `build_window_frame` |
| (8) | scoring function | `src/shadowdetectai/models/tgnn.py` | `ShadowDetectAI.forward` |
| (9) | interpretable risk score | `src/shadowdetectai/models/classifier.py` | `InterpretableRiskScore` |
| (10) | empirical risk | `src/shadowdetectai/models/losses.py` | `composite_loss` |
| (11) | dwell proxy d_i = τ_{i+1} − τ_i | `src/shadowdetectai/features/keystroke_timing_proxy.py` | `inter_record_intervals` |
| (12) | flight proxy l_i = τ_{i+2} − τ_i | `src/shadowdetectai/features/keystroke_timing_proxy.py` | `inter_record_intervals` |
| (13) | Eq. (13) statistics vector | `src/shadowdetectai/features/keystroke_timing_proxy.py` | `session_keystroke_features` |
| (14) | Shannon entropy H_v | `src/shadowdetectai/features/mouse_interaction_proxy.py` | `shannon_entropy` |
| (15) | e_i = Emb(r_i) + PE(pos_i) | `src/shadowdetectai/features/application_sequence.py` | `ApplicationSequenceEncoder` |
| (16) | fusion f_t = W[h_ks; h_mouse; h_app] + b | `src/shadowdetectai/models/encoder.py` | `MultiChannelBehavioralEncoder.forward` |
| (17) | message function | `src/shadowdetectai/models/memory.py` | `MessageFunction.forward` |
| (18) | GRU memory update | `src/shadowdetectai/models/memory.py` | `MemoryModule.forward` |
| (19) | temporal embedding gate | `src/shadowdetectai/models/temporal_attention.py` | `TemporalAttention.forward` |
| (20) | attention coefficients | `src/shadowdetectai/models/temporal_attention.py` | `TemporalAttention.forward` |
| (21) | multi-head concatenation | `src/shadowdetectai/models/temporal_attention.py` | `TemporalAttention.forward` |
| (22) | classification logit | `src/shadowdetectai/models/classifier.py` | `UserClassifier.forward` |
| (23) | anomaly probability | `src/shadowdetectai/models/classifier.py` | `sigmoid` |
| (24) | temporal smoothness regulariser | `src/shadowdetectai/models/tgnn.py` | `smoothness_penalty` |
| (25) | coalition value function | `src/shadowdetectai/explain/kernel_shap.py` | `KernelShapExplainer.explain` |
| (26) | Shapley additivity | `src/shadowdetectai/explain/kernel_shap.py` | `kernel_shap` |
| (27) | approximation of the logit | `src/shadowdetectai/explain/fidelity.py` | `fidelity` |
| (28) | top-k ranking | `src/shadowdetectai/explain/attribution.py` | `rank_contributions` |
| (29) | risk score from the attribution | `src/shadowdetectai/models/classifier.py` | `InterpretableRiskScore.from_attribution` |
| (30) | fidelity metric | `src/shadowdetectai/explain/fidelity.py` | `fidelity` |
| (31) | Platt scaling | `src/shadowdetectai/calibration/platt.py` | `PlattScaler.transform` |
| (32) | population stability index | `src/shadowdetectai/calibration/psi_drift.py` | `population_stability_index` |
| (33) | adaptive threshold | `src/shadowdetectai/calibration/adaptive_threshold.py` | `AdaptiveThreshold.apply` |
| (34) | channel scores | `src/shadowdetectai/calibration/platt.py` | `PlattScaler.transform` |
| (35) | role-conditioned fusion | `src/shadowdetectai/calibration/alert_fusion.py` | `fuse_scores` |
| (36) | composite loss | `src/shadowdetectai/models/losses.py` | `composite_loss` |
| (37) | binary cross-entropy | `src/shadowdetectai/models/losses.py` | `binary_cross_entropy` |
| (38) | AUC-ROC | `src/shadowdetectai/evaluation/metrics.py` | `roc_auc` |
| Eq. (33) operating point | the fitted, drift-adapted threshold | `src/shadowdetectai/evaluation/operating_point.py` | `fit_operating_point` |
| Eq. (30) for a trained model | the fidelity of the attribution against the model's own logit | `src/shadowdetectai/evaluation/attribution_eval.py` | `model_attribution_fidelity` |
| Eq. (28) panel | the ranked top-five contributors the analyst sees | `src/shadowdetectai/explain/model_fidelity.py` | `top_contributor_panel` |

## Tables

| Table | Content | Produced by | Target CSV |
|---|---|---|---|
| 1 | capability comparison of related work | — (prose) | — |
| 2 | notation | — (prose) | — |
| 3 | log source → proxy channel mapping | `src/shadowdetectai/features/proxy_mapping.py` | `table_3_rows()` |
| 4 | KernelSHAP sensitivity | `scripts/08_shap_sensitivity.py` | `results/tables/table04_shap_sensitivity.csv` |
| 5 | dataset partitions | `scripts/01_preprocess.py` | `results/tables/table05_dataset_partitions.csv` |
| 6 | implementation and training configuration | `configs/default.yaml` | — |
| 7 | baseline grid search and selection | `scripts/07_grid_search_baselines.py` | `results/tables/table07_baseline_grid_search.csv` |
| 8 | detection performance | `scripts/05_evaluate.py`, `scripts/06_run_baselines.py` | `results/tables/table08_detection_performance.csv` |
| 9 | confusion matrix | `scripts/05_evaluate.py` | `results/tables/table09_confusion_matrix.csv` |
| 10 | per-channel attribution magnitude | `scripts/09_channel_contribution.py` | `results/tables/table10_channel_attribution.csv` |
| 11 | ablation study | `scripts/10_ablation.py` | `results/tables/table11_ablation.csv` |
| 12 | triage alert pool and allocation | `scripts/14_triage_alert_pool.py` | `results/tables/table12_triage_allocation.csv` |
| 13 | triage time and disposition accuracy | `scripts/15_triage_analysis.py` | `results/tables/table13_triage_results.csv` |
| 14 | LOIO cross-validation | `scripts/11_loio_cv.py` | `results/tables/table14_loio.csv` |

## Figures

| Figure | Content | Produced by |
|---|---|---|
| 1 | motivating drift failure mode | authored artwork |
| 2 | system overview | authored artwork |
| 3 | end-to-end architecture | authored artwork |
| 4 | channel-separated vs. pooled fusion | authored artwork |
| 5 | embedding trajectories | authored artwork |
| 6 | algorithm workflow | authored artwork |
| 7 | ROC curves | `figures/make_figures.py` (from the evaluated scores) |
| 8 | per-channel attribution | `figures/make_figures.py` (from `table10_channel_attribution.csv`) |
| 9 | detection accuracy under drift | `figures/make_figures.py` (from `scripts/12_drift_and_calibration.py`) |
| 10 | alert volume, fixed vs. adaptive threshold | `figures/make_figures.py` (from `figure10_alert_volume.csv`) |
| 11 | scalability | `figures/make_figures.py` (from `figure11_scalability.csv`) |
| 12 | attribution fidelity across baselines | `figures/make_figures.py` (from `table08_detection_performance.csv`) |
| 13 | ablation bars and FPR at fixed recall | `figures/make_figures.py` (from `table11_ablation.csv`) |
| 14 | analyst triage time | `figures/make_figures.py` (from `table13_triage_results.csv`) |

## Sections

| Paper section | Code |
|---|---|
| 3.1 User activity and behavioural feature model | `src/shadowdetectai/data/` |
| 3.2 Dynamic interaction graph model | `src/shadowdetectai/data/graph_builder.py` |
| 3.3 Detection objective | `src/shadowdetectai/models/tgnn.py`, `models/classifier.py` |
| 4.1 Multi-channel behavioural encoder | `src/shadowdetectai/features/`, `models/encoder.py` |
| 4.2 Temporal graph neural network | `src/shadowdetectai/models/` |
| 4.3 Shapley attribution layer | `src/shadowdetectai/explain/` |
| 5.1 Score calibration | `src/shadowdetectai/calibration/platt.py` |
| 5.2 Behavioural drift detection | `src/shadowdetectai/calibration/psi_drift.py`, `adaptive_threshold.py` |
| 5.3 Multi-channel alert fusion | `src/shadowdetectai/calibration/alert_fusion.py` |
| 5.4 Composite training loss | `src/shadowdetectai/models/losses.py` |
| 5.5 Evaluation metric definition | `src/shadowdetectai/evaluation/metrics.py` |
| 6.1 Datasets | `src/shadowdetectai/data/partition.py`, `labeling.py` |
| 6.2 Behavioural channel contribution | `src/shadowdetectai/evaluation/channel_analysis.py` |
| 6.3 Robustness to drift, calibration, scalability | `src/shadowdetectai/evaluation/drift_robustness.py`, `scalability.py` |
| 6.4 Analyst triage simulation | `src/shadowdetectai/triage/` |
