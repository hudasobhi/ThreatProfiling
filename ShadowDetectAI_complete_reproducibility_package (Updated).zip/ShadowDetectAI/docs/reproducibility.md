# Reproducibility Specification

Extracted from the paper *"Explainable Deep Learning for Insider Threat
Profiling Using Log-Derived Behavioral Proxies and Temporal Graph Networks"*
(ShadowDetectAI).  This document is the contract between the manuscript and
the code: every number below is either quoted from the paper, or marked
`[NOT STATED IN PAPER]` / `[UNVERIFIED]` with the default this repository uses
and the reason for the choice.

Nothing here is invented.  Where the paper is silent, the gap is named.

---

## 1. Dataset

| Item | Value | Source |
|---|---|---|
| Name | CMU CERT r6.2 insider threat corpus | paper, Section 6.1 |
| Official URL | `https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247` | paper, Data Availability statement |
| DOI | `[UNVERIFIED]` — the paper gives no DOI for the dataset | — |
| Licence | `[UNVERIFIED]` — the KiltHub record's terms are not quoted in the paper | — |
| SHA256 | `[UNVERIFIED]` — not published; see `data/checksums.sha256` | — |
| Simulation span | 18 months | paper, Section 6.1 |
| Employee identities | 4,000 | paper, Section 6.1 |
| Malicious insider identities | 5 | paper, Section 6.1 |
| Activity logs used | `logon`, `file`, `email`, `device`, `http` | paper, Table 3 |
| Hardware telemetry used | **none** — no key press, key release, pointer-coordinate or click-pressure field exists in the release | paper, Section 4.1 and Table 3 |
| Class balance | malicious class is well under 0.1 % of labelled windows | paper, Section 6.1, citing [27] |

### 1.1 Split

Chronological, contiguous, **no gap month** (the absence of a gap is a stated
limitation of the paper, Section 6.1).

| Partition | Months | Users (nodes) | Windows | Malicious windows | Malicious identities | Split (window count) |
|---|---|---|---|---|---|---|
| train | 1–13 | 3,200 | 96,000 | 42 | 3 | 70 % |
| validation | 14–15 | 690 | 20,600 | 9 | 1 | 15 % |
| test | 16–18 | 690 | 20,600 | 9 | 1 | 15 % |

Source: paper Table 5 and Section 6.1.  The user counts include resource
nodes promoted during graph construction; 4,580 node entries in total, of
which 4,000 are human employee accounts.

> The paper's Table 5 note also reports time-based fractions of
> 72.2 % / 11.1 % / 16.7 % (months 1–13, 14–15, 16–18 of 18).  Both
> representations are correct under their own denominator; this repository
> reproduces the window-count figures, which are the ones Table 5 prints.

### 1.2 Windowing

* `Delta = 24 h`, non-overlapping (paper, Section 6.1). → `configs/data.yaml: windowing.window_hours`
* Session gap: **`[NOT STATED IN PAPER]`**.  Default **1800 s** (30-minute
  inactivity), the conventional threshold for enterprise audit logs.  Exposed
  as `data.session_gap_seconds` so it can be swept.
* Window origin: the earliest timestamp in the corpus, so the grid is
  identical on every run.

### 1.3 Cold-start memory

Paper Section 6.1: the TGN memory is reset to a zero vector at every
partition boundary, and no memory tensor is propagated across a boundary.
Implemented in `src/shadowdetectai/models/memory.py: MemoryStore.reset_memory`
and asserted by `tests/test_memory_reset.py`.

---

## 2. Model architecture

Every equation is mapped to its implementation in
`docs/paper_to_code_map.md`.

| Component | Paper | Value | Code |
|---|---|---|---|
| Multi-channel encoder | Eq. (16) | `f_t = W [h_ks ; h_mouse ; h_app] + b`, d = 128 | `models/encoder.py` |
| Keystroke timing proxy | Eqs. (11)–(13) | `d_i = τ_{i+1} − τ_i`; `l_i = τ_{i+2} − τ_i`; `k_t = [μ_d, σ_d, P50_d, P90_d, μ_l, σ_l, P50_l, P90_l]` | `features/keystroke_timing_proxy.py` |
| Mouse interaction proxy | Eq. (14) | `H_v = −Σ p_i log p_i` over the device-event frequency histogram | `features/mouse_interaction_proxy.py` |
| Application sequencing | Eq. (15) | `e_i = Emb(r_i) + PE(pos_i)`, aggregated by a single-layer GRU | `features/application_sequence.py` |
| TGN message | Eq. (17) | two-layer feed-forward over `[s_v, s_u, Δt, s_u_prev]` | `models/memory.py: MessageFunction` |
| TGN memory update | Eq. (18) | gated recurrent unit | `models/memory.py: MemoryModule` |
| Temporal attention | Eqs. (19)–(21) | 4 heads, LeakyReLU attention logits, softmax over the neighbourhood | `models/temporal_attention.py` |
| Classifier | Eqs. (22)–(23) | `z_{u,t} = W_cls [z_u(t)] + b`; `p = σ(z)` | `models/classifier.py` |
| Smoothness regulariser | Eq. (24) | `‖z_u(t) − z_u(t−1)‖²` between adjacent windows | `models/tgnn.py: smoothness_penalty` |
| Shapley attribution | Eqs. (25)–(28) | KernelSHAP, 100 background windows, 512 coalitions, d = 128 features + 1 neighbourhood player | `explain/kernel_shap.py` |
| Attribution fidelity | Eq. (30) | `1 − ‖Σφ − z‖ / ‖z‖` | `explain/fidelity.py` |
| Platt scaling | Eq. (31) | `p = σ(a·z + b)`, fitted by maximum likelihood | `calibration/platt.py` |
| operating threshold | Eq. (33) | `τ_0` fitted on the validation partition at a 1 % target FPR, then `τ = τ_0 (1 + λ·PSI)` | `evaluation/operating_point.py` |
| Population stability index | Eq. (32) | `Σ (p_i − q_i) ln(p_i/q_i)` | `calibration/psi_drift.py` |
| Adaptive threshold | Eq. (33) | `τ_t = τ_0 (1 + λ_drift · PSI_t)` | `calibration/adaptive_threshold.py` |
| Alert fusion | Eqs. (34)–(35) | role-conditioned softmax over channel scores | `calibration/alert_fusion.py` |
| Composite loss | Eqs. (36)–(37) | `L = L_bce + λ_smooth L_smooth + λ_reg L_reg` | `models/losses.py` |

### 2.1 Dimensions

| Tensor | Width | Source |
|---|---|---|
| Fused behavioural embedding | 128 | Table 6 |
| Keystroke proxy block | 8 | Eq. (13) |
| Mouse proxy block | 6 | Eq. (14) + interval statistics |
| Application block | 64 | `[NOT STATED IN PAPER]` — the paper names a learned categorical embedding but no width; 64 is used and exposed in `configs/encoder.yaml` |
| TGN memory | 128 | `[NOT STATED IN PAPER]` — set equal to the embedding dimension |
| Attention heads | 4 | Table 6 |
| Attention head dimension | 32 | derived (128 / 4) |

### 2.2 Loss weighting

`λ_smooth` and `λ_reg` are **`[NOT STATED IN PAPER]`**.

| Symbol | Default | Reason |
|---|---|---|
| `λ_smooth` | 0.1 | The smoothness term of Table 11 costs 0.6 percentage points of AUC-ROC when removed, i.e. it is a small effect; 0.1 reproduces that order of magnitude. Exposed as `model.smooth_lambda`. |
| `λ_reg` | 1e-5 | Standard small L2 coefficient for a 128-dim model. Exposed as `model.reg_lambda`. |

### 2.3 Normalisation and activations

`[NOT STATED IN PAPER]` for every normalisation layer, activation choice
inside the classifier, and dropout in the main model.  This repository uses:

* no normalisation layer anywhere (no batch norm / layer norm is mentioned);
* ReLU inside the classifier MLP and the attention value projection;
* sigmoid on the attention logits' input via LeakyReLU(0.2), following
  Rossi et al. [24];
* no dropout in the main model; dropout appears only in the baselines, where
  the paper's Table 7 grids state it explicitly.

---

## 3. Hyperparameters (Table 6, "Implementation and training configuration")

| Parameter | Value | Config key |
|---|---|---|
| Framework | PyTorch | `framework.name` |
| Framework version | 2.1 | `framework.version` |
| GPU | single 24 GB accelerator | `hardware.gpu` |
| CUDA version | `[UNVERIFIED]` — not stated in the paper | `hardware.cuda` |
| Optimiser | Adam | `training.optimizer` |
| Learning rate | 0.0003 | `training.learning_rate` |
| Schedule | `[NOT STATED IN PAPER]` → none | `training.scheduler` |
| Warmup | `[NOT STATED IN PAPER]` → 0 | `training.warmup_steps` |
| Weight decay | `[NOT STATED IN PAPER]` → 0 in the optimiser, `λ_reg` in the loss | `training.weight_decay` |
| Batch size | 256 users per window | `training.batch_size` |
| Epochs | 60 | `training.epochs` |
| Early stopping | `[NOT STATED IN PAPER]` → none | `training.early_stopping_patience` |
| Attention heads | 4 | `model.num_heads` |
| Embedding dimension | 128 | `model.embed_dim` |
| SHAP algorithm | KernelSHAP | `shap.algorithm` |
| SHAP background samples | 100 benign training windows (fixed) | `shap.n_background` |
| SHAP coalition samples per user | 512 | `shap.n_coalitions` |
| Independent runs | 10 | `seeds.list` |
| Seeds | 42, 123, 256, 512, 1024, 999, 777, 333, 111, 888 | `seeds.list` |

Mixed precision and multi-GPU are available through `training.use_amp` and
`training.device` but are **off** by default, because the paper does not
state that they were used.

---

## 4. Metrics (Section 5.5, Eq. 38)

| Metric | Definition | Averaging | Code |
|---|---|---|---|
| AUC-ROC | integral of TPR over FPR across all thresholds | single binary task, not macro-averaged | `evaluation/metrics.py: roc_auc` |
| Precision | TP / (TP + FP) | at the operating threshold of Eq. (33) | `evaluation/metrics.py: precision_recall_f1` |
| Recall | TP / (TP + FN) | at the operating threshold | same |
| F1 | 2PR / (P + R) | at the operating threshold | same |
| Attribution fidelity | Eq. (30) | mean over flagged users | `explain/fidelity.py` |
| Top-3 contribution recall | fraction of annotated drivers in the top 3 | mean over annotated users | `explain/topk_recall.py` |
| Population stability index | Eq. (32) | over K score bins | `calibration/psi_drift.py` |

The paper does not report macro/micro/weighted averaging because the task is
binary; the positive class is the malicious window.

### 4.1 Operating threshold

`[NOT STATED IN PAPER]` for the target false-positive rate used to fit `τ_0`.
Default **1 %**, which matches the confusion matrix of Table 9 (1 false
positive among 20,591 benign windows) and is exposed as
`calibration.drift.base_threshold`.

---

## 5. Baselines (Section 6.3, Table 8)

All six were "implemented from scratch in PyTorch 2.1 without use of
third-party code repositories".  This repository contains original
implementations only; `tests/test_baselines.py` asserts that no third-party
import appears in the baseline package.

| Baseline | Reference | Table 7 grid | Selected | Paper AUC-ROC |
|---|---|---|---|---|
| GraphCH | Roy & Chen [5] | LR ∈ {0.0001, 0.0003, 0.001}; Layers ∈ {2, 3}; Dim ∈ {64, 128, 256} | LR 0.0003, Layers 2, Dim 128 | 0.958 ± 0.003 |
| LAN | Cai et al. [4] | LR ∈ {0.0001, 0.0003, 0.001}; Heads ∈ {2, 4, 8}; Window ∈ {12, 24, 48} h | LR 0.0003, Heads 4, Window 24 h | 0.966 ± 0.002 |
| Double Layer Detection | He et al. [6] | LR ∈ {0.0001, 0.0003, 0.001}; Dim ∈ {64, 128}; Dropout ∈ {0.1, 0.3, 0.5} | LR 0.0001, Dim 128, Dropout 0.3 | 0.947 ± 0.003 |
| VGGM | Zhang et al. [7] | LR ∈ {0.0001, 0.001}; Components ∈ {2, 4, 8}; Latent ∈ {32, 64, 128} | LR 0.001, Components 4, Latent 64 | 0.941 ± 0.004 |
| EXAI | Arreche et al. [9] | LR ∈ {0.0001, 0.001}; Layers ∈ {2, 3, 4}; Units ∈ {64, 128, 256} | LR 0.001, Layers 3, Units 128 | 0.918 ± 0.005 |
| Gaspar et al. | Gaspar et al. [10] | LR ∈ {0.0001, 0.001}; Layers ∈ {2, 3, 4}; Units ∈ {64, 128, 256} | LR 0.0003, Layers 2, Units 64 | 0.912 ± 0.004 |

> **Inconsistency in Table 7 (flagged, not silently corrected).**  For the
> Gaspar et al. baseline the paper prints the learning-rate grid as
> `{0.0001, 0.001}` but reports the selected configuration as `LR = 0.0003`,
> which is not a member of that grid.  `configs/baselines/gaspar_mlp.yaml`
> therefore adds `0.0003` to the grid so the reported selected configuration
> is reachable, and keeps `0.0003` as the default.  The other five baselines
> are internally consistent; `tests/test_config_integrity.py` asserts that the
> selected learning rate is a member of the grid for every baseline.

Grid search is evaluated on the **validation** partition AUC-ROC, and the
best configuration is applied to the test partition without further
modification (Section 6.3).

---

## 6. Ablations (Section 6.4, Table 11)

| Configuration | Paper AUC-ROC | Paper fidelity | Config |
|---|---|---|---|
| Full ShadowDetectAI | 0.987 ± 0.002 | 0.943 ± 0.003 | `configs/default.yaml` |
| Without keystroke proxy channel only | 0.971 ± 0.003 | 0.935 ± 0.004 | `configs/ablation/no_keystroke_proxy.yaml` |
| Without mouse proxy channel only | 0.974 ± 0.003 | 0.937 ± 0.004 | `configs/ablation/no_mouse_proxy.yaml` |
| Without application usage channel only | 0.956 ± 0.004 | 0.929 ± 0.005 | `configs/ablation/no_application_channel.yaml` |
| Without keystroke and mouse channels (both) | 0.951 ± 0.004 | 0.928 ± 0.005 | `configs/ablation/no_keystroke_and_mouse.yaml` |
| Without temporal smoothness regulariser | 0.981 ± 0.003 | 0.940 ± 0.004 | `configs/ablation/no_smoothness_reg.yaml` |
| Uniform attention (Eq. (20) → mean pooling) | 0.963 ± 0.004 | 0.937 ± 0.004 | `configs/ablation/no_attention.yaml` |
| Without Shapley attribution layer | 0.987 ± 0.002 | N/A | `configs/ablation/no_shapley_layer.yaml` |

The Shapley layer is applied after training, so removing it cannot change the
AUC-ROC; this is why the last row repeats the full model's AUC.

---

## 7. Target values

Every reported number is stored as a target CSV under `results/tables/` and is
the input to `compare_results.py`.  No value is rounded differently from the
paper.

### 7.1 Table 4 — KernelSHAP sensitivity

| Panel | Background | Coalitions | Fidelity | Top-3 recall | Latency (ms/user) |
|---|---|---|---|---|---|
| A | 50 | 512 | 0.921 ± 0.006 | 0.81 ± 0.03 | 112 ± 4 |
| A | 100 | 512 | 0.941 ± 0.004 | 0.87 ± 0.02 | 143 ± 5 |
| A | 200 | 512 | 0.943 ± 0.004 | 0.87 ± 0.02 | 198 ± 6 |
| A | 500 | 512 | 0.944 ± 0.003 | 0.87 ± 0.02 | 361 ± 9 |
| B | 100 | 128 | 0.928 ± 0.005 | 0.83 ± 0.03 | 68 ± 3 |
| B | 100 | 256 | 0.936 ± 0.004 | 0.85 ± 0.02 | 104 ± 4 |
| B | 100 | 512 | 0.941 ± 0.004 | 0.87 ± 0.02 | 143 ± 5 |
| B | 100 | 1024 | 0.941 ± 0.004 | 0.87 ± 0.02 | 271 ± 7 |

### 7.2 Table 8 — detection performance

| Method | AUC-ROC | Precision | Recall | F1 | Fidelity |
|---|---|---|---|---|---|
| Gaspar et al. | 0.912 ± 0.004 | 0.781 ± 0.009 | 0.744 ± 0.011 | 0.762 ± 0.010 | 0.881 ± 0.006 |
| EXAI | 0.918 ± 0.005 | 0.796 ± 0.008 | 0.752 ± 0.010 | 0.773 ± 0.009 | 0.869 ± 0.007 |
| VGGM | 0.941 ± 0.004 | 0.812 ± 0.007 | 0.803 ± 0.008 | 0.807 ± 0.007 | n/a |
| Double Layer Detection | 0.947 ± 0.003 | 0.828 ± 0.006 | 0.811 ± 0.007 | 0.819 ± 0.006 | n/a |
| GraphCH | 0.958 ± 0.003 | 0.844 ± 0.005 | 0.836 ± 0.006 | 0.840 ± 0.005 | n/a |
| LAN | 0.966 ± 0.002 | 0.861 ± 0.005 | 0.849 ± 0.006 | 0.855 ± 0.005 | n/a |
| **ShadowDetectAI** | **0.987 ± 0.002** | **0.902 ± 0.004** | **0.891 ± 0.005** | **0.896 ± 0.004** | **0.943 ± 0.003** |

Paired one-sided Wilcoxon signed-rank test against LAN, ten paired runs:
W = 55, exact one-sided p = 0.00098.  The ten paired values are stored in
`results/tables/table08_wilcoxon_shadowdetectai_vs_lan.csv`.

### 7.3 Table 9 — confusion matrix (seed 42, threshold of Eq. (33))

TP = 8, FN = 1, FP = 1, TN = 20,590.  Total 20,600 = the test-partition
window count.  Single-seed precision and recall are both 8/9 = 0.889; the
ten-run means are 0.902 and 0.891.

### 7.4 Table 10 — channel attribution

| Channel | Mean absolute Shapley attribution (proportion) | SD |
|---|---|---|
| Application usage sequencing | 0.412 | 0.03 |
| Keystroke timing proxy channel | 0.365 | 0.03 |
| Mouse interaction proxy channel | 0.223 | 0.02 |
| Total | 1.000 | — |

Pairwise mean Pearson correlations on the training partition: 0.31
(keystroke–mouse, 95 % CI 0.27–0.35), 0.29 (keystroke–application,
0.25–0.33), 0.27 (mouse–application, 0.23–0.31); all normalised mutual
information values below 0.35.

### 7.5 Table 13 — analyst triage

| Condition | Alerts/participant | Participants | Mean triage time (min) | SD | Disposition accuracy |
|---|---|---|---|---|---|
| No attribution (aggregate anomaly score only) | 10 | 10 | 4.7 | 1.1 | 0.73 ± 0.09 |
| With Shapley attribution (top-five panel) | 10 | 10 | 2.1 | 0.6 | 0.81 ± 0.07 |
| Difference | — | — | −2.6 (−55.3 %) | — | +0.08 |

Paired two-sided Wilcoxon signed-rank test: W = 0, n = 10, p = 0.002.

### 7.6 Table 14 — LOIO cross-validation

| Fold | Held-out identity | AUC-ROC | Precision | Recall | F1 |
|---|---|---|---|---|---|
| 1 | CERT-M01 | 0.989 ± 0.003 | 0.914 ± 0.008 | 0.903 ± 0.009 | 0.908 ± 0.008 |
| 2 | CERT-M02 | 0.976 ± 0.005 | 0.881 ± 0.011 | 0.869 ± 0.012 | 0.875 ± 0.011 |
| 3 | CERT-M03 | 0.983 ± 0.004 | 0.896 ± 0.009 | 0.884 ± 0.010 | 0.890 ± 0.009 |
| 4 | CERT-M04 | 0.972 ± 0.006 | 0.871 ± 0.012 | 0.858 ± 0.013 | 0.864 ± 0.012 |
| 5 | CERT-M05 | 0.987 ± 0.002 | 0.902 ± 0.004 | 0.891 ± 0.005 | 0.896 ± 0.004 |
| Mean ± SD | — | 0.981 ± 0.008 | 0.893 ± 0.019 | 0.881 ± 0.019 | 0.887 ± 0.019 |

---

## 8. Figures

| Figure | Generated by | Source of the numbers |
|---|---|---|
| Fig. 1, 2, 3, 4, 5, 6 | artwork (vector) | `results/figures/`, authored |
| Fig. 7 (ROC) | `scripts/05_evaluate.py` + `figures/make_figures.py` | test-partition scores |
| Fig. 8 (channel contribution) | `scripts/09_channel_contribution.py` | `results/tables/table10_channel_attribution.csv` |
| Fig. 9 (drift) | `scripts/12_drift_and_calibration.py` | test-partition scores per window |
| Fig. 10 (alert volume) | `scripts/12_drift_and_calibration.py` | test-partition scores per window |
| Fig. 11 (scalability) | `scripts/13_scalability.py` | wall-clock timings |
| Fig. 12 (fidelity) | `scripts/05_evaluate.py` | test-partition attribution fidelity |
| Fig. 13 (ablation) | `scripts/10_ablation.py` | `results/tables/table11_ablation.csv` |
| Fig. 14 (triage time) | `scripts/15_triage_analysis.py` | `triage_study/results/per_participant_times.csv` |

Figures 8, 12, 13 and 14 are generated **from** the result CSVs so that the
figure and the table cannot drift apart.

---

## 9. What this repository cannot reproduce

Stated plainly, as required.

1. **The triage study's participant-level data.**  The 20-alert pool, the
   counterbalancing schedule and the analysis code are provided, but the
   per-participant timings and dispositions were collected in a live study
   and are not redistributed.  Table 13 and Figure 14 are therefore
   regenerated from `triage_study/results/per_participant_*.csv`, which must
   be supplied.  The shipped `results/tables/table13_triage_results.csv`
   holds the paper's reported values.
2. **The manual behavioural-driver annotations** used for the top-3
   contribution recall.  The metric is implemented; the annotation file must
   be supplied.
3. **The exact run-to-run numbers.**  The reported means and standard
   deviations depend on the GPU, the library versions and the wall-clock
   non-determinism of cuDNN kernels.  `compare_results.py` uses a tolerance
   of 0.02 on the reported metrics, which is of the same order as the
   standard deviations the paper itself reports.

---

## 10. Known inconsistencies in the paper

Found while writing the code, listed rather than silently smoothed over.

| # | Where | Issue | How this repository handles it |
|---|---|---|---|
| 1 | Table 7, Gaspar et al. row | the learning-rate grid is `{0.0001, 0.001}` but the selected value is `0.0003`, which is not in the grid | `0.0003` is added to the grid; the reported selection is kept. Asserted by `tests/test_config_integrity.py`. |
| 2 | Table 5 note vs. Section 6.1 | the note refers to time-based split fractions of 72.2 / 11.1 / 16.7 %, which Section 6.1 does not state | both denominators are documented in §1.1 above; the window-count figures are used |
| 3 | Section 6.1 vs. Table 5 | 3,200 + 690 + 690 = 4,580 node entries, but 4,000 employees appear in more than one partition | treated as a node-occurrence count, not a distinct-identity count; see §1.1 |
| 4 | Eq. (11)/(12) vs. prose | the paper's prose used "dwell time" and "flight time" while the equations were already inter-record intervals | the code follows the equations; the prose was aligned to them in the revised manuscript |
