# Architecture

```
activity logs (logon, file, email, device, http)
        |
        |  cert_loader.load_events            Section 6.1
        v
   event table  (timestamp, user, activity, resource, channel)
        |
        |  sessionize.sessionize              Section 4.1.1
        v
   session table (+ session_id)
        |
        |  windowing.assign_windows (Delta = 24 h)
        v
   windowed events (+ window_index)
        |
        +--> features/keystroke_timing_proxy  Eqs. (11)-(13)   -> 8 values
        +--> features/mouse_interaction_proxy Eq. (14)         -> 6 values
        +--> features/application_sequence    Eq. (15)         -> 64 values
        |
        |  encoder.MultiChannelBehavioralEncoder  Eq. (16)
        v
   fused embedding f_t  (d = 128)
        |
        |  graph_builder.build_window_graph    Eqs. (4)-(6)
        v
   dynamic interaction graph G_t = (users + resources, edges)
        |
        |  memory.MemoryModule                 Eqs. (17)-(18)
        |  temporal_attention.TemporalAttention Eqs. (19)-(21)
        v
   temporal embedding z_u(t)
        |
        |  classifier.UserClassifier           Eqs. (22)-(23)
        v
   logit z_{u,t}  ->  probability p_{u,t}
        |
        |  explain.KernelShapExplainer         Eqs. (25)-(28)
        v
   ranked per-feature contributions
        |
        |  calibration.*                       Eqs. (31)-(35)
        v
   analyst-facing risk score + deviation index
```

## Module map

| Package | Responsibility |
|---|---|
| `data/` | loading, sessionisation, windowing, labelling, partitioning, LOIO folds, graph construction, materialisation |
| `features/` | the three proxy channels and their fusion |
| `models/` | encoder, TGN memory, temporal attention, classifier, composite loss, model factories |
| `explain/` | KernelSHAP, ranking, fidelity, top-k recall |
| `calibration/` | Platt scaling, PSI drift, adaptive threshold, alert fusion |
| `baselines/` | the six comparison baselines, implemented from scratch |
| `training/` | trainer, seeds, checkpoints |
| `evaluation/` | metrics, confusion matrix, channel analysis, drift, scalability, leakage checks |
| `triage/` | alert pool, counterbalanced allocation, analysis |
| `utils/` | seeding, IO, logging, YAML config, plotting style |

## Data flow invariants

1. **No hardware telemetry.** The loader exposes only the five activity logs
   and `assert_no_hardware_fields` rejects any column whose name contains
   `press`, `release`, `keycode`, `x_coord`, `y_coord`, `pointer`,
   `pressure`, `click_x` or `click_y`.
2. **Cold-start memory.** `MemoryStore.reset_memory()` is called at every
   partition boundary; `tests/test_memory_reset.py` asserts that the memory
   norm is exactly zero afterwards.
3. **Disjoint partitions.** `split_windows` assigns each window to exactly one
   partition; `tests/test_partition_no_overlap.py` asserts no overlap.
4. **Determinism.** `set_seed` seeds Python, NumPy and torch and enables
   cuDNN determinism.  The ten paper seeds are defined once, in
   `utils/seeds.py`.
