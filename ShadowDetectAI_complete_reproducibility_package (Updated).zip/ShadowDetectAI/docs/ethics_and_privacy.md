# Ethics and privacy

This repository handles a dataset that contains **behavioural personal data**
about simulated employees, and it implements an analyst-facing attribution
layer.  Both facts carry obligations.

## The data

* The CMU CERT r6.2 corpus is a **simulation**.  It contains 4,000 synthetic
  employee identities over 18 months.  No real person's activity is recorded
  in it.  Nevertheless, the *shape* of the data — per-user behavioural traces
  over time — is the shape of real employee monitoring, and the deployment
  questions below are real.
* **The corpus is not committed to this repository.**  `data/raw/` is in
  `.gitignore`.  `data/download.py` fetches it from the official KiltHub
  record, which requires the user to accept the dataset terms themselves.
* The SHA256 digest is `[UNVERIFIED]` in `data/checksums.sha256` because no
  digest is published.  Record your own copy's digest so the check is
  meaningful for later runs.

## What is and is not collected

The pipeline reads exactly five activity logs and nothing else:

| Log | Feeds |
|---|---|
| `logon` | keystroke timing proxy channel |
| `file`, `email`, `http` | application usage sequencing channel |
| `device` | mouse interaction proxy channel |

**No key press, key release, pointer-coordinate or click-pressure telemetry
is read, transmitted or stored at any stage.**  None of the hardware sensor
categories listed as explicitly excluded in Table 3 is read, transmitted or
stored at any stage of the pipeline, and the deployment therefore requires no
collection of key press, key release, pointer-coordinate or click-pressure
data.  This is enforced by `tests/test_no_hardware_fields.py`.

## Data minimisation

Only the statistical feature vectors extracted from the activity log records
are retained.  Neither hardware key press or key release telemetry nor
pointer-coordinate or click-pressure telemetry is retained.

## Deployment obligations (from the manuscript's Ethical Considerations)

1. The session-level timing proxies, the device-event statistics and the
   application-use sequences **may constitute behavioural personal data**
   under GDPR, CCPA and equivalent frameworks.  The classification is
   context- and jurisdiction-dependent and must be assessed by qualified
   legal counsel before deployment.
2. Because deployment is normally in an organisational context, employees
   must be explicitly informed of it, and the organisation must have a
   documented, existing basis for the collection and a basis for consent
   under the relevant law.
3. Technical measures must implement data minimisation — see above.
4. **The Shapley attribution output must not be used as the sole basis for
   punitive action.**  It should be checked for compliance with the
   restrictions on solely automated decision-making (GDPR Article 22 and
   equivalents) before use.
5. In regulated industries (healthcare, finance) a Data Protection Impact
   Assessment or equivalent review may be required before deployment.

## The triage study

The analyst-triage study used ten graduate researchers as analyst proxies.
Only **de-identified per-participant CSVs** — participant id, condition,
elapsed seconds and correctness flag — are intended for release.  No alert
content, no user identifier and no free text from the interface is included.

Before releasing anything from `triage_study/`, confirm your ethics approval
or exemption covers it.  This is the authors' responsibility, not the
repository's.

## Known limitations the manuscript acknowledges

* The keystroke and mouse channels are **proxies**, not biometric
  measurements (see `docs/data_and_proxy_mapping.md`).
* The triage results come from a **simulated** environment with researcher
  proxies, not a live SOC with trained analysts; they are a proof of concept
  and not an operationally validated benchmark.
* All validation-partition triage stimuli derive from a **single** malicious
  insider identity, which is stated as a limitation of the stimulus pool.
* The test partition holds **nine** malicious windows from one identity, so
  the threshold-dependent metrics are indicative rather than definitive.
