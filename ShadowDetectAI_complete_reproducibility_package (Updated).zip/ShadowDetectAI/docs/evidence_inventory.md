# Evidence inventory and limits of this release

## Scope reviewed
This inventory is based on the supplied manuscript `V3-Insider-Threat-Profiling_Highlighted.docx` and repository archive. It distinguishes published target values from original experimental artifacts.

## Available
- The ten seeds specified in manuscript Table 6: `42, 123, 256, 512, 1024, 999, 777, 333, 111, 888`.
- Ten paired AUC-ROC values for ShadowDetectAI and LAN, printed in the note below manuscript Table 8. These are transcribed in `results/raw_runs/paper_reported_seed_level_auc.csv` and explicitly labeled as paper-transcribed values, not raw outputs.
- Aggregate target tables in `results/tables/`, including Table 13 triage summaries.
- A triage schedule, decision rubric, alert pool schema, and interface/harness.

## Not supplied and therefore not reconstructed
- Raw per-seed training logs, model checkpoints, model weights, logits, event/window predictions, per-seed confusion matrices, and per-seed precision/recall/F1/fidelity.
- The original per-participant triage times and correctness/disposition records.
- The raw CERT r6.2 corpus, which the manuscript says must be obtained separately under its access terms.

The manuscript's Code Availability statement says per-seed checkpoints, raw inference outputs, and trained weights are retained by the authors and available on reasonable request; it likewise says participant-level triage records are available on request subject to ethics constraints. Those artifacts are not present in the supplied archive. Contact the authors to obtain them. They cannot be recreated faithfully from mean ± standard deviation summaries.

## How to interpret the files
- `results/tables/`: paper-reported comparison targets, not reproduced measurements.
- `results/raw_runs/paper_reported_seed_level_auc.csv`: the limited per-seed AUC pairs explicitly printed in the paper; not raw run logs and not independently verified.
- `results/raw_runs/evidence_manifest.json`: machine-readable availability declaration.
- `results/raw_runs/per_seed_results_template.csv` and `per_seed_artifact_manifest_template.json`: one row per paper seed with unavailable metrics left blank, to be populated only from actual run artifacts.
- `results/raw_runs/`: no original training logs or checkpoints were supplied.
- `triage_study/results/per_participant_times.csv` and `per_participant_accuracy.csv`: empty-value data-collection templates; blank values mean unavailable, not zero.
- `results/reproduced/`: remains empty until the pipeline is actually run against the CERT corpus and required dependencies.

## Reproduction versus transcription
A reproduction requires executing the code on the corpus and generating predictions from trained models. Copying manuscript values into target CSVs is not reproduction. The repository intentionally keeps these two kinds of evidence separate.
