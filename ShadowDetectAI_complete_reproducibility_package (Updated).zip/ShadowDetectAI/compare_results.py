#!/usr/bin/env python3
"""Compare the reproduced results against the paper's reported values.

Loads ``results/tables`` (the numbers printed in the paper) and
``results/reproduced`` (the numbers this run produced), prints the absolute
difference for every comparable value, and flags any deviation above the
stated tolerance.

    python compare_results.py --tolerance 0.02
    python compare_results.py --expected results/tables --reproduced results/reproduced
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parent

#: Which numeric columns to compare for each table, and the tolerance that
#: applies to each column where it differs from the global default.
#: The tolerance is 0.02 for every reported metric because the paper reports
#: standard deviations across ten runs of the same order as the deviation
#: between two independent runs of the same configuration.
NUMERIC_COLUMNS = {
    "auc_roc", "auc_roc_mean", "auc_roc_std", "precision", "precision_std",
    "recall", "recall_std", "f1", "f1_std", "fidelity", "fidelity_mean",
    "fidelity_std", "attribution_fidelity", "top3_recall", "latency_ms_per_user",
    "mean_triage_time_min", "sd_across_participants", "count", "users",
    "windows", "malicious_windows", "malicious_identities", "split_window_pct",
    "mean_abs_shapley_proportion", "pearson_mean", "normalized_mi",
    "val_auc_roc", "training_seconds_per_step", "inference_seconds",
    "attribution_ms_per_user",
    # Table 4 and Table 10a
    "top3_recall_std", "latency_std", "pearson_ci_low", "pearson_ci_high",
    "sd_across_detected_malicious_users",
    # Table 7's grid columns
    "learning_rate", "num_layers", "hidden_dim", "num_heads", "window_hours",
    "dropout", "n_components", "latent_dim",
    # diagnostics written alongside the tables
    "tau_0", "psi", "threshold", "n_users",
    # the paired Wilcoxon table
    "shadowdetectai_auc", "lan_auc",
    # Table 12 is a prose table, but one of its cells ("Timed trials per
    # participant" = 20) is a bare number and is therefore comparable.
    "value",
    # Table 13 and the per-seed detail files
    "alerts_per_participant", "n_runs", "mean", "std",
    "participants", "disposition_accuracy",
}


def read_csv(path: Path) -> List[Dict[str, str]]:
    with open(path, "r", encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


_LEADING_NUMBER = re.compile(r"^[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?")


def to_float(value: str) -> Optional[float]:
    """Parse a cell as a number.

    A strict parse is tried first.  Failing that, a **leading** number is
    taken, which is what makes the paper's compound cells comparable:
    ``"0.73 +/- 0.09"`` compares as 0.73 and ``"-2.6 (-55.3 %)"`` as -2.6.
    Text that does not begin with a number - ``"Ten; eight from ..."`` - is
    not a number and is not compared.
    """
    if value is None:
        return None
    text = str(value).strip()
    try:
        return float(text)
    except (TypeError, ValueError):
        pass
    match = _LEADING_NUMBER.match(text)
    if match:
        try:
            return float(match.group(0))
        except (TypeError, ValueError):
            return None
    return None


def key_columns(rows: List[Dict[str, str]]) -> List[str]:
    """Pick the columns that identify a row, in preference order."""
    for candidate in (["method"], ["configuration"], ["condition"], ["fold"],
                      ["baseline"], ["panel", "background_samples",
                                     "coalition_samples"],
                      ["pair"], ["channel"], ["cell"], ["partition"],
                      ["metric", "method"], ["design_element"]):
        if rows and all(c in rows[0] for c in candidate):
            return candidate
    return list(rows[0].keys())[:1] if rows else []


def compare(expected: List[Dict[str, str]], reproduced: List[Dict[str, str]],
            tolerance: float) -> Tuple[List[Tuple[str, str, float, float, bool]],
                                       List[str], List[str]]:
    """Return the per-value differences, the unmatched keys and the gaps.

    A value that cannot be compared is reported as **missing** rather than
    skipped.  Silently skipping it would let a table whose columns do not
    line up with the target pass as if it had been reproduced, which is the
    one failure mode this script exists to prevent.
    """
    keys = key_columns(expected)
    idx = {}
    for row in reproduced:
        idx[tuple(str(row.get(k, "")).strip() for k in keys)] = row

    diffs: List[Tuple[str, str, float, float, bool]] = []
    unmatched: List[str] = []
    missing: List[str] = []
    for row in expected:
        k = tuple(str(row.get(c, "")).strip() for c in keys)
        other = idx.get(k)
        if other is None:
            unmatched.append(" | ".join(k))
            continue
        for col, ev in row.items():
            if col not in NUMERIC_COLUMNS:
                continue
            a = to_float(ev)
            b = to_float(other.get(col, ""))
            if a is None:
                continue
            if b is None:
                missing.append(f"{' | '.join(k)} :: {col} "
                               f"(paper {a}, reproduced column absent or not numeric)")
                continue
            d = abs(a - b)
            diffs.append((" | ".join(k), col, a, b, d > tolerance))
    return diffs, unmatched, missing


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--expected", default=str(ROOT / "results" / "tables"))
    ap.add_argument("--reproduced", default=str(ROOT / "results" / "reproduced"))
    ap.add_argument("--tolerance", type=float, default=0.02)
    ap.add_argument("--strict", action="store_true",
                    help="exit non-zero when any value exceeds the tolerance")
    args = ap.parse_args()

    exp_dir, rep_dir = Path(args.expected), Path(args.reproduced)
    if not exp_dir.exists():
        print(f"[FAIL] {exp_dir} does not exist")
        return 1
    if not rep_dir.exists() or not any(rep_dir.glob("*.csv")):
        print(f"[warn] no reproduced results in {rep_dir}; run evaluate_all.py first.")
        print("       The paper's reported values are listed below for reference.")
        for f in sorted(exp_dir.glob("*.csv")):
            print(f"  {f.name}")
        return 0

    n_flagged = 0
    n_compared = 0
    n_missing = 0
    for exp_file in sorted(exp_dir.glob("*.csv")):
        rep_file = rep_dir / exp_file.name
        if not rep_file.exists():
            print(f"\n### {exp_file.name}: NOT REPRODUCED (no matching file)")
            continue
        diffs, unmatched, missing = compare(read_csv(exp_file), read_csv(rep_file),
                                           args.tolerance)
        flagged = [d for d in diffs if d[4]]
        n_flagged += len(flagged)
        n_compared += len(diffs)
        n_missing += len(missing)
        status = "OK" if not flagged else f"{len(flagged)} DEVIATION(S)"
        if missing:
            status += f", {len(missing)} MISSING"
        if not diffs and not missing:
            status = "no comparable numeric values (text-only table)"
        print(f"\n### {exp_file.name}: {len(diffs)} values compared, {status}")
        for key, col, a, b, _ in diffs:
            mark = "  " if abs(a - b) <= args.tolerance else "**"
            print(f"  {mark} {key:<34} {col:<24} paper={a:<10} reproduced={b:<10} "
                  f"diff={abs(a-b):.4f}")
        for m in missing:
            print(f"  -- MISSING  {m}")
        for u in unmatched:
            print(f"  -- {u}: no reproduced row")

    print(f"\n=== {n_compared} values compared, {n_flagged} above the tolerance of "
          f"{args.tolerance}, {n_missing} missing ===")
    if n_missing:
        print("    A missing value means the reproduced table does not carry that")
        print("    column, or carries an empty cell.  It has NOT been reproduced.")
    if n_flagged and args.strict:
        return 1
    if n_missing and args.strict:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
