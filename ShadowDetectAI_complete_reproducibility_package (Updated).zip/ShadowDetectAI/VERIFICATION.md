# Verification report

What was actually executed when this package was assembled, and what was not.
Everything below is reproducible from the repository.

## Environment used for the final package audit (2026-10-29)

| | |
|---|---|
| Python | 3.13 |
| Available | NumPy, pandas, SciPy, scikit-learn, PyYAML, PyTorch CPU, pytest, matplotlib, SHAP |
| Not available | `torch-geometric` |
| GPU | none |
| CERT r6.2 corpus | **not present** — the KiltHub record requires manual acceptance of dataset terms |

## Checks executed for this package version

| Check | Command | Result |
|---|---|---|
| Unit tests | `PYTHONPATH=src python -m pytest -q` | **75 passed, 0 failed** |
| Python compilation | `python -m compileall -q src scripts tests *.py` | passed |
| Shell syntax | `bash -n` for every `*.sh` file | passed |
| Download CLI | `python data/download.py --help` | passed |
| Evidence audit | `python validate_evidence.py` | passed |
| End-to-end model reproduction | not run | requires CERT r6.2 corpus; full GPU training not performed |

The tests validate code-level behavior only. They do **not** establish that the paper's results have been reproduced. `torch-geometric` is listed in the environment requirements but is not installed in this audit environment; the CERT corpus and original author-held artifacts are also absent.

## What was not executed

* **No model was trained on CERT r6.2.** The corpus is not included in the supplied archive.
* **No original author-held checkpoints, raw inference outputs, or training logs were available.**
* **No participant-level triage results were available.** The distributed CSVs are blank data-collection templates.
* The analyst-triage interface was not run as a real human-participant study.

## Consequence for the numbers

No numeric result in `results/reproduced/` is claimed as a new experimental result. `results/tables/` holds paper-reported targets. `results/raw_runs/paper_reported_seed_level_auc.csv` contains only the ten AUC pairs explicitly printed in the paper, labeled as transcriptions rather than raw runs. Other per-seed metrics and participant-level triage values are not derivable from the paper's aggregates and are not fabricated.

## Defects found and fixed while assembling this package

Recorded because they are the kind of thing that silently produces wrong
numbers rather than errors.

| # | Where | Defect | Fix |
|---|---|---|---|
| 1 | `features/keystroke_timing_proxy.py`, `features/mouse_interaction_proxy.py` | `astype("int64")` on a datetime column returns **microseconds** under pandas 3, so every interval was 1000× too small | force `datetime64[ns]` explicitly |
| 2 | `features/keystroke_timing_proxy.py` | Eq. (11) returned `T_u − 2` dwell values instead of `T_u − 1` | `np.diff(t)` |
| 3 | `explain/kernel_shap.py` | the Shapley regression **weights were computed and then discarded** — the fit was an unweighted least squares | weighted least squares with the Shapley kernel |
| 4 | `explain/kernel_shap.py` | the weights were derived from a *randomly sampled* subset size rather than the coalition's own size | read the size from the coalition |
| 5 | `explain/kernel_shap.py` | the regression had **no intercept**, so the background value was forced into the feature coefficients | add the intercept; `explain()` now returns the baseline |
| 6 | `explain/fidelity.py` | Eq. (30) compared `Σφ` against the logit, but `Σφ` excludes the baseline | `fidelity(Σφ, z, φ_0)` |
| 7 | `scripts/08_shap_sensitivity.py` | the fidelity expression was `1 − \|Σφ\|/\|Σφ\|`, which is **always 0** | compute Eq. (30) against the model's own logit |
| 8 | `scripts/08_shap_sensitivity.py` | the KernelSHAP value function returned **zeros** instead of the model's predictions | use the trained model |
| 9 | `scripts/08_shap_sensitivity.py` | it read `data/processed/fused_features.npz`, a file **nothing creates** | build the instances and the background from the materialised frames |
| 10 | `compare_results.py` | a value the reproduced table did not carry was **skipped silently**, so a mismatched table passed as a reproduction | report it as **MISSING**; `tests/test_compare_results.py` locks this in |
| 11 | `scripts/05`–`15` | they wrote into `results/tables/`, **overwriting the paper's target values** on a run | every script now defaults to `results/reproduced/` |
| 12 | `scripts/05`–`11` | the tables were written in a long format that the target tables do not use, so the comparison would have compared nothing | all tables are now written in the paper's own layout |
| 13 | `scripts/05`, `scripts/10` | the operating threshold was a hard-coded `0.5` | the threshold of Eq. (33), fitted on the validation partition |
| 14 | `scripts/14` | wrote no Table 12 | it now writes it, and self-checks the counterbalancing |
| 15 | `triage/allocation.py` | the condition assignment was sampled per participant, so an alert could appear in the attribution condition zero or ten times | a balanced cyclic rotation: each alert appears in each condition exactly five times |
| 16 | `data/materialize.py` | an unbalanced parenthesis (a syntax error) | fixed; caught by the full-tree syntax sweep |
| 17 | `data/materialize.py` | the new `partition` tag would have been read as a numeric feature column | the feature columns are selected by dtype |
| 18 | `scripts/14` | the alert CSVs it reads were **never written by anything** | `scripts/05` now writes them |
| 19 | `data/preprocess.py` | the partition tag was missing from the feature tables | added, so the training-partition analyses can select their rows |
| 20 | `scripts/12` | it read the checkpoint from `results/checkpoints/` while the trainer writes to `results/raw_runs/` | the path is corrected and its existence is reported |

## How to verify this package yourself

```bash
pip install -r requirements.txt
python -m pytest tests -q                       # the full suite
python -m compileall -q src scripts tests *.py  # every file parses
bash scripts/99_reproduce_all.sh --skip-download # the full pipeline
python compare_results.py --tolerance 0.02      # the comparison
```

On a machine with the corpus and a GPU, the last two commands are the real
test of this package: they replace the paper's reported numbers with the
numbers this code produces, and report the difference.


## Supplementary evidence audit (2026-10-29)

The supplied manuscript and archive were checked specifically for the requested original per-seed results and participant-level triage data.

- Added `docs/evidence_inventory.md` to distinguish actual artifacts from paper-reported target values.
- Added `results/raw_runs/paper_reported_seed_level_auc.csv` with only the ten paired ShadowDetectAI/LAN AUC-ROC values explicitly printed in the Table 8 note. Every row is labeled `transcribed_from_paper_not_raw_run`; this is a transcription, not a model rerun.
- Added `results/raw_runs/evidence_manifest.json` documenting which artifacts are and are not supplied.
- Added `triage_study/results/README.md`; the two participant-level CSVs remain blank templates. The manuscript reports only group-level Table 13 summaries and says the underlying participant-level records are available from the authors upon request subject to ethics constraints.
- No synthetic per-seed metrics, checkpoints, logits, predictions, confusion matrices, or participant observations were fabricated. Original training logs/checkpoints and participant-level triage data were absent from the supplied archive, so those files cannot honestly be added without obtaining the source artifacts.


## Final package integrity fixes (2026-10-29)

- Fixed the dataset downloader's argument parser invocation (`parse_args`).
- Registered all six baseline implementations and made them conform to the common baseline base class.
- Corrected the baseline import-integrity test to permit standard-library and package-relative imports.
- Reinitialised the proposed model for every seed so each reported seed run starts from independent weights rather than continuing from the previous seed.
- Changed evaluation to fail when a required checkpoint is missing instead of silently skipping a seed or evaluating an untrained model.
- Changed triage analysis to stop on blank template fields instead of attempting to calculate Table 13 from missing data.
- Corrected dataset download/extract/preprocess instructions to match the actual command-line interfaces.
- Re-ran the complete available test suite: 75 passed, 0 failed. The end-to-end experiment remains unrun because the dataset is absent.
