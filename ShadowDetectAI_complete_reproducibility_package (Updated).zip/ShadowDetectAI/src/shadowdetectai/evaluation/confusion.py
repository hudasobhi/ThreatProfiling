"""Confusion matrix reporting (paper Table 9)."""
from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np


def confusion_matrix(y_true: Sequence[int], scores: Sequence[float],
                     threshold: float = 0.5) -> Dict[str, int]:
    """The raw counts of Table 9: TP, FP, FN and TN."""
    y = np.asarray(y_true).astype(int)
    p = (np.asarray(scores, dtype=np.float64) >= threshold).astype(int)
    return {
        "TP": int(((p == 1) & (y == 1)).sum()),
        "FP": int(((p == 1) & (y == 0)).sum()),
        "FN": int(((p == 0) & (y == 1)).sum()),
        "TN": int(((p == 0) & (y == 0)).sum()),
    }


def confusion_frame(y_true: Sequence[int], scores: Sequence[float],
                    threshold: float = 0.5) -> "object":
    """Render the confusion matrix as the 2x2 table of Table 9."""
    import pandas as pd

    c = confusion_matrix(y_true, scores, threshold)
    return pd.DataFrame(
        [["Actual Positive (Malicious)", f"TP = {c['TP']}", f"FN = {c['FN']}"],
         ["Actual Negative (Benign)", f"FP = {c['FP']}", f"TN = {c['TN']}"]],
        columns=["Actual / Predicted", "Predicted Positive", "Predicted Negative"])


def class_report(y_true: Sequence[int], scores: Sequence[float],
                 threshold: float = 0.5) -> Dict[str, Dict[str, float]]:
    """Per-class precision, recall and F1."""
    from sklearn.metrics import precision_recall_fscore_support

    y = np.asarray(y_true).astype(int)
    p = (np.asarray(scores, dtype=np.float64) >= threshold).astype(int)
    pr, rc, f1, sup = precision_recall_fscore_support(
        y, p, labels=[0, 1], zero_division=0)
    return {
        "benign": {"precision": float(pr[0]), "recall": float(rc[0]),
                   "f1": float(f1[0]), "support": int(sup[0])},
        "malicious": {"precision": float(pr[1]), "recall": float(rc[1]),
                      "f1": float(f1[1]), "support": int(sup[1])},
    }
