"""Robustness to behavioural drift (paper Section 6.3, Figures 9 and 10).

Figure 9 tracks detection accuracy across successive weekly windows while a
subset of test users undergo gradual, benign role changes.  Figure 10
compares the alert volume of a fixed threshold with the adaptive PSI-driven
threshold of Eq. (33) during a simulated organisational reorganisation.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np

from ..calibration.adaptive_threshold import AdaptiveThreshold
from ..calibration.psi_drift import PSIReference


@dataclass
class DriftResult:
    """Per-window detection accuracy for one method."""

    method: str
    windows: List[int]
    accuracy: List[float]

    def as_dict(self) -> Dict[str, object]:
        return {"method": self.method, "windows": self.windows,
                "accuracy": self.accuracy}


def accuracy_per_window(window_index: Sequence[int], labels: Sequence[int],
                        scores: Sequence[float], threshold: float = 0.5
                        ) -> Dict[int, float]:
    """Detection accuracy inside each evaluation window."""
    win = np.asarray(window_index)
    y = np.asarray(labels).astype(int)
    p = (np.asarray(scores, dtype=np.float64) >= threshold).astype(int)
    out: Dict[int, float] = {}
    for w in np.unique(win):
        m = win == w
        out[int(w)] = float((p[m] == y[m]).mean())
    return out


def drift_curve(window_index: Sequence[int], labels: Sequence[int],
                scores: Sequence[float], method: str, threshold: float = 0.5
                ) -> DriftResult:
    """Build one method's drift curve (Figure 9)."""
    acc = accuracy_per_window(window_index, labels, scores, threshold)
    windows = sorted(acc)
    return DriftResult(method=method, windows=windows,
                       accuracy=[acc[w] for w in windows])


def alert_volume_per_window(window_index: Sequence[int], scores: Sequence[float],
                            threshold: float) -> Dict[int, int]:
    """Number of triggered alerts inside each window (Figure 10)."""
    win = np.asarray(window_index)
    p = (np.asarray(scores, dtype=np.float64) >= threshold).astype(int)
    out: Dict[int, int] = {}
    for w in np.unique(win):
        out[int(w)] = int(p[win == w].sum())
    return out


def adaptive_alert_volume(window_index: Sequence[int], scores: Sequence[float],
                           reference_scores: Sequence[float],
                           base_threshold: float,
                           lambda_drift: float = 0.1,
                           n_bins: int = 10) -> Dict[int, int]:
    """Alert volume under the adaptive threshold of Eq. (33)."""
    win = np.asarray(window_index)
    s = np.asarray(scores, dtype=np.float64)
    ref = PSIReference.fit(reference_scores, n_bins=n_bins)
    policy = AdaptiveThreshold(tau_0=base_threshold, lambda_drift=lambda_drift)
    out: Dict[int, int] = {}
    for w in np.unique(win):
        m = win == w
        psi = ref.compute(s[m])
        tau = policy.apply(psi)
        out[int(w)] = int((s[m] >= tau).sum())
    return out
