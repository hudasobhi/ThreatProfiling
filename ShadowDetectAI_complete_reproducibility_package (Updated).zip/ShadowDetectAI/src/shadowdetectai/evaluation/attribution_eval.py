"""Attribution fidelity of a trained detector (paper Section 4.3, Eq. 30).

This is the bridge between the training-side code and the explanation-side
code: it takes a trained model and the materialised partitions, and returns
the mean Eq. (30) fidelity over the flagged users of the test partition.

The background distribution is the benign training windows, as Table 6
specifies ("100 benign training windows (fixed)").
"""
from __future__ import annotations

from typing import Optional

import numpy as np

from ..explain.model_fidelity import attribution_fidelity


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(np.asarray(x, dtype=np.float64),
                                        -60.0, 60.0)))


def model_attribution_fidelity(model,
                               test_frame,
                               train_frame,
                               device,
                               n_background: int = 100,
                               n_coalitions: int = 512,
                               max_users: int = 20,
                               threshold: float = 0.5) -> Optional[float]:
    """Mean Eq. (30) fidelity over the flagged users of the test partition.

    Returns ``None`` when the computation is not possible - for instance
    when the training partition has fewer benign windows than the
    background size, or when the test partition holds no malicious window.
    """
    import torch

    train_labels = train_frame.labels.detach().cpu().numpy()
    benign = train_frame.features.detach().cpu().numpy()[train_labels == 0]
    if benign.shape[0] < n_background:
        return None
    background = benign[:n_background]

    test_labels = test_frame.labels.detach().cpu().numpy()
    test_features = test_frame.features.detach().cpu().numpy()

    with torch.no_grad():
        logits = []
        for start in range(0, len(test_labels), 512):
            chunk = torch.as_tensor(test_features[start:start + 512],
                                    dtype=torch.float32, device=device)
            node = chunk.unsqueeze(1)
            out = model({
                "features": chunk,
                "node_features": node,
                "neighbour_features": node,
                "neighbour_mask": torch.zeros((chunk.shape[0], 1), dtype=torch.bool,
                                              device=device),
                "label": torch.zeros(chunk.shape[0], dtype=torch.long, device=device),
                "window_index": torch.zeros(chunk.shape[0], dtype=torch.long,
                                            device=device),
            })
            logits.extend(out["logit"].detach().cpu().numpy().tolist())
    scores = _sigmoid(np.asarray(logits, dtype=np.float64))

    flagged = np.where((test_labels == 1) & (scores >= threshold))[0]
    if flagged.size == 0:
        flagged = np.where(test_labels == 1)[0]
    if flagged.size == 0:
        return None
    instances = test_features[flagged][:max_users]

    def score_fn(m: np.ndarray) -> np.ndarray:
        with torch.no_grad():
            tensor = torch.as_tensor(m, dtype=torch.float32, device=device)
            node = tensor.unsqueeze(1)
            out = model({
                "features": tensor,
                "node_features": node,
                "neighbour_features": node,
                "neighbour_mask": torch.zeros((tensor.shape[0], 1), dtype=torch.bool,
                                              device=device),
                "label": torch.zeros(tensor.shape[0], dtype=torch.long, device=device),
                "window_index": torch.zeros(tensor.shape[0], dtype=torch.long,
                                            device=device),
            })
            return _sigmoid(out["logit"].detach().cpu().numpy())

    result = attribution_fidelity(score_fn, instances, background,
                                   n_background=n_background,
                                   n_coalitions=n_coalitions,
                                   max_users=max_users)
    return float(result["fidelity_mean"])
