"""Scalability measurement (paper Section 6.3, Figure 11).

Figure 11 reports training and inference wall-clock time as the number of
active users in the interaction graph increases, and states that inference for
a single flagged user, including Shapley attribution, remains under 200
milliseconds even at the largest evaluated graph size.
"""
from __future__ import annotations

import time
from typing import Dict, List, Optional, Sequence

import numpy as np

import torch


def time_training_step(model: torch.nn.Module, batch: Dict[str, torch.Tensor],
                       optimizer: torch.optim.Optimizer,
                       n_steps: int = 5, device: Optional[torch.device] = None
                       ) -> float:
    """Mean seconds per training step at the current graph size."""
    device = device or next(model.parameters()).device
    model.train()
    times: List[float] = []
    for _ in range(n_steps):
        batch = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}
        t0 = time.perf_counter()
        out = model(batch)
        loss = out["logit"].mean()
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        if device.type == "cuda":
            torch.cuda.synchronize()
        times.append(time.perf_counter() - t0)
    return float(np.mean(times))


def time_inference(model: torch.nn.Module, batch: Dict[str, torch.Tensor],
                   device: Optional[torch.device] = None, n_steps: int = 5) -> float:
    """Mean seconds for one inference pass."""
    device = device or next(model.parameters()).device
    model.eval()
    times: List[float] = []
    with torch.no_grad():
        for _ in range(n_steps):
            batch = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}
            t0 = time.perf_counter()
            model(batch)
            if device.type == "cuda":
                torch.cuda.synchronize()
            times.append(time.perf_counter() - t0)
    return float(np.mean(times))


def time_attribution(explainer, instance: np.ndarray, n_runs: int = 3) -> float:
    """Mean seconds for one KernelSHAP attribution of a flagged user."""
    times: List[float] = []
    for _ in range(n_runs):
        t0 = time.perf_counter()
        explainer.explain(instance)
        times.append(time.perf_counter() - t0)
    return float(np.mean(times))


def count_parameters(model: torch.nn.Module) -> int:
    """Number of trainable parameters."""
    return int(sum(p.numel() for p in model.parameters() if p.requires_grad))


def estimate_flops(model: torch.nn.Module, batch: Dict[str, torch.Tensor]) -> Optional[int]:
    """Forward FLOPs, when ``fvcore`` is installed; otherwise ``None``.

    The paper does not report FLOPs, so this is an optional extra rather than
    a reported quantity.
    """
    try:
        from fvcore.nn import FlopCountAnalysis
    except ImportError:
        return None
    try:
        analysis = FlopCountAnalysis(model, batch)
        return int(analysis.total())
    except Exception:
        return None
