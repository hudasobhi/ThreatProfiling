"""Behavioural channel contribution analysis (paper Section 6.2, Table 10,
Figure 8).

Two statistics are computed on the training partition:

  * pairwise Pearson correlation coefficients between the three channel
    feature vectors, and
  * normalised mutual information between every pair.

The paper reports mean pairwise correlations of 0.31 (keystroke-mouse, 95% CI
0.27-0.35), 0.29 (keystroke-application, 0.25-0.33) and 0.27 (mouse-application,
0.23-0.31), with all normalised mutual information values below 0.35.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np


def pairwise_pearson(vectors: Dict[str, np.ndarray]) -> Dict[Tuple[str, str], float]:
    """Mean pairwise Pearson correlation between channel feature matrices."""
    from scipy.stats import pearsonr

    keys = list(vectors.keys())
    out: Dict[Tuple[str, str], float] = {}
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            a = np.asarray(vectors[keys[i]], dtype=np.float64).reshape(len(vectors[keys[i]]), -1)
            b = np.asarray(vectors[keys[j]], dtype=np.float64).reshape(len(vectors[keys[j]]), -1)
            n = min(a.shape[0], b.shape[0])
            if n < 3:
                out[(keys[i], keys[j])] = float("nan")
                continue
            corrs = []
            for col in range(min(a.shape[1], b.shape[1])):
                if a[:, col].std() < 1e-12 or b[:, col].std() < 1e-12:
                    continue
                r, _ = pearsonr(a[:n, col], b[:n, col])
                if not np.isnan(r):
                    corrs.append(float(r))
            out[(keys[i], keys[j])] = float(np.mean(corrs)) if corrs else float("nan")
    return out


def pairwise_normalized_mi(vectors: Dict[str, np.ndarray]) -> Dict[Tuple[str, str], float]:
    """Normalised mutual information between channel feature blocks."""
    from sklearn.feature_selection import mutual_info_regression

    keys = list(vectors.keys())
    out: Dict[Tuple[str, str], float] = {}
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            a = np.asarray(vectors[keys[i]], dtype=np.float64)
            b = np.asarray(vectors[keys[j]], dtype=np.float64)
            n = min(a.shape[0], b.shape[0])
            if n < 3:
                out[(keys[i], keys[j])] = float("nan")
                continue
            a, b = a[:n], b[:n]
            mi = mutual_info_regression(b, a, random_state=0).mean()
            ha = _entropy(a)
            hb = _entropy(b)
            denom = np.sqrt(ha * hb)
            out[(keys[i], keys[j])] = float(mi / denom) if denom > 0 else 0.0
    return out


def _entropy(x: np.ndarray) -> float:
    """Differential entropy of a continuous block, estimated by binning."""
    if x.size == 0:
        return 0.0
    out = 0.0
    for col in range(x.shape[1]):
        col_data = x[:, col]
        if col_data.std() < 1e-12:
            continue
        hist, edges = np.histogram(col_data, bins=32)
        p = hist / max(hist.sum(), 1)
        p = p[p > 0]
        width = (edges[-1] - edges[0]) / 32 if edges[-1] > edges[0] else 1.0
        out += float(-(p * np.log(p)).sum() * np.log(width))
    return out


def channel_attribution_proportions(attributions: Sequence[np.ndarray],
                                    channel_slices: Dict[str, slice]) -> Dict[str, float]:
    """Table 10: the share of total attribution magnitude per channel.

    Parameters
    ----------
    attributions:
        One attribution vector per correctly detected malicious user.
    channel_slices:
        Mapping ``channel_key -> slice`` giving each channel's block inside
        the 128-dimensional fused feature vector.
    """
    totals = {k: 0.0 for k in channel_slices}
    count = 0
    for vec in attributions:
        arr = np.asarray(vec, dtype=np.float64)
        for key, sl in channel_slices.items():
            totals[key] += float(np.abs(arr[sl]).sum())
        count += 1
    grand = sum(totals.values())
    if grand <= 0:
        return {k: 0.0 for k in totals}
    return {k: v / grand for k, v in totals.items()}


def channel_attribution_sds(attributions: Sequence[np.ndarray],
                            channel_slices: Dict[str, slice]) -> Dict[str, float]:
    """Table 10: the standard deviation of each channel's share.

    The share is computed per flagged malicious user and then summarised
    across users, so the reported standard deviation is the spread of the
    per-user proportions, not the spread of the raw attribution magnitudes.
    """
    per_user: Dict[str, List[float]] = {k: [] for k in channel_slices}
    for vec in attributions:
        arr = np.asarray(vec, dtype=np.float64)
        totals = {k: float(np.abs(arr[sl]).sum()) for k, sl in channel_slices.items()}
        grand = sum(totals.values())
        if grand <= 0:
            continue
        for key in channel_slices:
            per_user[key].append(totals[key] / grand)
    out: Dict[str, float] = {}
    for key, values in per_user.items():
        if len(values) > 1:
            out[key] = float(np.std(np.asarray(values), ddof=1))
        elif values:
            out[key] = 0.0
        else:
            out[key] = float("nan")
    return out


def pearson_ci(r: float, n: int, confidence: float = 0.95) -> Tuple[float, float]:
    """The confidence interval of a Pearson correlation.

    Uses Fisher's z transform, which is the standard construction and the
    one the paper's reported intervals are consistent with.
    """
    if n < 4 or not np.isfinite(r) or abs(r) >= 1.0:
        return (float("nan"), float("nan"))
    from math import atanh, erf, sqrt

    z = atanh(float(r))
    se = 1.0 / sqrt(n - 3)
    # Normal quantile for the requested confidence, two-sided.
    z_crit = 2.0 * erf(1.0 / sqrt(2.0))  # 0.9545 quantile of |N(0,1)|
    if abs(confidence - 0.95) > 1e-9:
        z_crit = 1.959963985 if confidence >= 0.95 else 1.644853627
    lo, hi = z - z_crit * se, z + z_crit * se
    return (float(np.tanh(lo)), float(np.tanh(hi)))
