"""Evaluation metrics (paper Section 5.5 and Section 6).

    Eq. (38)   AUC-ROC = integral of TPR with respect to FPR over all thresholds

The paper reports AUC-ROC as the headline metric, together with precision,
recall and F1 at the operating threshold of Eq. (33).  Because the test
partition holds only nine malicious windows from a single insider identity,
the threshold-dependent metrics are reported as indicative rather than
definitive; the AUC-ROC is threshold-agnostic and carries the weight.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import numpy as np

try:
    from sklearn.metrics import roc_auc_score
except ImportError:  # pragma: no cover
    roc_auc_score = None  # type: ignore


def roc_auc(y_true: Sequence[int], scores: Sequence[float]) -> float:
    """Eq. (38): the area under the receiver operating characteristic curve."""
    y = np.asarray(y_true).astype(int)
    s = np.asarray(scores, dtype=np.float64)
    if y.size == 0 or len(np.unique(y)) < 2:
        return float("nan")
    if roc_auc_score is not None:
        return float(roc_auc_score(y, s))
    # Manual trapezoidal computation over the ROC curve.
    order = np.argsort(-s)
    y = y[order]
    tps = np.cumsum(y)
    fps = np.cumsum(1 - y)
    tpr = tps / tps[-1]
    fpr = fps / fps[-1]
    return float(np.trapezoid(tpr, fpr))


def precision_recall_f1(y_true: Sequence[int], scores: Sequence[float],
                        threshold: float = 0.5) -> Dict[str, float]:
    """Precision, recall and F1 at a fixed operating threshold."""
    y = np.asarray(y_true).astype(int)
    p = (np.asarray(scores, dtype=np.float64) >= threshold).astype(int)
    tp = int(((p == 1) & (y == 1)).sum())
    fp = int(((p == 1) & (y == 0)).sum())
    fn = int(((p == 0) & (y == 1)).sum())
    tn = int(((p == 0) & (y == 0)).sum())
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
    return {"precision": float(precision), "recall": float(recall),
            "f1": float(f1), "tp": tp, "fp": fp, "fn": fn, "tn": tn}


def classification_metrics(y_true: Sequence[int], scores: Sequence[float],
                            threshold: float = 0.5) -> Dict[str, float]:
    """Every metric the paper reports for a detection run."""
    out: Dict[str, float] = {"auc_roc": roc_auc(y_true, scores)}
    out.update(precision_recall_f1(y_true, scores, threshold))
    return out


def mean_std(values: Sequence[float]) -> Dict[str, float]:
    """Mean and standard deviation across seeds, as the paper reports them."""
    arr = np.asarray([v for v in values if not (isinstance(v, float) and np.isnan(v))],
                     dtype=np.float64)
    if arr.size == 0:
        return {"mean": float("nan"), "std": float("nan"), "n": 0}
    return {"mean": float(arr.mean()),
            "std": float(arr.std(ddof=1)) if arr.size > 1 else 0.0,
            "n": int(arr.size)}


def wilcoxon_paired(a: Sequence[float], b: Sequence[float],
                    alternative: str = "two-sided") -> Dict[str, float]:
    """Paired Wilcoxon signed-rank test.

    The paper uses a paired **one-sided** Wilcoxon signed-rank test for the
    AUC gain over LAN (Table 8 note, ``alternative="greater"``) and a paired
    **two-sided** test for the triage times (Section 6.4).
    """
    from scipy.stats import wilcoxon

    x = np.asarray(a, dtype=np.float64)
    y = np.asarray(b, dtype=np.float64)
    if x.size < 2:
        return {"statistic": float("nan"), "p_value": float("nan")}
    res = wilcoxon(x, y, alternative=alternative)
    return {"statistic": float(res.statistic), "p_value": float(res.pvalue)}
