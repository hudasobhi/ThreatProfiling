"""Evaluation: metrics, confusion matrix, channel analysis, drift robustness,
scalability and leakage checks."""
