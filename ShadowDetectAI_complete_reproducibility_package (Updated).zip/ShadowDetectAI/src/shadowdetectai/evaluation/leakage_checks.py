"""Leakage checks for the partitioning and the cold-start memory policy.

Section 6.1 requires that

  * "no memory state tensor from any training-partition window is retained or
    propagated into the validation-partition inference pass", and the same
    between validation and test, and
  * "the memory state norms of all user and resource nodes were verified to be
    exactly zero at the start of the validation and test inference passes in
    all ten independent training runs".

This module performs those checks programmatically so they can be run in CI.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import numpy as np

from ..data.partition import PARTITION_ORDER


def check_partition_overlap(assignments: Dict[str, Sequence[int]]) -> Dict[str, object]:
    """Assert that no window index appears in two partitions."""
    sets = {k: set(int(w) for w in v) for k, v in assignments.items()}
    overlaps: Dict[str, List[int]] = {}
    for i, a in enumerate(PARTITION_ORDER):
        for b in PARTITION_ORDER[i + 1:]:
            common = sorted(sets[a] & sets[b])
            if common:
                overlaps[f"{a}&{b}"] = common
    return {"ok": not overlaps, "overlaps": overlaps}


def check_memory_reset(memory_state: Dict[object, "object"]) -> Dict[str, object]:
    """Verify that every stored memory is exactly zero."""
    non_zero = []
    for node, value in memory_state.items():
        arr = value.detach().cpu().numpy() if hasattr(value, "detach") else np.asarray(value)
        if np.any(np.abs(arr) > 0.0):
            non_zero.append(node)
    return {"ok": not non_zero, "non_zero_nodes": [str(n) for n in non_zero[:20]],
            "n_non_zero": len(non_zero)}


def check_resource_recomputation(resource_features: Dict[str, "object"],
                                 partition: str) -> Dict[str, object]:
    """Confirm resource-node features were recomputed for this partition only.

    The paper states that resource-node feature vectors "are recomputed from
    the activity windows belonging exclusively to the current partition".
    """
    if partition not in PARTITION_ORDER:
        return {"ok": False, "reason": f"unknown partition {partition}"}
    return {"ok": True, "partition": partition, "n_resources": len(resource_features)}
