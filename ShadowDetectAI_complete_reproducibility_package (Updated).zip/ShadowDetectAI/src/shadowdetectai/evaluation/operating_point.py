"""The operating point of the detector (paper Section 5, Eq. 33).

The paper reports precision, recall and F1 "at the operating threshold of
Eq. (33)", i.e. at a threshold that adapts to behavioural drift.  The
threshold is therefore not a constant: it is fitted on the validation
partition at a target false-positive rate and then widened by the
population stability index between the validation and test score
distributions.

    tau_0  = the threshold at the target FPR, fitted on the validation scores
    PSI    = the drift between the validation and test score distributions
    tau    = tau_0 * (1 + lambda_drift * PSI)                      (Eq. 33)

The target FPR is ``[NOT STATED IN PAPER]``; the default of 1 % reproduces
the confusion matrix of Table 9, which contains a single false positive
among 20,591 benign windows.
"""
from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np

from ..calibration.adaptive_threshold import AdaptiveThreshold, fit_base_threshold
from ..calibration.psi_drift import PSIReference


def fit_operating_point(validation_scores: Sequence[float],
                        test_scores: Sequence[float],
                        target_fpr: float = 0.01,
                        n_bins: int = 10,
                        lambda_drift: float = 0.1) -> Dict[str, float]:
    """Fit the operating threshold of Eq. (33).

    Parameters
    ----------
    validation_scores:
        The validation-partition scores, used both to fit the base
        threshold and as the drift reference.
    test_scores:
        The test-partition scores, used to measure the drift.
    target_fpr:
        The false-positive rate the base threshold is fitted at.
    n_bins:
        The number of score bins used by the PSI of Eq. (32).
    lambda_drift:
        The drift weight of Eq. (33).

    Returns
    -------
    dict
        ``tau_0``, ``psi`` and ``threshold``.
    """
    val = np.asarray(validation_scores, dtype=np.float64)
    test = np.asarray(test_scores, dtype=np.float64)

    tau_0 = fit_base_threshold(val, target_fpr=target_fpr)
    if val.size and test.size:
        reference = PSIReference.fit(val, n_bins=n_bins)
        psi = float(reference.compute(test))
    else:
        psi = 0.0
    threshold = AdaptiveThreshold(tau_0=tau_0, lambda_drift=lambda_drift).apply(psi)
    return {"tau_0": float(tau_0), "psi": psi, "threshold": float(threshold)}
