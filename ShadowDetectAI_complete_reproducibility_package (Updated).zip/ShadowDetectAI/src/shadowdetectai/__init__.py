"""ShadowDetectAI: explainable insider threat profiling with log-derived behavioral proxies.

Reference implementation for the paper
"Explainable Deep Learning for Insider Threat Profiling Using Log-Derived
Behavioral Proxies and Temporal Graph Networks" (ShadowDetectAI).

Every module in this package cites the paper equation / table / section it
implements.  See ``docs/paper_to_code_map.md`` for the complete map.
"""

__version__ = "1.0.0"
__all__ = ["data", "features", "models", "explain", "calibration",
           "baselines", "training", "evaluation", "triage", "utils"]
