"""Checkpoint saving and loading."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

import torch


def save_checkpoint(path: str | Path, model: torch.nn.Module,
                    optimizer: Optional[torch.optim.Optimizer] = None,
                    epoch: int = 0, seed: Optional[int] = None,
                    extra: Optional[Dict[str, Any]] = None) -> Path:
    """Save a model checkpoint (best and last are both written by the trainer)."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload: Dict[str, Any] = {
        "model_state": model.state_dict(),
        "epoch": epoch,
        "seed": seed,
    }
    if optimizer is not None:
        payload["optimizer_state"] = optimizer.state_dict()
    if extra:
        payload["extra"] = extra
    torch.save(payload, p)
    return p


def load_checkpoint(path: str | Path, model: torch.nn.Module,
                    optimizer: Optional[torch.optim.Optimizer] = None,
                    map_location: str = "cpu") -> Dict[str, Any]:
    """Restore a checkpoint into ``model`` (and optionally ``optimizer``)."""
    payload = torch.load(path, map_location=map_location, weights_only=False)
    model.load_state_dict(payload["model_state"])
    if optimizer is not None and "optimizer_state" in payload:
        optimizer.load_state_dict(payload["optimizer_state"])
    return payload


def checkpoint_paths(out_dir: str | Path, seed: int) -> Dict[str, Path]:
    """The best/last checkpoint paths used for one seed."""
    d = Path(out_dir)
    return {
        "best": d / f"seed{seed}_best.pt",
        "last": d / f"seed{seed}_last.pt",
    }
