"""Training harness shared by the main model and the six baselines.

Every hyper-parameter is read from the YAML config; nothing is hard-coded
here.  The trainer implements the composite loss of Eq. (36) and the
cold-start memory reset required at each partition boundary (Section 6.1).
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import torch
from torch import nn

from ..models.losses import LossWeights, composite_loss
from ..utils.io import ensure_dir, write_json
from ..utils.logging import CSVLogger, get_logger
from ..utils.seeds import set_seed
from .checkpoints import checkpoint_paths, save_checkpoint


@dataclass
class TrainConfig:
    """Everything the trainer needs, normally loaded from YAML."""

    seed: int = 42
    epochs: int = 60
    learning_rate: float = 3e-4
    weight_decay: float = 0.0
    batch_size: int = 256
    optimizer: str = "adam"
    scheduler: str = "none"
    warmup_steps: int = 0
    early_stopping_patience: Optional[int] = None
    use_amp: bool = False
    device: str = "cuda"
    output_dir: str = "results/raw_runs"
    log_every: int = 1
    num_workers: int = 0
    smooth_lambda: float = 0.1
    reg_lambda: float = 1e-5
    max_grad_norm: Optional[float] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TrainConfig":
        known = {f for f in cls.__dataclass_fields__}  # type: ignore[attr-defined]
        return cls(**{k: v for k, v in d.items() if k in known})


def build_optimizer(model: nn.Module, cfg: TrainConfig) -> torch.optim.Optimizer:
    """Build the optimizer named in the config (Adam by default, Table 6)."""
    name = cfg.optimizer.lower()
    params = [p for p in model.parameters() if p.requires_grad]
    if name == "adam":
        return torch.optim.Adam(params, lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    if name == "adamw":
        return torch.optim.AdamW(params, lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    if name == "sgd":
        return torch.optim.SGD(params, lr=cfg.learning_rate, momentum=0.9,
                               weight_decay=cfg.weight_decay)
    raise ValueError(f"unknown optimizer: {cfg.optimizer}")


def build_scheduler(optimizer: torch.optim.Optimizer, cfg: TrainConfig):
    """Optional learning-rate schedule (the paper states none)."""
    if cfg.scheduler in (None, "none", ""):
        return None
    if cfg.scheduler == "cosine":
        return torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg.epochs)
    if cfg.scheduler == "step":
        return torch.optim.lr_scheduler.StepLR(optimizer, step_size=max(cfg.epochs // 3, 1),
                                               gamma=0.1)
    raise ValueError(f"unknown scheduler: {cfg.scheduler}")


class Trainer:
    """Train one model for one seed and report the metrics the paper reports."""

    def __init__(self, model: nn.Module, cfg: TrainConfig,
                 loss_weights: Optional[LossWeights] = None):
        self.model = model
        self.cfg = cfg
        self.loss_weights = loss_weights or LossWeights(cfg.smooth_lambda, cfg.reg_lambda)
        self.device = torch.device(cfg.device if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.optimizer = build_optimizer(model, cfg)
        self.scheduler = build_scheduler(self.optimizer, cfg)
        self.scaler = torch.amp.GradScaler("cuda", enabled=cfg.use_amp and self.device.type == "cuda")
        self.logger = get_logger("shadowdetectai.train")
        ensure_dir(Path(cfg.output_dir))

    def train_epoch(self, loader: Iterable[Dict[str, torch.Tensor]]) -> Dict[str, float]:
        """One pass over the training loader."""
        self.model.train()
        totals = {"loss": 0.0, "bce": 0.0, "smooth": 0.0, "n": 0}
        for batch in loader:
            batch = {k: (v.to(self.device) if torch.is_tensor(v) else v)
                     for k, v in batch.items()}
            labels = batch["label"].float()
            with torch.amp.autocast("cuda", enabled=self.scaler.is_enabled()):
                out = self.model(batch)
                logit = out["logit"]
                smoothness = batch.get("smoothness_penalty")
                losses = composite_loss(logit, labels, smoothness,
                                        self.loss_weights, self.model)
            self.optimizer.zero_grad(set_to_none=True)
            self.scaler.scale(losses["total"]).backward()
            if self.cfg.max_grad_norm:
                self.scaler.unscale_(self.optimizer)
                nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.max_grad_norm)
            self.scaler.step(self.optimizer)
            self.scaler.update()
            n = int(labels.shape[0])
            totals["loss"] += float(losses["total"].item()) * n
            totals["bce"] += float(losses["bce"].item()) * n
            totals["smooth"] += float(losses["smooth"].item()) * n
            totals["n"] += n
        n = max(totals["n"], 1)
        return {"loss": totals["loss"] / n, "bce": totals["bce"] / n,
                "smooth": totals["smooth"] / n}

    @torch.no_grad()
    def evaluate(self, loader: Iterable[Dict[str, torch.Tensor]]) -> Dict[str, float]:
        """Evaluate on a loader and return the paper's headline metrics."""
        from ..evaluation.metrics import classification_metrics

        self.model.eval()
        logits: List[float] = []
        labels: List[int] = []
        for batch in loader:
            batch = {k: (v.to(self.device) if torch.is_tensor(v) else v)
                     for k, v in batch.items()}
            out = self.model(batch)
            logits.extend(out["logit"].detach().cpu().numpy().tolist())
            labels.extend(batch["label"].detach().cpu().numpy().astype(int).tolist())
        return classification_metrics(logits, labels)

    def fit(self, train_loader, val_loader: Optional[Any] = None,
            epochs: Optional[int] = None) -> Dict[str, Any]:
        """Full training run for one seed.

        Returns a dict with the per-epoch history, the best validation
        metrics and the checkpoint paths.
        """
        set_seed(self.cfg.seed)
        epochs = epochs or self.cfg.epochs
        paths = checkpoint_paths(self.cfg.output_dir, self.cfg.seed)
        csv_logger = CSVLogger(Path(self.cfg.output_dir) / f"seed{self.cfg.seed}_train.csv",
                                ["epoch", "loss", "bce", "smooth",
                                 "val_auc", "val_f1", "seconds"])
        history: List[Dict[str, float]] = []
        best = {"auc": -1.0}
        best_epoch = -1
        patience = 0
        t_start = time.perf_counter()

        for epoch in range(1, epochs + 1):
            t0 = time.perf_counter()
            train_stats = self.train_epoch(train_loader)
            val_stats = (self.evaluate(val_loader) if val_loader is not None else {})
            if self.scheduler is not None:
                self.scheduler.step()
            elapsed = time.perf_counter() - t0
            row = {"epoch": epoch, **train_stats,
                   "val_auc": val_stats.get("auc_roc", ""),
                   "val_f1": val_stats.get("f1", ""),
                   "seconds": round(elapsed, 3)}
            history.append(row)
            csv_logger.append(row)

            if val_stats:
                auc = float(val_stats.get("auc_roc", -1.0))
                if auc > best["auc"]:
                    best = val_stats
                    best_epoch = epoch
                    save_checkpoint(paths["best"], self.model, self.optimizer,
                                    epoch, self.cfg.seed)
                    patience = 0
                else:
                    patience += 1
                    if self.cfg.early_stopping_patience and patience >= self.cfg.early_stopping_patience:
                        self.logger.info(f"early stopping at epoch {epoch}")
                        break
            if epoch % self.cfg.log_every == 0:
                self.logger.info(f"seed {self.cfg.seed} epoch {epoch}: {row}")

        save_checkpoint(paths["last"], self.model, self.optimizer, epochs, self.cfg.seed)
        summary = {
            "seed": self.cfg.seed,
            "best_epoch": best_epoch,
            "best": best,
            "history": history,
            "checkpoints": {k: str(v) for k, v in paths.items()},
            "total_seconds": time.perf_counter() - t_start,
        }
        write_json(Path(self.cfg.output_dir) / f"seed{self.cfg.seed}_summary.json", summary)
        return summary
