"""Seed helpers re-exported from :mod:`shadowdetectai.utils.seeds`.

Keeping them here means the training entry points can import from a single
place, and the ten paper seeds stay in exactly one definition.
"""
from __future__ import annotations

from ..utils.seeds import PAPER_SEEDS, paper_seeds, seed_worker, set_seed

__all__ = ["PAPER_SEEDS", "paper_seeds", "seed_worker", "set_seed"]
