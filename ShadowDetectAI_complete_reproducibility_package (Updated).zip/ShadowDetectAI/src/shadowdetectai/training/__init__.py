"""Training loop, seeding helpers and checkpointing."""
