"""Double Layer Detection [6] baseline.

He et al., "Double layer detection of internal threat in enterprise systems
based on deep learning", IEEE TIFS 19 (2024) 4741-4751.  The architecture
separates phishing-mediated compromise from purely behavioural internal
threats in a two-stage detection pipeline.

Table 7 grid: learning rate in {0.0001, 0.0003, 0.001}, hidden dimension in
{64, 128}, dropout rate in {0.1, 0.3, 0.5}.  Selected configuration:
LR = 0.0001, Dim = 128, Dropout = 0.3.
"""
from __future__ import annotations

from . import BaselineModel

from typing import Dict, Optional

import torch
from torch import nn
from torch.nn import functional as F


class DoubleLayerDetection(BaselineModel):
    """Two-stage detector: phishing-mediated layer then behavioural layer."""

    def __init__(self, feature_dim: int, hidden_dim: int = 128, dropout: float = 0.3):
        super().__init__()
        self.feature_dim = int(feature_dim)
        self.hidden_dim = int(hidden_dim)
        self.dropout = float(dropout)

        # Layer 1 - phishing-mediated compromise indicators.
        self.layer1 = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU())
        # Layer 2 - purely behavioural internal threat.
        self.layer2 = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1))
        self.combine = nn.Linear(2 * hidden_dim, hidden_dim)

    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        x = batch["features"]
        h1 = self.layer1(x)
        h2 = self.layer2(h1)
        phishing_logit = h2.squeeze(-1)

        behavioural = self.layer1(x)
        fused = F.relu(self.combine(torch.cat([h1, behavioural], dim=-1)))
        final = self.layer2(fused).squeeze(-1)

        return {
            "logit": final,
            "probability": torch.sigmoid(final),
            "phishing_logit": phishing_logit,
        }
