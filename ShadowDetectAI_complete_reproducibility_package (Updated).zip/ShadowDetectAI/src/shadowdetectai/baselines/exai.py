"""EXAI [9] baseline: an explainable but non-relational detector.

Arreche et al., "EXAI: evaluating black box explainable AI frameworks for
network intrusion detection", IEEE Access 12 (2024) 23954-23988.  Adapted
here as an explainable baseline that, like Gaspar et al., consumes flat
single-snapshot feature vectors and performs no relational modelling.

Table 7 grid: learning rate in {0.0001, 0.001}, layers in {2, 3, 4}, units per
layer in {64, 128, 256}.  Selected configuration: LR = 0.001, Layers = 3,
Units = 128.
"""
from __future__ import annotations

from . import BaselineModel

from typing import Dict

import torch
from torch import nn


class EXAIBaseline(BaselineModel):
    """Flat-feature MLP with a post-hoc explanation head.

    The explanation head is trained jointly so that the attribution it emits
    is faithful to the detector's own output, mirroring EXAI's evaluation of
    black-box explainable pipelines.
    """

    def __init__(self, input_dim: int, hidden_dim: int = 128, num_layers: int = 3):
        super().__init__()
        self.input_dim = int(input_dim)
        self.hidden_dim = int(hidden_dim)
        self.num_layers = int(num_layers)
        trunk = []
        dim = input_dim
        for _ in range(max(num_layers - 1, 1)):
            trunk += [nn.Linear(dim, hidden_dim), nn.ReLU()]
            dim = hidden_dim
        trunk += [nn.Linear(dim, 1)]
        self.net = nn.Sequential(*trunk)
        self.explainer = nn.Linear(input_dim, input_dim)

    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        x = batch["features"]
        logit = self.net(x).squeeze(-1)
        attribution = self.explainer(x)
        return {
            "logit": logit,
            "probability": torch.sigmoid(logit),
            "attribution": attribution,
        }
