"""VGGM [7] baseline: variational graph Gaussian mixture model.

Zhang et al., "VGGM: variational graph Gaussian mixture model for unsupervised
change point detection in dynamic networks", IEEE TIFS 19 (2024) 4272-4284.
Adapted here as a graph-based anomaly baseline: a variational auto-encoder
over graph node embeddings with a Gaussian mixture prior, trained
unsupervised and scored by reconstruction error.

Table 7 grid: learning rate in {0.0001, 0.001}, GMM components in {2, 4, 8},
latent dimension in {32, 64, 128}.  Selected configuration: LR = 0.001,
Components = 4, Latent dim = 64.
"""
from __future__ import annotations

from . import BaselineModel

from typing import Dict, Optional

import torch
from torch import nn
from torch.nn import functional as F


class VGGM(BaselineModel):
    """Unsupervised variational graph anomaly detector."""

    def __init__(self, feature_dim: int, latent_dim: int = 64,
                 n_components: int = 4, hidden_dim: int = 128):
        super().__init__()
        self.feature_dim = int(feature_dim)
        self.latent_dim = int(latent_dim)
        self.n_components = int(n_components)

        self.encoder = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU())
        self.mu = nn.Linear(hidden_dim, latent_dim)
        self.logvar = nn.Linear(hidden_dim, latent_dim)
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, feature_dim))
        # Gaussian-mixture prior parameters.
        self.prior_logits = nn.Parameter(torch.zeros(n_components))
        self.prior_means = nn.Parameter(torch.randn(n_components, latent_dim) * 0.1)

    def _sample(self, mu: torch.Tensor, logvar: torch.Tensor):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std, mu, logvar

    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        x = batch["node_features"]
        h = self.encoder(x)
        mu, logvar = self.mu(h), self.logvar(h)
        z, mu, logvar = self._sample(mu, logvar)
        recon = self.decoder(z)
        error = (recon - x).pow(2).mean(dim=-1)
        # The anomaly score is the reconstruction error; the sign convention
        # makes larger error mean more anomalous.
        logit = -error
        return {
            "logit": logit,
            "probability": torch.sigmoid(logit),
            "mu": mu,
            "logvar": logvar,
            "recon": recon,
        }

    def kl_loss(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """KL divergence to the Gaussian-mixture prior."""
        x = batch["node_features"]
        h = self.encoder(x)
        mu, logvar = self.mu(h), self.logvar(h)
        z = mu + torch.randn_like(mu) * torch.exp(0.5 * logvar)
        logp = self._log_prior(z)
        logq = (-0.5 * (1 + logvar + mu.pow(2) - logvar.exp())).sum(-1)
        return (logq - logp).mean()

    def _log_prior(self, z: torch.Tensor) -> torch.Tensor:
        logits = F.log_softmax(self.prior_logits, dim=0)
        comp = logits.unsqueeze(0) - 0.5 * ((z.unsqueeze(1) - self.prior_means.unsqueeze(0)) ** 2).sum(-1)
        return torch.logsumexp(comp, dim=1)
