"""LAN [4] baseline: learning adaptive neighbours for real-time detection.

Cai et al., "LAN: learning adaptive neighbors for real time insider threat
detection", IEEE TIFS 19 (2024) 10157-10172.  LAN jointly learns temporal
dependencies within a single user's activity sequence and structural
relationships across users through a learned graph structure.

Table 7 grid: learning rate in {0.0001, 0.0003, 0.001}, attention heads in
{2, 4, 8}, window size in {12 h, 24 h, 48 h}.  Selected configuration:
LR = 0.0003, Heads = 4, Window = 24 h.
"""
from __future__ import annotations

from . import BaselineModel

from typing import Dict, Optional

import torch
from torch import nn
from torch.nn import functional as F


class LAN(BaselineModel):
    """Learned-neighbour model with temporal sequence aggregation.

    Unlike the main model, LAN learns the neighbour weights from the
    interaction history rather than from a fixed adjacency structure, which
    is the "adaptive neighbours" contribution of the original paper.
    """

    def __init__(self, feature_dim: int, hidden_dim: int = 128, num_heads: int = 4):
        super().__init__()
        self.feature_dim = int(feature_dim)
        self.hidden_dim = int(hidden_dim)
        self.num_heads = int(num_heads)
        self.seq_encoder = nn.GRU(feature_dim, hidden_dim, batch_first=True)
        self.query = nn.Linear(hidden_dim, hidden_dim)
        self.key = nn.Linear(hidden_dim, hidden_dim)
        self.value = nn.Linear(hidden_dim, hidden_dim)
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, 1))

    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        seq = batch.get("sequence_features")              # (B, T, F)
        node_feat = batch["node_features"]                # (B, F)

        if seq is not None and seq.shape[1] > 0:
            _, h_seq = self.seq_encoder(seq)
            h = h_seq[-1]
        else:
            h = node_feat

        neighbour_feat = batch.get("neighbour_features")
        if neighbour_feat is not None and neighbour_feat.shape[1] > 0:
            nb = F.relu(self.key(neighbour_feat))
            q = self.query(h).unsqueeze(1)
            logits = (q * nb).sum(-1) / (self.hidden_dim ** 0.5)
            mask = batch.get("neighbour_mask")
            if mask is not None:
                logits = logits.masked_fill(~mask, float("-inf"))
            alpha = torch.softmax(logits, dim=1).unsqueeze(-1)
            v = self.value(neighbour_feat)
            h = h + (alpha * v).sum(dim=1)

        out = self.classifier(h).squeeze(-1)
        return {"logit": out, "probability": torch.sigmoid(out)}
