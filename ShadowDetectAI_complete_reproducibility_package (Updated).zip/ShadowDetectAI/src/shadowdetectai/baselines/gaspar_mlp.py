"""Gaspar et al. [10] baseline: LIME and SHAP on a multi-layer perceptron.

Gaspar et al., "Explainable AI for intrusion detection systems: LIME and
SHAP applicability on multi-layer perceptron", IEEE Access 12 (2024)
30164-30175.  Adapted here as a **flat feature** anomaly detector: the MLP
consumes one pooled feature vector per user-window, with no relational
structure.

Table 7 grid: learning rate in {0.0001, 0.001}, layers in {2, 3, 4}, units per
layer in {64, 128, 256}.  Selected configuration: LR = 0.0003, Layers = 2,
Units = 64.
"""
from __future__ import annotations

from . import BaselineModel

from typing import Dict

import torch
from torch import nn

from . import mlp_body


class GasparMLP(BaselineModel):
    """Flat-feature MLP anomaly detector with post-hoc attribution."""

    def __init__(self, input_dim: int, hidden_dim: int = 64, num_layers: int = 2,
                 dropout: float = 0.0):
        super().__init__()
        self.input_dim = int(input_dim)
        self.hidden_dim = int(hidden_dim)
        self.num_layers = int(num_layers)
        if num_layers == 2:
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_dim), nn.ReLU(),
                nn.Linear(hidden_dim, 1))
        elif num_layers == 3:
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_dim), nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
                nn.Linear(hidden_dim, 1))
        else:
            self.net = nn.Sequential(
                nn.Linear(input_dim, hidden_dim), nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
                nn.Linear(hidden_dim, 1))
        if dropout > 0:
            self.net = nn.Sequential(nn.Dropout(dropout), self.net)

    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        x = batch["features"]
        logit = self.net(x).squeeze(-1)
        return {"logit": logit, "probability": torch.sigmoid(logit)}
