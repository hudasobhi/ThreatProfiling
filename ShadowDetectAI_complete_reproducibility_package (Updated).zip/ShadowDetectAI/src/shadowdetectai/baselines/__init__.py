"""The six comparison baselines of Section 6.3.

The paper states that "All six baselines were implemented from scratch in
PyTorch 2.1 without use of third-party code repositories" (Section 6.3).
Every model in this package is therefore an original implementation written
for this repository; no third-party code is vendored.

Common interface
----------------
Every baseline exposes ``forward(batch) -> dict`` with an ``"logit"`` key and
is trained through the same harness as the main model
(``src/shadowdetectai/training/trainer.py``).
"""
from __future__ import annotations

from typing import Dict

import torch
from torch import nn


class BaselineModel(nn.Module):
    """Base class giving every baseline the same interface."""

    def __init__(self, input_dim: int = 0, hidden_dim: int = 128):
        super().__init__()
        self.input_dim = int(input_dim)
        self.hidden_dim = int(hidden_dim)

    def forward(self, batch: Dict[str, "torch.Tensor"]) -> Dict[str, "torch.Tensor"]:
        raise NotImplementedError

    def logit(self, batch: Dict[str, "torch.Tensor"]) -> "torch.Tensor":
        return self.forward(batch)["logit"]


def mlp_body(input_dim: int, hidden_dim: int, output_dim: int = 1,
             dropout: float = 0.0) -> nn.Sequential:
    """A plain MLP trunk shared by the flat-feature baselines."""
    layers = [nn.Linear(input_dim, hidden_dim), nn.ReLU()]
    if dropout > 0:
        layers.append(nn.Dropout(dropout))
    layers += [nn.Linear(hidden_dim, hidden_dim), nn.ReLU()]
    if dropout > 0:
        layers.append(nn.Dropout(dropout))
    layers += [nn.Linear(hidden_dim, output_dim)]
    return nn.Sequential(*layers)


# Public registry used by the evaluation scripts and integrity tests.
from .graphch import GraphCH
from .lan import LAN
from .double_layer import DoubleLayerDetection
from .vggm import VGGM
from .exai import EXAIBaseline
from .gaspar_mlp import GasparMLP

BASELINE_TYPES = {
    "graphch": GraphCH,
    "lan": LAN,
    "double_layer": DoubleLayerDetection,
    "vggm": VGGM,
    "exai": EXAIBaseline,
    "gaspar_mlp": GasparMLP,
}

__all__ = ["BaselineModel", "BASELINE_TYPES", "GraphCH", "LAN",
           "DoubleLayerDetection", "VGGM", "EXAIBaseline", "GasparMLP"]
