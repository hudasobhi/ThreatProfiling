"""Counterbalanced allocation of the alert pool to participants.

Section 6.4 and Table 12: each of the twenty alerts appears in the
attribution condition for five participants and in the no-attribution
condition for five participants; every participant therefore sees all twenty
alerts exactly once, ten with the attribution panel visible and ten without.
Within each condition the ten assigned alerts are composed of five
true-positive and five false-positive alerts, so the difficulty mix is
identical in both conditions.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np

from .alert_pool import Alert


@dataclass
class ParticipantSchedule:
    """One participant's alert order and condition assignment."""

    participant_id: int
    condition_order: List[str]          # ["attribution", "no_attribution"] or reversed
    attribution_alerts: List[str]       # alert ids, in presentation order
    no_attribution_alerts: List[str]
    practice_alerts: List[str]

    def as_dict(self) -> Dict[str, object]:
        return {
            "participant_id": self.participant_id,
            "condition_order": self.condition_order,
            "attribution_alerts": self.attribution_alerts,
            "no_attribution_alerts": self.no_attribution_alerts,
            "practice_alerts": self.practice_alerts,
        }


def allocate(pool: Sequence[Alert],
             n_participants: int = 10,
             seed: int = 42) -> List[ParticipantSchedule]:
    """Build the counterbalanced schedule for ``n_participants``.

    Half the participants complete the attribution condition first and half
    complete the no-attribution condition first (Table 12, "Order of
    conditions").
    """
    tp = [a.alert_id for a in pool if a.is_true_positive]
    fp = [a.alert_id for a in pool if not a.is_true_positive]
    rng = np.random.default_rng(seed)
    schedules: List[ParticipantSchedule] = []

    # A balanced cyclic rotation: participant p receives the true-positive
    # alerts at positions p..p+4 (mod 10) and the false-positive alerts at
    # positions p+5..p+9 (mod 10).  Every alert therefore appears in the
    # attribution condition for exactly half of the participants and in the
    # no-attribution condition for the other half, which is the invariant
    # stated in Section 6.4 and Table 12.
    half_tp = len(tp) // 2
    half_fp = len(fp) // 2
    for p in range(1, n_participants + 1):
        shift = (p - 1) % max(len(tp), 1)
        shift_fp = (p - 1 + half_tp) % max(len(fp), 1)
        attribution = ([tp[(shift + j) % len(tp)] for j in range(half_tp)] +
                       [fp[(shift_fp + j) % len(fp)] for j in range(half_fp)])
        remaining = [a.alert_id for a in pool if a.alert_id not in attribution]
        no_attr = list(rng.permutation(remaining))
        attribution = list(rng.permutation(attribution))
        order = (["attribution", "no_attribution"] if p % 2 == 1
                 else ["no_attribution", "attribution"])
        schedules.append(ParticipantSchedule(
            participant_id=p,
            condition_order=order,
            attribution_alerts=attribution,
            no_attribution_alerts=no_attr,
            practice_alerts=[],
        ))
    return schedules


def verify_allocation(pool: Sequence[Alert],
                       schedules: Sequence[ParticipantSchedule]) -> Dict[str, object]:
    """Check the invariants stated in Section 6.4 and Table 12."""
    ids = [a.alert_id for a in pool]
    seen_per_condition = {a: 0 for a in ids}
    problems: List[str] = []
    for sch in schedules:
        overlap = set(sch.attribution_alerts) & set(sch.no_attribution_alerts)
        if overlap:
            problems.append(f"participant {sch.participant_id} repeats alerts {sorted(overlap)}")
        if len(set(sch.attribution_alerts) | set(sch.no_attribution_alerts)) != len(ids):
            problems.append(f"participant {sch.participant_id} does not see all alerts")
        for a in sch.attribution_alerts:
            seen_per_condition[a] = seen_per_condition.get(a, 0) + 1
    by_id = {a.alert_id: a for a in pool}
    for sch in schedules:
        n_tp = sum(1 for a in sch.attribution_alerts if by_id[a].is_true_positive)
        if n_tp != len(sch.attribution_alerts) // 2:
            problems.append(f"participant {sch.participant_id} attribution mix is unbalanced")
    return {"ok": not problems, "problems": problems,
            "n_participants": len(schedules),
            "alerts_per_participant": len(ids)}
