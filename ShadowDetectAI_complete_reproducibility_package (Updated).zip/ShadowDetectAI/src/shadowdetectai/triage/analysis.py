"""Analysis of the analyst-triage study (paper Section 6.4, Table 13, Fig. 14).

The reported quantities are computed from the per-participant CSV files and
are written to Table 13 and Figure 14 from those same numbers, so the figure
and the table cannot drift apart.

Reported values (Table 13):
    no attribution  : 4.7 +/- 1.1 minutes per alert, disposition accuracy 0.73 +/- 0.09
    with attribution: 2.1 +/- 0.6 minutes per alert, disposition accuracy 0.81 +/- 0.07
    difference      : -2.6 minutes (-55.3 %)
    Wilcoxon        : W = 0, n = 10, p = 0.002 (paired, two-sided)
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np


def summarise_times(times: Sequence[Sequence[float]]) -> Dict[str, float]:
    """Per-participant mean triage times summarised as mean and SD."""
    per_participant = np.asarray([np.mean(t) for t in times], dtype=np.float64)
    return {
        "mean": float(per_participant.mean()),
        "sd": float(per_participant.std(ddof=1)) if per_participant.size > 1 else 0.0,
        "per_participant": per_participant.tolist(),
    }


def summarise_accuracy(accuracy: Sequence[Sequence[float]]) -> Dict[str, float]:
    """Per-participant disposition accuracy summarised as mean and SD."""
    per_participant = np.asarray([np.mean(a) for a in accuracy], dtype=np.float64)
    return {
        "mean": float(per_participant.mean()),
        "sd": float(per_participant.std(ddof=1)) if per_participant.size > 1 else 0.0,
        "per_participant": per_participant.tolist(),
    }


def reduction(no_attr: Dict[str, float], with_attr: Dict[str, float]) -> Dict[str, float]:
    """The absolute and relative triage-time reduction."""
    delta = no_attr["mean"] - with_attr["mean"]
    pct = 100.0 * delta / no_attr["mean"] if no_attr["mean"] else 0.0
    return {"difference_minutes": float(delta), "reduction_percent": float(pct)}


def wilcoxon_test(no_attr: Dict[str, float], with_attr: Dict[str, float]
                  ) -> Dict[str, float]:
    """The paired two-sided Wilcoxon signed-rank test of Section 6.4."""
    from scipy.stats import wilcoxon

    a = np.asarray(no_attr["per_participant"], dtype=np.float64)
    b = np.asarray(with_attr["per_participant"], dtype=np.float64)
    if a.size < 2:
        return {"statistic": float("nan"), "p_value": float("nan"), "n": int(a.size)}
    res = wilcoxon(a, b, alternative="two-sided")
    return {"statistic": float(res.statistic), "p_value": float(res.pvalue),
            "n": int(a.size)}


def table13_rows(no_attr: Dict[str, float], with_attr: Dict[str, float],
                 no_acc: Dict[str, float], with_acc: Dict[str, float],
                 red: Dict[str, float], n_participants: int = 10
                 ) -> List[List[object]]:
    """The rows of Table 13."""
    return [
        ["No attribution (aggregate anomaly score only)", 10, n_participants,
         round(no_attr["mean"], 1), round(no_attr["sd"], 1),
         f"{no_acc['mean']:.2f} +/- {no_acc['sd']:.2f}"],
        ["With Shapley attribution (top-five panel)", 10, n_participants,
         round(with_attr["mean"], 1), round(with_attr["sd"], 1),
         f"{with_acc['mean']:.2f} +/- {with_acc['sd']:.2f}"],
        ["Difference", "-", "-",
         f"{red['difference_minutes']:.1f} (-{red['reduction_percent']:.1f} %)",
         "-", f"+{with_acc['mean'] - no_acc['mean']:.2f}"],
    ]
