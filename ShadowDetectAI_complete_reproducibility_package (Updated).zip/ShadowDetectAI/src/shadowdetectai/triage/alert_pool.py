"""Construction of the 20-alert triage pool (paper Section 6.4, Table 12).

The pool is **exhaustive rather than sampled**: it contains every confirmed
detection of the seed-42 test-partition run, supplemented with
validation-partition alerts until the target composition of ten true-positive
and ten false-positive alerts is reached.  The seed-42 test-partition run
yields eight confirmed true positives and one false positive (Table 9), so
the remaining two true-positive and nine false-positive alerts are taken from
the validation partition.

All validation-partition stimuli derive from the single malicious insider
identity assigned to that partition (Table 5), which the paper states as a
limitation of the stimulus pool.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np

TARGET_TRUE_POSITIVES = 10
TARGET_FALSE_POSITIVES = 10
PRACTICE_BLOCK_SIZE = 5


@dataclass
class Alert:
    """One alert in the pool."""

    alert_id: str
    partition: str
    is_true_positive: bool
    user: str
    window_index: int
    score: float
    deviation_count: int
    ground_truth_label: int

    def as_dict(self) -> Dict[str, object]:
        return {
            "alert_id": self.alert_id,
            "partition": self.partition,
            "is_true_positive": int(self.is_true_positive),
            "user": self.user,
            "window_index": int(self.window_index),
            "score": float(self.score),
            "deviation_count": int(self.deviation_count),
            "ground_truth_label": int(self.ground_truth_label),
        }


def build_alert_pool(test_alerts: Sequence[Alert],
                      validation_alerts: Sequence[Alert],
                      target_tp: int = TARGET_TRUE_POSITIVES,
                      target_fp: int = TARGET_FALSE_POSITIVES) -> List[Alert]:
    """Assemble the pool, exhausting the test partition first.

    Parameters
    ----------
    test_alerts:
        Confirmed alerts of the seed-42 test-partition run.
    validation_alerts:
        Candidate alerts from the validation partition.
    """
    pool: List[Alert] = []
    for a in test_alerts:
        if len(pool) >= target_tp + target_fp:
            break
        pool.append(a)
    n_tp = sum(1 for a in pool if a.is_true_positive)
    n_fp = len(pool) - n_tp
    for a in validation_alerts:
        if n_tp >= target_tp and n_fp >= target_fp:
            break
        if a.is_true_positive and n_tp < target_tp:
            pool.append(a)
            n_tp += 1
        elif (not a.is_true_positive) and n_fp < target_fp:
            pool.append(a)
            n_fp += 1
    for i, a in enumerate(pool, start=1):
        a.alert_id = f"alert_{i:02d}"
    return pool


def split_practice_block(pool: Sequence[Alert],
                         size: int = PRACTICE_BLOCK_SIZE) -> List[Alert]:
    """The practice block, drawn from the validation partition and excluded
    from the twenty timed alerts."""
    validation = [a for a in pool if a.partition == "validation"]
    return validation[:size]


def pool_composition(pool: Sequence[Alert]) -> Dict[str, int]:
    """Counts used by Table 12."""
    return {
        "total": len(pool),
        "true_positive": sum(1 for a in pool if a.is_true_positive),
        "false_positive": sum(1 for a in pool if not a.is_true_positive),
        "from_test": sum(1 for a in pool if a.partition == "test"),
        "from_validation": sum(1 for a in pool if a.partition == "validation"),
    }
