"""Analyst-triage study: alert pool, counterbalanced allocation and analysis."""
