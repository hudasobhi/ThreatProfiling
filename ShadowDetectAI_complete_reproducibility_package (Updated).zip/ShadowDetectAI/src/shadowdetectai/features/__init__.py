"""The three log-derived behavioural proxy channels (paper Section 4.1) and
their fusion (Eq. 16)."""
