"""Mouse interaction proxy channel (paper Section 4.1.2, Eq. 14).

The channel is built from CERT r6.2 **device** (USB) activity records.  The
paper states: "the device-event records are summarized by their frequency
distribution, which the encoder treats as a coarse proxy for the rate of device
interaction; the mouse channel is computed directly from that distribution; no
pointer coordinate or click-pressure quantity is involved at any stage of the
computation".

    Eq. (14)   H_v = - sum_i p_i log p_i

``H_v`` is the Shannon entropy of the device-event frequency histogram.  The
feature vector concatenates the entropy with the device-event interval
statistics computed analogously to Eq. (13).
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np
import pandas as pd

#: Names of the components of the mouse feature vector.
MOUSE_FEATURE_NAMES: List[str] = [
    "device_entropy",
    "device_event_rate",
    "device_interval_mean",
    "device_interval_std",
    "device_interval_p50",
    "device_interval_p90",
]

MOUSE_FEATURE_DIM = len(MOUSE_FEATURE_NAMES)


def shannon_entropy(counts: np.ndarray) -> float:
    """Eq. (14): the Shannon entropy of a frequency distribution."""
    counts = np.asarray(counts, dtype=np.float64)
    total = counts.sum()
    if total <= 0:
        return 0.0
    p = counts / total
    p = p[p > 0]
    return float(-(p * np.log(p)).sum())


def device_event_histogram(session: pd.DataFrame,
                           activity_col: str = "activity") -> np.ndarray:
    """Histogram of device-event *types* within a session.

    The paper computes the entropy over "the frequency distribution of the
    different types of device events".
    """
    if session.empty or activity_col not in session.columns:
        return np.zeros(0)
    return session[activity_col].value_counts().to_numpy(dtype=np.float64)


def session_mouse_features(session: pd.DataFrame,
                           time_col: str = "timestamp",
                           activity_col: str = "activity") -> np.ndarray:
    """The mouse feature vector for one session."""
    hist = device_event_histogram(session, activity_col)
    entropy = shannon_entropy(hist)
    # Force nanosecond resolution explicitly: pandas may hold the column at
    # microsecond resolution, in which case a bare astype("int64") would
    # return microseconds and every interval would be 1000x too small.
    t = np.sort(session[time_col].to_numpy(dtype="datetime64[ns]").astype("int64")
                .astype(np.float64) / 1e9)
    intervals = np.diff(t) if t.size >= 2 else np.zeros(0)
    rate = float(len(session) / max((t[-1] - t[0]) / 3600.0, 1e-9)) if t.size >= 2 else 0.0
    if intervals.size:
        stats = [float(intervals.mean()), float(intervals.std()),
                 float(np.median(intervals)), float(np.percentile(intervals, 90))]
    else:
        stats = [0.0, 0.0, 0.0, 0.0]
    return np.asarray([entropy, rate] + stats, dtype=np.float32)


def user_window_mouse_features(events: pd.DataFrame,
                               user_col: str = "user",
                               window_col: str = "window_index",
                               session_col: str = "session_id",
                               time_col: str = "timestamp",
                               activity_col: str = "activity") -> pd.DataFrame:
    """Mouse proxy features for every (user, window) pair."""
    rows: List[Dict[str, object]] = []
    for (user, window), grp in events.groupby([user_col, window_col], sort=True):
        if session_col in grp.columns:
            groups = list(grp.groupby(session_col, sort=True))
        else:
            groups = [(None, grp)]
        agg = np.zeros(MOUSE_FEATURE_DIM, dtype=np.float64)
        for _, sess in groups:
            agg += session_mouse_features(sess, time_col, activity_col)
        agg /= max(len(groups), 1)
        row: Dict[str, object] = {user_col: user, window_col: int(window)}
        for name, value in zip(MOUSE_FEATURE_NAMES, agg):
            row[name] = float(value)
        rows.append(row)
    return pd.DataFrame(rows, columns=[user_col, window_col] + MOUSE_FEATURE_NAMES)
