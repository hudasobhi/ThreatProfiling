"""The Table 3 mapping from CERT r6.2 log source to behavioural proxy channel.

This module is the single source of truth for which log feeds which channel.
It is imported by the feature extractors, by ``tests/test_no_hardware_fields.py``
and by the documentation generator, so that the manuscript's Table 3 and the
code cannot drift apart.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

#: The three channels named in the manuscript (Table 3).
CHANNEL_KEYSTROKE = "keystroke timing proxy channel"
CHANNEL_MOUSE = "mouse interaction proxy channel"
CHANNEL_APPLICATION = "application usage sequencing channel"

CHANNEL_NAMES: List[str] = [CHANNEL_KEYSTROKE, CHANNEL_MOUSE, CHANNEL_APPLICATION]

#: Short internal keys used in configs and code.
CHANNEL_KEYS: Dict[str, str] = {
    CHANNEL_KEYSTROKE: "keystroke_timing_proxy",
    CHANNEL_MOUSE: "mouse_interaction_proxy",
    CHANNEL_APPLICATION: "application_sequencing",
}


@dataclass(frozen=True)
class ChannelSpec:
    """One row of Table 3."""

    log_source: str
    proxy_statistic: str
    channel_name: str
    key: str


#: Table 3, verbatim in structure.
TABLE_3: List[ChannelSpec] = [
    ChannelSpec(
        log_source="Logon and session activity records (timestamped)",
        proxy_statistic=("Inter-event interval distribution inside a session window; "
                         "mean, standard deviation, median and ninetieth percentile of the interval"),
        channel_name=CHANNEL_KEYSTROKE,
        key="keystroke_timing_proxy",
    ),
    ChannelSpec(
        log_source="Device (USB) activity records (timestamped)",
        proxy_statistic=("Frequency distribution of device events and their inter-event intervals; "
                         "Shannon entropy of the interval histogram"),
        channel_name=CHANNEL_MOUSE,
        key="mouse_interaction_proxy",
    ),
    ChannelSpec(
        log_source="File, email and HTTP activity records (timestamped)",
        proxy_statistic=("Categorical resource-access embedding with sinusoidal session-position "
                         "encoding, aggregated by a single-layer GRU"),
        channel_name=CHANNEL_APPLICATION,
        key="application_sequencing",
    ),
]

#: The fourth row of Table 3: the explicitly excluded hardware categories.
EXCLUDED_ROW = ChannelSpec(
    log_source="None; no hardware sensor field exists in the release and none is read",
    proxy_statistic="Not applicable",
    channel_name="Explicitly excluded; reported in the Ethical Considerations statement",
    key="excluded",
)

#: Activity-log names that feed each channel.
SOURCE_LOGS: Dict[str, List[str]] = {
    "keystroke_timing_proxy": ["logon"],
    "mouse_interaction_proxy": ["device"],
    "application_sequencing": ["file", "email", "http"],
}


def channel_for_log(log_name: str) -> Optional[str]:
    """Return the channel key fed by an activity log, or None."""
    for key, logs in SOURCE_LOGS.items():
        if log_name in logs:
            return key
    return None


def all_source_logs() -> List[str]:
    """Every activity log consumed by the pipeline."""
    out: List[str] = []
    for logs in SOURCE_LOGS.values():
        out.extend(logs)
    return out


def table_3_rows() -> List[List[str]]:
    """Table 3 rendered as rows, for CSV export."""
    rows = [[c.log_source, c.proxy_statistic, c.channel_name] for c in TABLE_3]
    rows.append([EXCLUDED_ROW.log_source, EXCLUDED_ROW.proxy_statistic, EXCLUDED_ROW.channel_name])
    return rows
