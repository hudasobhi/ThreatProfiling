"""Keystroke timing proxy channel (paper Section 4.1.1, Eqs. 11-13).

The channel is built **entirely** from CERT r6.2 logon/session record
timestamps.  No key press or key release event exists in the release, so the
two quantities are inter-record intervals and are named *dwell proxy* and
*flight proxy*:

    Eq. (11)   d_i = tau_{i+1} - tau_i
    Eq. (12)   l_i = tau_{i+2} - tau_i
    Eq. (13)   k_t = [mu_d, sigma_d, P50_d, P90_d, mu_l, sigma_l, P50_l, P90_l]

``tau`` is an activity log record timestamp.  ``tests/test_no_hardware_fields.py``
asserts that no press/release/pointer/pressure quantity is read anywhere in
this module.
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd

#: Width of the feature vector produced by Eq. (13).
KEYSTROKE_FEATURE_DIM = 8

#: Names of the eight components of Eq. (13), in order.
KEYSTROKE_FEATURE_NAMES: List[str] = [
    "dwell_mean", "dwell_std", "dwell_p50", "dwell_p90",
    "flight_mean", "flight_std", "flight_p50", "flight_p90",
]


def _interval_stats(values: np.ndarray) -> List[float]:
    """Mean, population std, median and ninetieth percentile of an interval array."""
    if values.size == 0:
        return [0.0, 0.0, 0.0, 0.0]
    return [
        float(values.mean()),
        float(values.std()),
        float(np.median(values)),
        float(np.percentile(values, 90)),
    ]


def inter_record_intervals(session: pd.DataFrame,
                           time_col: str = "timestamp") -> Dict[str, np.ndarray]:
    """Compute the dwell and flight proxies for one session.

    Parameters
    ----------
    session:
        Records of a single session, sorted by time.

    Returns
    -------
    dict
        ``{"dwell": array, "flight": array}`` holding the intervals in seconds.
    """
    # Force nanosecond resolution explicitly: pandas may hold the column at
    # microsecond resolution, in which case a bare astype("int64") would
    # return microseconds and every interval would be 1000x too small.
    t = np.sort(session[time_col].to_numpy(dtype="datetime64[ns]").astype("int64")
                .astype(np.float64) / 1e9)
    if t.size < 2:
        return {"dwell": np.zeros(0), "flight": np.zeros(0)}
    # Eq. (11): d_i = tau_{i+1} - tau_i,  i = 1, ..., T_u - 1  ->  T_u - 1 values
    dwell = np.diff(t)
    # Eq. (12): l_i = tau_{i+2} - tau_i,  i = 1, ..., T_u - 2  ->  T_u - 2 values
    flight = (t[2:] - t[:-2]) if t.size >= 3 else np.zeros(0)
    return {"dwell": dwell, "flight": flight}


def session_keystroke_features(session: pd.DataFrame,
                               time_col: str = "timestamp") -> np.ndarray:
    """The Eq. (13) feature vector for one session."""
    iv = inter_record_intervals(session, time_col)
    return np.asarray(_interval_stats(iv["dwell"]) + _interval_stats(iv["flight"]),
                      dtype=np.float32)


def user_window_keystroke_features(events: pd.DataFrame,
                                   user_col: str = "user",
                                   window_col: str = "window_index",
                                   session_col: str = "session_id",
                                   time_col: str = "timestamp") -> pd.DataFrame:
    """Eq. (13) features for every (user, window) pair.

    Records inside a window are re-grouped into sessions, because the paper
    defines the proxy over "two consecutive log entries assigned to the same
    session" (Section 4.1.1).
    """
    rows: List[Dict[str, object]] = []
    for (user, window), grp in events.groupby([user_col, window_col], sort=True):
        feats = np.zeros(KEYSTROKE_FEATURE_DIM, dtype=np.float32)
        if session_col in grp.columns:
            groups = list(grp.groupby(session_col, sort=True))
        else:
            groups = [(None, grp)]
        for _, sess in groups:
            feats += session_keystroke_features(sess, time_col)
        n = max(len(groups), 1)
        row: Dict[str, object] = {user_col: user, window_col: int(window)}
        for name, value in zip(KEYSTROKE_FEATURE_NAMES, feats / n):
            row[name] = float(value)
        rows.append(row)
    return pd.DataFrame(rows, columns=[user_col, window_col] + KEYSTROKE_FEATURE_NAMES)
