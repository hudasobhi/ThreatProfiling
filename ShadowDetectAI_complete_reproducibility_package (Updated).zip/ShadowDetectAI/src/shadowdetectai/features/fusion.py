"""Multi-channel fusion (paper Section 4.1.4, Eq. 16).

The three channel embeddings are concatenated and projected into the shared
behavioural embedding space:

    Eq. (16)   f_t = W [h_ks ; h_mouse ; h_app] + b

with ``W`` and ``b`` trainable.  The output dimension is d = 128 (Table 6).
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np
import pandas as pd

from .proxy_mapping import CHANNEL_KEYS


def fuse_channels(channel_vectors: Dict[str, np.ndarray],
                  embed_dim: int = 128,
                  seed: Optional[int] = None) -> np.ndarray:
    """Concatenate channel vectors and project them with a linear layer.

    Parameters
    ----------
    channel_vectors:
        Mapping ``channel_key -> (n, d_channel)`` array.
    embed_dim:
        Width of the fused embedding (d = 128 in the paper).
    seed:
        When given, the projection is initialised deterministically.

    Returns
    -------
    numpy.ndarray
        Shape ``(n, embed_dim)``.
    """
    order = [k for k in ("keystroke_timing_proxy", "mouse_interaction_proxy",
                         "application_sequencing") if k in channel_vectors]
    if not order:
        raise ValueError("No channel vectors supplied to fuse_channels")
    widths = [channel_vectors[k].shape[1] for k in order]
    if len(set(widths)) != 1:
        widths = [max(widths)] * len(order)
    n = channel_vectors[order[0]].shape[0]
    stacked = np.concatenate([channel_vectors[k] for k in order], axis=1).astype(np.float32)
    rng = np.random.default_rng(seed)
    w = rng.normal(0.0, 1.0 / np.sqrt(stacked.shape[1]), size=(stacked.shape[1], embed_dim)).astype(np.float32)
    b = np.zeros(embed_dim, dtype=np.float32)
    return stacked @ w + b


def fuse_channels_torch(channel_vectors: Dict[str, "object"],
                        embed_dim: int = 128):
    """Differentiable version of :func:`fuse_channels` for training.

    Returns ``(fused, projection)`` where ``projection`` is the trainable
    ``nn.Linear`` module implementing Eq. (16).
    """
    import torch
    from torch import nn

    order = [k for k in ("keystroke_timing_proxy", "mouse_interaction_proxy",
                         "application_sequencing") if k in channel_vectors]
    widths = [channel_vectors[k].shape[1] for k in order]
    proj = nn.Linear(int(sum(widths)), embed_dim)
    stacked = torch.cat([channel_vectors[k] for k in order], dim=-1)
    return proj(stacked), proj


def channel_feature_frame(channel_frames: Dict[str, pd.DataFrame],
                           user_col: str = "user",
                           window_col: str = "window_index") -> pd.DataFrame:
    """Outer-join per-channel feature frames on (user, window)."""
    merged: Optional[pd.DataFrame] = None
    for key in ("keystroke_timing_proxy", "mouse_interaction_proxy",
                "application_sequencing"):
        df = channel_frames.get(key)
        if df is None:
            continue
        df = df.copy()
        if "vector" in df.columns:
            vec = df["vector"].tolist()
            df = df.drop(columns=["vector", "sequence"], errors="ignore")
            wide = pd.DataFrame([list(v) for v in vec],
                                columns=[f"{key}_f{i}" for i in range(len(vec[0]))] if vec else [])
            df = pd.concat([df.reset_index(drop=True), wide.reset_index(drop=True)], axis=1)
        df = df.rename(columns={c: f"{key}_{c}" for c in df.columns
                                if c not in (user_col, window_col)})
        merged = df if merged is None else merged.merge(df, on=[user_col, window_col], how="outer")
    if merged is None:
        raise ValueError("No channel frames supplied")
    return merged.sort_values([user_col, window_col]).reset_index(drop=True)
