"""Application usage sequencing channel (paper Section 4.1.3, Eq. 15).

Each application or resource access event is mapped to a learned categorical
embedding and combined with a sinusoidal positional encoding of its position
within the session:

    Eq. (15)   e_i = Emb(r_i) + PE(pos_i)

The sequence ``(e_1 ... e_n)`` inside a window is aggregated by a single-layer
gated recurrent unit into a fixed-length vector ``h_app``.

The channel is built from the CERT r6.2 file, email and HTTP activity logs.
Like the other two channels it reads no hardware telemetry: no key press, key
release, pointer-coordinate or click-pressure quantity is read at any stage.
"""
from __future__ import annotations

import math
from typing import List, Optional, Sequence

import numpy as np
import pandas as pd

#: Dimension of the learned categorical resource embedding.
APPLICATION_EMBED_DIM = 64


def sinusoidal_position_encoding(position: np.ndarray, dim: int) -> np.ndarray:
    """Standard sinusoidal positional encoding of Vaswani et al.

    Parameters
    ----------
    position:
        Integer positions, shape ``(n,)``.
    dim:
        Embedding width (must be even).

    Returns
    -------
    numpy.ndarray
        Shape ``(n, dim)``.
    """
    position = np.asarray(position, dtype=np.float64)[:, None]
    div = np.exp(np.arange(0, dim, 2) * (-math.log(10000.0) / dim))
    pe = np.zeros((position.shape[0], dim), dtype=np.float64)
    pe[:, 0::2] = np.sin(position * div)
    pe[:, 1::2] = np.cos(position * div)
    return pe.astype(np.float32)


class ApplicationSequenceEncoder:
    """Learned categorical embedding + positional encoding + single-layer GRU.

    Implements Eq. (15) and the GRU aggregation described in Section 4.1.3.
    The GRU is built lazily so that this module has no hard dependency on
    PyTorch at import time (the data-only utilities stay usable without it).
    """

    def __init__(self, vocab_size: int, embed_dim: int = APPLICATION_EMBED_DIM,
                 hidden_dim: int = APPLICATION_EMBED_DIM, num_layers: int = 1):
        self.vocab_size = max(int(vocab_size), 1)
        self.embed_dim = embed_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self._torch = None
        self._model = None
        self._built = False

    # -- lazy torch construction -------------------------------------------------
    def _build(self):
        if self._built:
            return
        import torch
        from torch import nn

        self._torch = torch
        vocab = self.vocab_size

        class _Net(nn.Module):
            def __init__(self, vocab, embed_dim, hidden_dim, num_layers):
                super().__init__()
                self.embedding = nn.Embedding(vocab, embed_dim)
                self.gru = nn.GRU(embed_dim, hidden_dim, num_layers=num_layers,
                                  batch_first=True)

            def forward(self, ids, positions):
                x = self.embedding(ids)
                pe = torch.from_numpy(
                    sinusoidal_position_encoding(positions.numpy(), x.shape[-1]))
                out, _ = self.gru(x + pe.to(x.device))
                return out[:, -1, :]

        self._model = _Net(vocab, self.embed_dim, self.hidden_dim, self.num_layers)
        self._built = True

    @property
    def model(self):
        self._build()
        return self._model

    def parameters(self):
        return self.model.parameters()

    def state_dict(self):
        return self.model.state_dict()

    def load_state_dict(self, state):
        self.model.load_state_dict(state)

    def encode_sequences(self, sequences: Sequence[Sequence[int]],
                         max_len: int = 64) -> np.ndarray:
        """Encode variable-length id sequences into fixed-length vectors."""
        import torch

        self._build()
        if not sequences:
            return np.zeros((0, self.hidden_dim), dtype=np.float32)
        clipped = [s[:max_len] for s in sequences]
        lengths = [max(len(s), 1) for s in clipped]
        padded = [list(s) + [0] * (max_len - len(s)) for s in clipped]
        ids = torch.tensor(padded, dtype=torch.long)
        pos = torch.tensor([[min(i, max_len - 1) for i in range(max_len)]
                            for _ in clipped], dtype=torch.long)
        self.model.eval()
        with torch.no_grad():
            out = self.model(ids, pos).cpu().numpy()
        return out.astype(np.float32)

    def train(self, mode: bool = True):
        self._build()
        self.model.train(mode)
        return self


def build_vocabulary(events: pd.DataFrame,
                     resource_col: str = "resource",
                     max_size: int = 50000) -> dict:
    """Map resource strings to integer ids (1-based; 0 is the padding id)."""
    counts = events[resource_col].astype(str).value_counts()
    vocab = {str(r): i + 1 for i, (r, _) in enumerate(counts.head(max_size).items())}
    return vocab


def user_window_application_features(events: pd.DataFrame,
                                     vocab: dict,
                                     encoder: ApplicationSequenceEncoder,
                                     user_col: str = "user",
                                     window_col: str = "window_index",
                                     session_col: str = "session_id",
                                     resource_col: str = "resource",
                                     max_len: int = 64) -> pd.DataFrame:
    """Application sequencing features for every (user, window) pair.

    Returns a frame whose columns are the user, the window index and
    ``app_seq_0 ... app_seq_{hidden-1}``.
    """
    rows = []
    for (user, window), grp in events.groupby([user_col, window_col], sort=True):
        if session_col in grp.columns:
            groups = list(grp.groupby(session_col, sort=True))
        else:
            groups = [(None, grp)]
        seqs = []
        for _, sess in groups:
            ids = [vocab.get(str(r), 0) for r in sess[resource_col].tolist()]
            if ids:
                seqs.append(ids)
        vec = encoder.encode_sequences(seqs, max_len=max_len)
        if vec.size == 0:
            vec = np.zeros((1, encoder.hidden_dim), dtype=np.float32)
        rows.append({user_col: user, window_col: int(window),
                     "sequence": seqs,
                     "vector": vec.mean(axis=0)})
    return pd.DataFrame(rows)
