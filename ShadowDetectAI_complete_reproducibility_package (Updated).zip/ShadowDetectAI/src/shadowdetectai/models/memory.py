"""Temporal Graph Network memory (paper Section 4.2, Eqs. 17-18).

Following Rossi et al. [24], when an interaction involving node ``u``
occurs a message is computed from the current memory states of the
interacting nodes,

    Eq. (17)   m_v(t) = msg( s_v(t^-), s_u(t), dt, s_u(t^-) )

where ``dt`` is the elapsed time since the node's previous interaction and
``msg`` is a two-layer feed-forward network.  The memory is then updated with
a gated recurrent unit,

    Eq. (18)   s_v(t) = GRU( m_v(t), s_v(t^-) ).

**Cold-start policy (Section 6.1).**  At every partition boundary the memory
state is reset to a zero vector, so that no state tensor from a training
window is propagated into the validation pass or from validation into test.
:func:`reset_memory` implements this and ``tests/test_memory_reset.py``
asserts it.
"""
from __future__ import annotations

from typing import Dict, Optional

import torch
from torch import nn


class MessageFunction(nn.Module):
    """The two-layer feed-forward ``msg`` of Eq. (17).

    Inputs are concatenated as ``[s_v, s_u, dt, s_u_prev]``.
    """

    def __init__(self, memory_dim: int):
        super().__init__()
        self.memory_dim = memory_dim
        self.net = nn.Sequential(
            nn.Linear(4 * memory_dim, memory_dim),
            nn.ReLU(),
            nn.Linear(memory_dim, memory_dim),
        )

    def forward(self, s_v: torch.Tensor, s_u: torch.Tensor,
                dt: torch.Tensor, s_u_prev: torch.Tensor) -> torch.Tensor:
        """Return the message for a batch of interactions."""
        dt_emb = dt.view(-1, 1).expand(-1, self.memory_dim)
        return self.net(torch.cat([s_v, s_u, dt_emb, s_u_prev], dim=-1))


class MemoryModule(nn.Module):
    """Per-node memory with the GRU update of Eq. (18)."""

    def __init__(self, memory_dim: int):
        super().__init__()
        self.memory_dim = memory_dim
        self.msg = MessageFunction(memory_dim)
        self.gru = nn.GRUCell(memory_dim, memory_dim)

    def forward(self, s_v: torch.Tensor, s_u: torch.Tensor,
                dt: torch.Tensor, s_u_prev: torch.Tensor) -> torch.Tensor:
        """One memory update step."""
        message = self.msg(s_v, s_u, dt, s_u_prev)
        return self.gru(message, s_v)


class MemoryStore:
    """A dictionary of node memories with an explicit reset.

    ``reset_memory`` implements the cold-start boundary required by
    Section 6.1; it is called between partitions by the trainer.
    """

    def __init__(self, memory_dim: int, device: Optional[torch.device] = None):
        self.memory_dim = memory_dim
        self.device = device or torch.device("cpu")
        self._state: Dict[object, torch.Tensor] = {}
        self._last_time: Dict[object, float] = {}

    def __len__(self) -> int:
        return len(self._state)

    def __contains__(self, node: object) -> bool:
        return node in self._state

    def get(self, node: object) -> torch.Tensor:
        """Return the memory of a node, or a zero vector if unseen."""
        return self._state.get(node, self.zero())

    def zero(self) -> torch.Tensor:
        return torch.zeros(self.memory_dim, device=self.device)

    def set(self, node: object, value: torch.Tensor, time: Optional[float] = None) -> None:
        self._state[node] = value
        if time is not None:
            self._last_time[node] = time

    def elapsed(self, node: object, current_time: float) -> float:
        """Seconds since the node's previous interaction (Eq. 17's ``dt``)."""
        if node not in self._last_time:
            return 0.0
        return max(current_time - self._last_time[node], 0.0)

    def reset_memory(self) -> None:
        """Zero every memory state.

        This is the cold-start reset required at every partition boundary
        (Section 6.1): no memory tensor from an earlier partition may be
        retained or propagated.
        """
        self._state.clear()
        self._last_time.clear()

    def state_norm(self) -> float:
        """Maximum L2 norm across all stored memories (used by leakage checks)."""
        if not self._state:
            return 0.0
        return float(max(float(v.norm().item()) for v in self._state.values()))

    def snapshot(self) -> Dict[object, torch.Tensor]:
        return {k: v.detach().clone() for k, v in self._state.items()}
