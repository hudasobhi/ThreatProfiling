"""Model components: behavioural encoder, TGN memory, temporal attention,
classifier and the composite training loss."""
