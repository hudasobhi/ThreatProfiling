"""Factories that build the proposed model and the six baselines from a config.

Keeping the factories in the package (rather than in the scripts) means the
training, evaluation, ablation and baseline scripts all construct models
identically, and the config drives every hyper-parameter.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

import torch
from torch import nn

from ..baselines.double_layer import DoubleLayerDetection
from ..baselines.exai import EXAIBaseline
from ..baselines.gaspar_mlp import GasparMLP
from ..baselines.graphch import GraphCH
from ..baselines.lan import LAN
from ..baselines.vggm import VGGM
from ..utils.config import get
from .tgnn import ShadowDetectAI, TGNConfig

BASELINE_TYPES = {
    "graphch": GraphCH,
    "lan": LAN,
    "double_layer": DoubleLayerDetection,
    "vggm": VGGM,
    "exai": EXAIBaseline,
    "gaspar_mlp": GasparMLP,
}


def make_model(cfg: Dict[str, Any]) -> nn.Module:
    """Build the model described by a resolved config.

    ``cfg["model"]["type"]`` selects the proposed model when absent, or one of
    the six baselines by name.
    """
    model_cfg = dict(get(cfg, "model", {}) or {})
    kind = str(model_cfg.pop("type", "shadowdetectai")).lower()

    if kind in BASELINE_TYPES:
        cls = BASELINE_TYPES[kind]
        feature_dim = int(get(cfg, "encoder.channel_dims.application_sequencing", 64))
        feature_dim = sum(int(v) for v in (get(cfg, "encoder.channel_dims", {}) or {}).values())
        kwargs: Dict[str, Any] = {}
        for key in ("hidden_dim", "num_layers", "num_heads", "dropout",
                    "latent_dim", "n_components"):
            if key in model_cfg:
                kwargs[key] = model_cfg[key]
        return cls(feature_dim, **kwargs)

    dims = get(cfg, "encoder.channel_dims", {}) or {}
    order = list(get(cfg, "encoder.channel_order", []) or [])
    tgnn_cfg = TGNConfig(
        channel_dims=tuple(int(dims.get(n, 0)) for n in order),
        embed_dim=int(get(cfg, "encoder.embed_dim", 128)),
        memory_dim=int(get(cfg, "model.memory_dim", get(cfg, "encoder.embed_dim", 128))),
        num_heads=int(get(cfg, "model.num_heads", 4)),
        use_attention=bool(get(cfg, "model.use_attention", True)),
        use_smoothness=bool(get(cfg, "model.use_smoothness", True)),
        smooth_lambda=float(get(cfg, "model.smooth_lambda", 0.1)),
        weight_decay_lambda=float(get(cfg, "model.reg_lambda", 1e-5)),
    )
    return ShadowDetectAI(tgnn_cfg)


def count_parameters(model: nn.Module) -> int:
    """Number of trainable parameters."""
    return int(sum(p.numel() for p in model.parameters() if p.requires_grad))
