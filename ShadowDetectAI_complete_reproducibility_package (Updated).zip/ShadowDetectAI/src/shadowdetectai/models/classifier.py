"""Classification head and the interpretable risk score (paper Section 3.3
and Section 4.2).

    Eq. (22)   z_{u,t} = W_cls [ z_u(t) ] + b
    Eq. (23)   p_{u,t} = sigma( z_{u,t} )
    Eq. (29)   s_t = sum_j phi_j   (attribution vector approximates the score)
"""
from __future__ import annotations

from typing import Optional

import torch
from torch import nn


class UserClassifier(nn.Module):
    """Per-user classification logit over the temporal embedding."""

    def __init__(self, embed_dim: int = 128, hidden_dim: Optional[int] = None):
        super().__init__()
        hidden_dim = hidden_dim or embed_dim
        self.net = nn.Sequential(
            nn.Linear(embed_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, embedding: torch.Tensor) -> torch.Tensor:
        """Return the logit ``z_{u,t}`` with shape ``(B,)``."""
        return self.net(embedding).squeeze(-1)


def sigmoid(x: torch.Tensor) -> torch.Tensor:
    """Eq. (23): the logistic function."""
    return torch.sigmoid(x)


class InterpretableRiskScore(nn.Module):
    """The analyst-facing score of Eq. (29).

    The score is presented as the attribution vector's contribution sum; where
    the neighborhood approximation of Section 4.3 applies, the attribution
    vector closely approximates the risk score.
    """

    def __init__(self):
        super().__init__()

    @staticmethod
    def from_attribution(attribution: torch.Tensor) -> torch.Tensor:
        """Sum the per-feature contributions (Eq. 29)."""
        return attribution.sum(dim=-1)

    @staticmethod
    def from_logit(logit: torch.Tensor) -> torch.Tensor:
        """Fallback when no attribution is available."""
        return torch.sigmoid(logit)
