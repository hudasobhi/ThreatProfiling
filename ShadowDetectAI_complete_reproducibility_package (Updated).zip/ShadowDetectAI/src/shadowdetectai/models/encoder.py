"""Multi-channel behavioural encoder (paper Section 4.1, Eq. 16).

The encoder converts the session-level proxy statistics of the three channels
into a single fused embedding per user per window.  Channel-separated
statistics are kept until fusion rather than pooled into one undifferentiated
feature vector (Section 4.1.4).
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import torch
from torch import nn


class MultiChannelBehavioralEncoder(nn.Module):
    """Projects the three channel embeddings into the shared d = 128 space.

    Implements Eq. (16)

        f_t = W [ h_ks ; h_mouse ; h_app ] + b

    with ``W`` and ``b`` trainable and the channel order fixed to the
    keystroke timing proxy, mouse interaction proxy and application usage
    sequencing channels of Table 3.
    """

    CHANNEL_ORDER = ("keystroke_timing_proxy", "mouse_interaction_proxy",
                     "application_sequencing")

    def __init__(self, channel_dims: Sequence[int], embed_dim: int = 128):
        super().__init__()
        if len(channel_dims) != len(self.CHANNEL_ORDER):
            raise ValueError(
                f"expected {len(self.CHANNEL_ORDER)} channel dims, got {len(channel_dims)}")
        self.channel_dims = list(int(d) for d in channel_dims)
        self.embed_dim = int(embed_dim)
        self.projection = nn.Linear(sum(self.channel_dims), self.embed_dim)

    def forward(self, channel_vectors: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Fuse the three channel vectors.

        Parameters
        ----------
        channel_vectors:
            Mapping channel key -> tensor of shape ``(B, d_channel)``.
        """
        missing = [k for k in self.CHANNEL_ORDER if k not in channel_vectors]
        if missing:
            raise KeyError(f"missing channel vectors: {missing}")
        stacked = torch.cat([channel_vectors[k] for k in self.CHANNEL_ORDER], dim=-1)
        return self.projection(stacked)

    @property
    def num_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters())


class MeanPoolingAttention(nn.Module):
    """Uniform neighbourhood averaging, used by the ``no_attention`` ablation.

    It replaces Eq. (20) with a plain mean over the neighbourhood so that the
    learned attention can be shown to contribute beyond adding parameters
    (Section 6.4, Table 11).
    """

    def __init__(self, memory_dim: int, embed_dim: int, num_heads: int = 4):
        super().__init__()
        self.memory_dim = memory_dim
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = max(embed_dim // num_heads, 1)
        self.w3 = nn.Linear(memory_dim, num_heads * self.head_dim, bias=False)
        self.gate = nn.Linear(memory_dim + embed_dim, embed_dim)

    def forward(self, node_memory, neighbour_memory, node_features,
                neighbour_features, neighbour_mask=None):
        b, n = neighbour_memory.shape[0], neighbour_memory.shape[1]
        if neighbour_mask is not None:
            denom = neighbour_mask.sum(dim=1, keepdim=True).clamp(min=1).unsqueeze(-1)
            mean_mem = (neighbour_memory * neighbour_mask.unsqueeze(-1)).sum(1) / denom
        else:
            mean_mem = neighbour_memory.mean(dim=1)
        values = self.w3(mean_mem).view(b, self.num_heads, self.head_dim)
        out = values.reshape(b, self.num_heads * self.head_dim)[:, : self.embed_dim]
        g = torch.sigmoid(self.gate(torch.cat([node_memory, node_features], dim=-1)))
        alpha = torch.full((b, self.num_heads, n), 1.0 / max(n, 1), device=out.device)
        return out * g, alpha
