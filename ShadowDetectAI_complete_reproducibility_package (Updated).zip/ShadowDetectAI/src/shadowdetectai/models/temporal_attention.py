"""Temporal attention over the recent neighbourhood (paper Section 4.2,
Eqs. 19-21).

    Eq. (19)   z_v(t) = sigma( W_1 [ s_v(t) ; h_v(t) ] )
    Eq. (20)   alpha_v(t,u) = softmax_u( LeakyReLU( W_2 [ s_v(t) ; s_u(t) ] ) )
    Eq. (21)   z_v(t) = ||_k ( sum_u alpha^k_v(t,u) W_3^k s_u(t) )

Four attention heads are used (Table 6).
"""
from __future__ import annotations

from typing import Optional, Tuple

import torch
from torch import nn


class TemporalAttention(nn.Module):
    """Multi-head temporal attention with ``num_heads`` heads (default 4)."""

    def __init__(self, memory_dim: int, embed_dim: int, num_heads: int = 4):
        super().__init__()
        if num_heads <= 0:
            raise ValueError("num_heads must be positive")
        self.memory_dim = memory_dim
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = max(embed_dim // num_heads, 1)

        self.w1 = nn.Linear(memory_dim + embed_dim, embed_dim)
        self.w2 = nn.Linear(2 * memory_dim, num_heads)
        self.w3 = nn.Linear(memory_dim, num_heads * self.head_dim, bias=False)
        self.leaky_relu = nn.LeakyReLU(0.2)

    def forward(self, node_memory: torch.Tensor,
                neighbour_memory: torch.Tensor,
                node_features: torch.Tensor,
                neighbour_features: torch.Tensor,
                neighbour_mask: Optional[torch.Tensor] = None
                ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute the temporal embedding and the attention coefficients.

        Parameters
        ----------
        node_memory:
            ``(B, memory_dim)`` memory of the target node.
        neighbour_memory:
            ``(B, N, memory_dim)`` memory of its neighbours.
        node_features:
            ``(B, embed_dim)`` fused behavioural embedding of the target node.
        neighbour_features:
            ``(B, N, embed_dim)`` embeddings of the neighbours.
        neighbour_mask:
            Optional ``(B, N)`` boolean mask, ``True`` for valid neighbours.

        Returns
        -------
        (embedding, coefficients)
            Embedding has shape ``(B, embed_dim)``; coefficients ``(B, heads, N)``.
        """
        b, n = neighbour_memory.shape[0], neighbour_memory.shape[1]

        # Eq. (19): gate on the node's own memory and features.
        gate = torch.sigmoid(self.w1(torch.cat([node_memory, node_features], dim=-1)))
        gate = gate.unsqueeze(1)                                   # (B, 1, E)

        # Eq. (20): attention logits over the neighbourhood.
        s_v_exp = node_memory.unsqueeze(1).expand(-1, n, -1)
        logits = self.leaky_relu(self.w2(torch.cat([s_v_exp, neighbour_memory], dim=-1)))
        if neighbour_mask is not None:
            logits = logits.masked_fill(~neighbour_mask.unsqueeze(1), float("-inf"))
        alpha = torch.softmax(logits, dim=-1)                      # (B, heads, N)
        alpha = torch.nan_to_num(alpha, nan=0.0)

        # Eq. (21): per-head value projection and weighted sum.
        values = self.w3(neighbour_memory).view(b, n, self.num_heads, self.head_dim)
        values = values.permute(0, 2, 1, 3)                        # (B, heads, N, head_dim)
        out = torch.einsum("bhn,bhnd->bhd", alpha, values)
        out = out.reshape(b, self.num_heads * self.head_dim)
        if out.shape[-1] < self.embed_dim:
            out = torch.nn.functional.pad(out, (0, self.embed_dim - out.shape[-1]))
        out = out[:, : self.embed_dim]
        return out * gate.squeeze(1), alpha
