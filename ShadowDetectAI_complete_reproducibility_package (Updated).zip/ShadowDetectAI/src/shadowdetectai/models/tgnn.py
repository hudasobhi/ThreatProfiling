"""The ShadowDetectAI temporal graph neural network (paper Section 4.2).

The model is a Temporal Graph Network in the sense of Rossi et al. [24]:
node memory is updated with Eq. (18) as interactions arrive, the temporal
embedding is formed by the multi-head attention of Eqs. (19)-(21), and the
classification logit follows from Eq. (22).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import torch
from torch import nn

from .classifier import UserClassifier
from .encoder import MeanPoolingAttention, MultiChannelBehavioralEncoder
from .memory import MemoryStore
from .temporal_attention import TemporalAttention


@dataclass
class TGNConfig:
    """Architecture hyper-parameters (Table 6 and Section 4.2)."""

    channel_dims: Tuple[int, int, int] = (8, 6, 64)
    embed_dim: int = 128
    memory_dim: int = 128
    num_heads: int = 4
    use_attention: bool = True
    use_smoothness: bool = True
    smooth_lambda: float = 0.1
    weight_decay_lambda: float = 1e-5
    num_layers: int = 1


class ShadowDetectAI(nn.Module):
    """The full model: encoder -> TGN -> classifier.

    Parameters
    ----------
    config:
        :class:`TGNConfig` holding the architecture hyper-parameters.
    """

    def __init__(self, config: Optional[TGNConfig] = None):
        super().__init__()
        self.config = config or TGNConfig()
        cfg = self.config
        self.encoder = MultiChannelBehavioralEncoder(cfg.channel_dims, cfg.embed_dim)
        if cfg.use_attention:
            self.attention = TemporalAttention(cfg.memory_dim, cfg.embed_dim, cfg.num_heads)
        else:
            self.attention = MeanPoolingAttention(cfg.memory_dim, cfg.embed_dim, cfg.num_heads)
        self.classifier = UserClassifier(cfg.embed_dim)
        self.memory_module = None  # created lazily by MemoryStore usage

    # -- memory ------------------------------------------------------------------
    def new_memory_store(self, device: Optional[torch.device] = None) -> MemoryStore:
        """Create a fresh :class:`MemoryStore` with the configured memory width."""
        return MemoryStore(self.config.memory_dim, device=device)

    # -- forward -----------------------------------------------------------------
    def forward(self,
                channel_vectors: Dict[str, torch.Tensor],
                node_memory: torch.Tensor,
                neighbour_memory: torch.Tensor,
                neighbour_mask: Optional[torch.Tensor] = None,
                neighbour_features: Optional[torch.Tensor] = None
                ) -> Dict[str, torch.Tensor]:
        """Run one inference pass over a window.

        Parameters
        ----------
        channel_vectors:
            Mapping channel key -> ``(B, d_channel)``.
        node_memory:
            ``(B, memory_dim)`` current memory of the target user.
        neighbour_memory:
            ``(B, N, memory_dim)`` memory of the neighbourhood.
        neighbour_features:
            ``(B, N, embed_dim)`` fused embeddings of the neighbourhood.

        Returns
        -------
        dict
            ``{"embedding", "logit", "probability", "attention"}``.
        """
        fused = self.encoder(channel_vectors)                       # Eq. (16)
        if neighbour_features is None:
            neighbour_features = torch.zeros(
                neighbour_memory.shape[0], neighbour_memory.shape[1],
                self.config.embed_dim, device=fused.device)
        embedding, alpha = self.attention(
            node_memory, neighbour_memory, fused, neighbour_features, neighbour_mask)
        logit = self.classifier(embedding)                          # Eq. (22)
        return {
            "embedding": embedding,
            "logit": logit,
            "probability": torch.sigmoid(logit),                    # Eq. (23)
            "attention": alpha,
            "fused": fused,
        }

    # -- smoothness --------------------------------------------------------------
    def smoothness_penalty(self, embeddings: torch.Tensor) -> torch.Tensor:
        """Eq. (24): penalise abrupt change of embeddings between windows.

        Parameters
        ----------
        embeddings:
            ``(T, B, E)`` embeddings for ``T`` consecutive windows.
        """
        if embeddings.shape[0] < 2:
            return embeddings.new_zeros(())
        return (embeddings[1:] - embeddings[:-1]).pow(2).mean()
