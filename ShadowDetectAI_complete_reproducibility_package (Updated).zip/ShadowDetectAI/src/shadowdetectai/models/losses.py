"""Composite training loss (paper Section 5.4, Eqs. 36-37).

    Eq. (36)   L = L_bce + lambda_smooth * L_smooth + lambda_reg * L_reg
    Eq. (37)   L_bce = -(1/N) sum_u [ y_u log p_u + (1 - y_u) log(1 - p_u) ]

``lambda_smooth`` and ``lambda_reg`` are the scalar weighting
hyper-parameters.  The paper does not state their values, so they are
**[NOT STATED IN PAPER]** and default to 0.1 and 1e-5 respectively, with the
defaults exposed in ``configs/default.yaml``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import torch
from torch import nn

#: Default weight of the temporal smoothness regulariser. [NOT STATED IN PAPER]
DEFAULT_SMOOTH_LAMBDA = 0.1
#: Default L2 weight-decay coefficient. [NOT STATED IN PAPER]
DEFAULT_WEIGHT_DECAY_LAMBDA = 1e-5


@dataclass
class LossWeights:
    """The two scalar weighting hyper-parameters of Eq. (36)."""

    smooth: float = DEFAULT_SMOOTH_LAMBDA
    reg: float = DEFAULT_WEIGHT_DECAY_LAMBDA


def binary_cross_entropy(logit: torch.Tensor, label: torch.Tensor,
                         weight: Optional[torch.Tensor] = None) -> torch.Tensor:
    """Eq. (37): the binary cross-entropy term."""
    loss = nn.functional.binary_cross_entropy_with_logits(
        logit, label.to(logit.dtype), weight=weight, reduction="mean")
    return loss


def composite_loss(logit: torch.Tensor,
                   label: torch.Tensor,
                   smoothness: Optional[torch.Tensor] = None,
                   weights: Optional[LossWeights] = None,
                   model: Optional[nn.Module] = None) -> Dict[str, torch.Tensor]:
    """The composite objective of Eq. (36).

    Returns a dict with ``"total"``, ``"bce"``, ``"smooth"`` and ``"reg"``.
    """
    w = weights or LossWeights()
    bce = binary_cross_entropy(logit, label)
    smooth = smoothness if smoothness is not None else logit.new_zeros(())
    reg = logit.new_zeros(())
    if model is not None:
        l2 = torch.stack([p.pow(2).sum() for p in model.parameters() if p.requires_grad])
        reg = l2.mean() if l2.numel() else reg
    total = bce + w.smooth * smooth + w.reg * reg
    return {"total": total, "bce": bce, "smooth": smooth, "reg": reg}
