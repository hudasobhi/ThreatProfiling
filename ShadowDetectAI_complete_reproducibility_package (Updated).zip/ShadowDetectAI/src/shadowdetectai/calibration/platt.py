"""Platt scaling (paper Section 5.1, Eq. 31).

    Eq. (31)   p = sigma( a * z + b )

with ``a`` and ``b`` fitted by maximum likelihood on a held-out calibration
set, producing probabilities that are directly comparable across users and
time windows.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

try:
    from sklearn.linear_model import LogisticRegression
except ImportError:  # pragma: no cover
    LogisticRegression = None  # type: ignore


@dataclass
class PlattScaler:
    """Fitted Platt parameters ``(a, b)``."""

    a: float = 1.0
    b: float = 0.0
    fitted: bool = False

    def transform(self, logits: np.ndarray) -> np.ndarray:
        """Apply Eq. (31) to an array of raw logits."""
        logits = np.asarray(logits, dtype=np.float64)
        return 1.0 / (1.0 + np.exp(-(self.a * logits + self.b)))

    def fit(self, logits: np.ndarray, labels: np.ndarray) -> "PlattScaler":
        """Fit ``a`` and ``b`` by maximum likelihood."""
        logits = np.asarray(logits, dtype=np.float64).reshape(-1)
        labels = np.asarray(labels, dtype=np.float64).reshape(-1)
        if LogisticRegression is not None and len(np.unique(labels)) > 1:
            lr = LogisticRegression(C=1e6, solver="lbfgs", max_iter=1000)
            lr.fit(logits.reshape(-1, 1), labels)
            self.a = float(lr.coef_[0][0])
            self.b = float(lr.intercept_[0])
        else:
            # Degenerate calibration set: fall back to an identity scaling.
            self.a, self.b = 1.0, 0.0
        self.fitted = True
        return self

    def to_dict(self) -> dict:
        return {"a": self.a, "b": self.b, "fitted": self.fitted}


def fit_platt(logits: np.ndarray, labels: np.ndarray) -> PlattScaler:
    """Convenience wrapper returning a fitted :class:`PlattScaler`."""
    return PlattScaler().fit(logits, labels)
