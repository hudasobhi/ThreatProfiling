"""PSI-driven adaptive detection threshold (paper Section 5.2, Eq. 33).

    Eq. (33)   tau_t = tau_0 * ( 1 + lambda_drift * PSI_t )

``tau_0`` is the threshold fitted at training time and ``lambda_drift``
controls how aggressively the threshold responds to drift, preventing benign
organisational change from triggering a wave of false alerts while still
tightening the threshold if drift is accompanied by genuine label-confirmed
threat activity during retraining cycles.

``lambda_drift`` is **[NOT STATED IN PAPER]**; the default of 0.1 is used and
is exposed in ``configs/calibration.yaml``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np


@dataclass
class AdaptiveThreshold:
    """The threshold policy of Eq. (33)."""

    tau_0: float = 0.5
    lambda_drift: float = 0.1

    def apply(self, psi: float) -> float:
        """Return the adapted threshold for a PSI value."""
        return float(self.tau_0 * (1.0 + self.lambda_drift * float(psi)))

    def series(self, psi_values) -> np.ndarray:
        """Adapted thresholds for a sequence of PSI values."""
        return np.asarray([self.apply(p) for p in psi_values], dtype=np.float64)


def fit_base_threshold(scores: np.ndarray, target_fpr: float = 0.01) -> float:
    """Fit the training-time threshold ``tau_0`` at a target false-positive rate.

    The target FPR is **[NOT STATED IN PAPER]**; 1% is used, matching the
    operating point implied by the confusion matrix of Table 9
    (1 false positive out of 20591 benign windows).
    """
    scores = np.asarray(scores, dtype=np.float64)
    if scores.size == 0:
        return 0.5
    return float(np.quantile(scores, 1.0 - target_fpr))
