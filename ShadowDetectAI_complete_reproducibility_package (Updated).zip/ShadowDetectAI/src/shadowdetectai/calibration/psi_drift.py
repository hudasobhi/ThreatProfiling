"""Population stability index (paper Section 5.2, Eq. 32).

    Eq. (32)   PSI = sum_i ( p_i - q_i ) * ln( p_i / q_i )

with ``p`` the calibrated score distribution at deployment time and ``q`` the
reference distribution fitted at training time, over ``K`` score bins.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np

_EPS = 1e-6


def _bin_edges(reference: np.ndarray, n_bins: int) -> np.ndarray:
    """Quantile bin edges from the reference sample, open at both ends."""
    edges = np.quantile(reference, np.linspace(0, 1, n_bins + 1))
    edges = np.asarray(edges, dtype=np.float64)
    edges[0] = -np.inf
    edges[-1] = np.inf
    # Guarantee strictly increasing finite interior edges.
    interior = edges[1:-1]
    interior = np.maximum.accumulate(interior)
    edges[1:-1] = interior
    return edges


def population_stability_index(reference: Sequence[float],
                               current: Sequence[float],
                               n_bins: int = 10) -> float:
    """Eq. (32): the PSI between two score distributions.

    Both distributions are binned on the *reference* quantiles, which is the
    standard definition and the one the paper's Eq. (32) implies.
    """
    ref = np.asarray(reference, dtype=np.float64)
    cur = np.asarray(current, dtype=np.float64)
    if ref.size == 0 or cur.size == 0:
        return 0.0
    edges = _bin_edges(ref, n_bins)
    q = np.histogram(ref, bins=edges)[0].astype(np.float64) / ref.size
    p = np.histogram(cur, bins=edges)[0].astype(np.float64) / cur.size
    q = np.clip(q, _EPS, None)
    p = np.clip(p, _EPS, None)
    return float(np.sum((p - q) * np.log(p / q)))


@dataclass
class PSIReference:
    """The reference distribution fitted at training time.

    The reference *histogram* is stored alongside the bin edges, because the
    reference probabilities ``q`` of Eq. (32) cannot be recovered from the
    edges alone.
    """

    edges: np.ndarray
    reference_probs: np.ndarray
    n_bins: int = 10

    @classmethod
    def fit(cls, reference: Sequence[float], n_bins: int = 10) -> "PSIReference":
        """Fit the reference distribution from a training-time score sample."""
        ref = np.asarray(reference, dtype=np.float64)
        if ref.size == 0:
            raise ValueError("cannot fit a PSI reference on an empty sample")
        edges = _bin_edges(ref, n_bins)
        counts = np.histogram(ref, bins=edges)[0].astype(np.float64)
        probs = counts / ref.size
        return cls(edges=edges, reference_probs=probs, n_bins=n_bins)

    def compute(self, current: Sequence[float]) -> float:
        """PSI of a deployment-time distribution against this reference."""
        cur = np.asarray(current, dtype=np.float64)
        if cur.size == 0:
            return 0.0
        p = np.histogram(cur, bins=self.edges)[0].astype(np.float64) / cur.size
        q = np.clip(self.reference_probs, _EPS, None)
        p = np.clip(p, _EPS, None)
        return float(np.sum((p - q) * np.log(p / q)))

    def to_dict(self) -> dict:
        return {
            "n_bins": self.n_bins,
            "edges": [float(e) for e in self.edges],
            "reference_probs": [float(p) for p in self.reference_probs],
        }
