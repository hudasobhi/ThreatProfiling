"""Adaptive risk calibration and alert fusion (paper Section 5)."""
