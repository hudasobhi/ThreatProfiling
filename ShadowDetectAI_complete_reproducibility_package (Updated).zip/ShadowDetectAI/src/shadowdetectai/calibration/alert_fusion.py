"""Role-conditioned multi-channel alert fusion (paper Section 5.3, Eqs. 34-35).

Because the three behavioural channels are not equally reliable for every user
role - a role with minimal device interaction yields a noisier mouse
interaction proxy signal - channel-specific scores are fused with learned,
role-conditioned weights:

    Eq. (34)   s_c = Platt_c( z_c )
    Eq. (35)   s_fused = sum_c softmax(alpha(role))_c * s_c

where ``alpha`` are trainable logits learned jointly with the rest of the
network.
"""
from __future__ import annotations

from typing import Dict, Mapping, Optional, Sequence

import numpy as np


def role_conditioned_weights(logits: Mapping[str, float],
                             roles: Optional[Mapping[str, str]] = None,
                             n_roles: int = 1) -> Dict[str, np.ndarray]:
    """Softmax weights of Eq. (35) for each role.

    Parameters
    ----------
    logits:
        Trainable per-channel logits ``alpha``, shared across roles unless a
        role-specific vector is supplied.
    roles:
        Optional mapping ``role -> channel -> logit`` for learned
        role-conditioned weights.
    """
    channels = list(logits.keys())
    if roles:
        out: Dict[str, np.ndarray] = {}
        for role, role_logits in roles.items():
            vec = np.asarray([float(role_logits.get(c, logits[c])) for c in channels])
            vec = vec - vec.max()
            e = np.exp(vec)
            out[role] = e / e.sum()
        return out
    vec = np.asarray([float(logits[c]) for c in channels])
    vec = vec - vec.max()
    e = np.exp(vec)
    return {"__default__": e / e.sum()}


def fuse_scores(channel_scores: Mapping[str, float],
                weights: Mapping[str, np.ndarray],
                role: Optional[str] = None) -> float:
    """Eq. (35): the fused risk score presented to the analyst."""
    channels = list(channel_scores.keys())
    w = weights.get(role, weights.get("__default__"))
    if w is None:
        raise KeyError("no fusion weights for this role")
    if len(w) != len(channels):
        raise ValueError("weight vector length does not match the channel count")
    return float(sum(float(wi) * float(channel_scores[c]) for wi, c in zip(w, channels)))
