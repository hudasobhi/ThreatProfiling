"""Chronological partitioning of CERT r6.2 and the cold-start memory policy.

Paper Section 6.1: the corpus spans 18 months.  Training covers months 1-13
(approximately 70% of the labelled windows), validation covers months 14 and
15 (approximately 15%) and test covers months 16-18 (approximately 15%).  The
three partitions are temporally contiguous, with **no gap month**, and the
absence of a gap is acknowledged as a limitation.

The paper also requires a cold-start memory at every partition boundary:
"the TGN memory state is explicitly reset to a zero vector at each partition
boundary".  :func:`partition_manifest` records the split so that the boundary
is reproducible and auditable.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

#: Month ranges (1-based, inclusive) of the 18-month simulation.
PARTITION_MONTHS: Dict[str, Sequence[int]] = {
    "train": tuple(range(1, 14)),        # months 1-13
    "validation": (14, 15),              # months 14-15
    "test": tuple(range(16, 19)),        # months 16-18
}

PARTITION_ORDER: Sequence[str] = ("train", "validation", "test")


@dataclass
class PartitionManifest:
    """Auditable record of the chronological split."""

    window_hours: int
    origin: str
    bounds: Dict[str, Dict[str, object]]
    no_gap_month: bool = True
    cold_start_memory: bool = True
    notes: str = ""

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)


def _month_bounds(origin: pd.Timestamp, months: Sequence[int]) -> Dict[str, object]:
    first = pd.Timestamp(year=origin.year, month=origin.month, day=1) + pd.DateOffset(months=months[0] - 1)
    last = pd.Timestamp(year=origin.year, month=origin.month, day=1) + pd.DateOffset(months=months[-1])
    return {"start": str(first), "end_exclusive": str(last)}


def partition_manifest(events: pd.DataFrame,
                       window_hours: int = 24,
                       time_col: str = "timestamp") -> PartitionManifest:
    """Build the manifest describing the chronological partition boundaries."""
    origin = pd.Timestamp(events[time_col].min()).normalize()
    bounds = {name: _month_bounds(origin, months) for name, months in PARTITION_MONTHS.items()}
    return PartitionManifest(
        window_hours=window_hours,
        origin=str(origin),
        bounds=bounds,
        no_gap_month=True,
        cold_start_memory=True,
        notes=("Training months 1-13, validation months 14-15, test months 16-18. "
               "The partitions are contiguous with no gap month; the absence of a gap "
               "is a stated limitation of the paper (Section 6.1)."),
    )


def assign_partitions(events: pd.DataFrame,
                      manifest: PartitionManifest,
                      window_col: str = "window_index",
                      time_col: str = "timestamp") -> pd.Series:
    """Assign each event to a partition name by its window start time."""
    origin = pd.Timestamp(manifest.origin)
    out = pd.Series(pd.NA, index=events.index, dtype="object")
    for name in PARTITION_ORDER:
        b = manifest.bounds[name]
        start = pd.Timestamp(b["start"])
        end = pd.Timestamp(b["end_exclusive"])
        mask = (events[time_col] >= start) & (events[time_col] < end)
        out.loc[mask] = name
    return out


def split_windows(window_index: pd.Series,
                  manifest: PartitionManifest,
                  window_hours: int = 24) -> pd.Series:
    """Assign a window index to a partition, using the window grid."""
    origin = pd.Timestamp(manifest.origin)
    starts = origin + pd.to_timedelta(window_index * window_hours, unit="h")
    out = pd.Series(pd.NA, index=window_index.index, dtype="object")
    for name in PARTITION_ORDER:
        b = manifest.bounds[name]
        mask = (starts >= pd.Timestamp(b["start"])) & (starts < pd.Timestamp(b["end_exclusive"]))
        out.loc[mask] = name
    return out


def partition_report(labels: pd.DataFrame,
                      manifest: PartitionManifest,
                      window_hours: int = 24) -> pd.DataFrame:
    """Reproduce Table 5: users, windows, malicious windows, identities, split."""
    part = split_windows(labels["window_index"], manifest, window_hours)
    lab = labels.copy()
    lab["partition"] = part.values
    rows = []
    for name in PARTITION_ORDER:
        sub = lab[lab["partition"] == name]
        malicious = sub[sub["label"] == 1]
        rows.append({
            "partition": name,
            "users": int(sub["user"].nunique()),
            "windows": int(len(sub)),
            "malicious_windows": int(len(malicious)),
            "malicious_identities": int(malicious["user"].nunique()),
        })
    total = sum(r["windows"] for r in rows) or 1
    for r in rows:
        r["split_window_pct"] = round(100.0 * r["windows"] / total, 1)
    return pd.DataFrame(rows)


def write_manifest(manifest: PartitionManifest, path: str | Path) -> None:
    """Persist the manifest to ``data/splits/partition_manifest.json``."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(manifest.to_json() + "\n", encoding="utf-8")
