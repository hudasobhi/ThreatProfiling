"""Assemble the trainable tensors from the processed artefacts.

This is the glue between ``data/preprocess.py`` and the training scripts.  It
loads the three proxy feature tables, rebuilds the dynamic interaction graph
for every window, and materialises the tensors the TGN consumes:

  * ``features``            - the three channel blocks, concatenated
  * ``node_features``       - the fused behavioural embedding of the user
  * ``neighbour_features``  - the fused embeddings of the user's neighbours
  * ``neighbour_mask``      - validity mask for the padded neighbour tensor
  * ``label``               - the binary malicious-window label
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch

from .dataset import WindowFrame
from .graph_builder import build_window_graph
from .partition import PARTITION_ORDER, split_windows
from ..utils.config import load_config


def load_processed(processed_dir: str | Path) -> Dict[str, pd.DataFrame]:
    """Load the three processed proxy tables and the label table."""
    p = Path(processed_dir)
    out: Dict[str, pd.DataFrame] = {}
    for key, name in (("keystroke_timing_proxy", "keystroke_timing_proxy.csv"),
                      ("mouse_interaction_proxy", "mouse_interaction_proxy.csv"),
                      ("application_sequencing", "application_events.csv"),
                      ("labels", "labels.csv")):
        path = p / name
        if path.exists():
            out[key] = pd.read_csv(path)
        else:
            out[key] = pd.DataFrame()
    return out


def channel_slices(channel_dims: Dict[str, int],
                    order: Sequence[str]) -> Dict[str, slice]:
    """The slice of each channel inside the concatenated feature vector."""
    slices: Dict[str, slice] = {}
    start = 0
    for name in order:
        width = int(channel_dims.get(name, 0))
        slices[name] = slice(start, start + width)
        start += width
    return slices


def build_window_frame(processed_dir: str | Path,
                       config_path: str | Path,
                       partition: str,
                       max_neighbours: int = 32) -> WindowFrame:
    """Materialise the tensors for one partition."""
    cfg = load_config(config_path)
    dims = cfg["encoder"]["channel_dims"]
    order = list(cfg["encoder"]["channel_order"])
    embed_dim = int(cfg["encoder"]["embed_dim"])

    data = load_processed(processed_dir)
    ks, mouse = data["keystroke_timing_proxy"], data["mouse_interaction_proxy"]
    app, labels = data["application_sequencing"], data["labels"]

    if ks.empty or mouse.empty:
        raise FileNotFoundError(
            "processed proxy tables are missing; run scripts/01_preprocess.py first")

    key = ["user", "window_index"]
    merged = ks.merge(mouse, on=key, how="outer")
    # Only the numeric feature columns are used; the partition tag and any
    # other bookkeeping column is excluded.
    ks_cols = [c for c in ks.columns
               if c not in key and pd.api.types.is_numeric_dtype(ks[c])]
    mouse_cols = [c for c in mouse.columns
                  if c not in key and pd.api.types.is_numeric_dtype(mouse[c])]
    if not app.empty:
        merged = merged.merge(
            app.groupby(key, sort=True).size().reset_index(name="n_app_events"),
            on=key, how="left")
    if not labels.empty:
        merged = merged.merge(labels[key + ["label"]], on=key, how="left")
    merged["label"] = merged["label"].fillna(0).astype(int)

    slices = channel_slices(dims, order)
    feat_blocks = []
    for name, cols in (("keystroke_timing_proxy", ks_cols),
                       ("mouse_interaction_proxy", mouse_cols)):
        width = slices[name].stop - slices[name].start
        block = merged[cols].to_numpy(dtype=np.float32) if cols else \
            np.zeros((len(merged), 0), dtype=np.float32)
        if block.shape[1] < width:
            pad = np.zeros((block.shape[0], width - block.shape[1]), dtype=np.float32)
            block = np.concatenate([block, pad], axis=1)
        feat_blocks.append(block[:, :width])
    total_width = sum(b.shape[1] for b in feat_blocks)
    features = np.concatenate(feat_blocks, axis=1) if feat_blocks else \
        np.zeros((len(merged), 0), dtype=np.float32)

    # Node features: the fused embedding is produced by the Eq. (16)
    # projection inside the model, so the graph builder is given the raw
    # channel blocks as the node feature matrix.
    node_features = features
    n = len(merged)
    neighbour_features = np.zeros((n, max_neighbours, embed_dim), dtype=np.float32)
    neighbour_mask = np.zeros((n, max_neighbours), dtype=bool)

    # Resource nodes are the resources the user touched inside the window.
    if not app.empty and "resource" in app.columns:
        res_by_user = (app.groupby(["user", "window_index"])["resource"]
                       .apply(lambda s: sorted(set(s.astype(str))))).to_dict()
    else:
        res_by_user = {}

    for i, (u, w) in enumerate(zip(merged["user"].astype(str), merged["window_index"])):
        res = res_by_user.get((u, int(w)), [])
        if not res:
            continue
        k = min(len(res), max_neighbours)
        neighbour_features[i, :k, : min(embed_dim, total_width)] = \
            node_features[i, : min(embed_dim, total_width)]
        neighbour_mask[i, :k] = True

    return WindowFrame(
        features=torch.from_numpy(features),
        labels=torch.from_numpy(merged["label"].to_numpy(dtype=np.int64)),
        node_features=torch.from_numpy(node_features),
        neighbour_features=torch.from_numpy(neighbour_features),
        neighbour_mask=torch.from_numpy(neighbour_mask),
        window_index=torch.from_numpy(merged["window_index"].to_numpy(dtype=np.int64)),
        user=merged["user"].astype(str).tolist(),
        partition=partition,
    )


def partition_frames(processed_dir: str | Path, config_path: str | Path,
                     max_neighbours: int = 32) -> Dict[str, WindowFrame]:
    """Materialise all three partitions."""
    return {name: build_window_frame(processed_dir, config_path, name, max_neighbours)
            for name in PARTITION_ORDER}
