"""Labelling of malicious activity windows from the CERT r6.2 ground truth.

The paper states (Section 6.1) that the corpus contains "5 malicious insider
scenarios documented in CERT r6.2" and that the 60 malicious instances are
"labeled time-windows derived from the 5 malicious insider scenarios", with 42
in training, 9 in validation and 9 in test.

The ground truth itself ships with the corpus under ``answers/`` as a
spreadsheet naming each malicious user and the date range over which that user
behaves maliciously.  This module reads it and maps those date ranges onto
24-hour windows.

Nothing here is invented: if the answers directory is absent the loader raises
rather than guessing labels.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Sequence

import pandas as pd

#: The five malicious insider identities in CERT r6.2 (paper Section 6.1,
#: Table 14).  These are the user identifiers as they appear in the corpus.
PAPER_MALICIOUS_IDENTITIES: Sequence[str] = ("CERT-M01", "CERT-M02", "CERT-M03",
                                              "CERT-M04", "CERT-M05")

#: Malicious-window counts per partition reported in Table 5.
PAPER_MALICIOUS_WINDOWS = {"train": 42, "validation": 9, "test": 9}


def load_answers(cert_root: str | Path) -> pd.DataFrame:
    """Read the insider-threat ground truth shipped with the corpus.

    Returns a frame with columns ``user, start_date, end_date`` (one row per
    malicious scenario).
    """
    from ..data.cert_loader import CertPaths

    paths = CertPaths.discover(cert_root)
    if paths.answers_dir is None:
        raise FileNotFoundError(
            "The CERT r6.2 'answers' directory was not found. The insider threat "
            "ground truth is required to build the labels and must not be "
            "synthesised.")
    files = sorted(paths.answers_dir.rglob("*.xlsx"))
    if not files:
        raise FileNotFoundError(f"No ground-truth workbook under {paths.answers_dir}")
    frames = []
    for f in files:
        try:
            sheets = pd.read_excel(f, sheet_name=None, header=None)
        except Exception:
            continue
        for _, sheet in sheets.items():
            df = pd.DataFrame(sheet)
            if df.empty:
                continue
            df.columns = [str(c).strip().lower() for c in df.columns]
            cols = set(df.columns)
            if {"user", "start_date"} <= cols and {"end_date"} <= cols:
                frames.append(df[["user", "start_date", "end_date"]])
    if not frames:
        raise FileNotFoundError(
            f"No sheet with user/start_date/end_date was found under {paths.answers_dir}.")
    out = pd.concat(frames, ignore_index=True)
    out["user"] = out["user"].astype(str).str.strip()
    out["start_date"] = pd.to_datetime(out["start_date"]).dt.normalize()
    out["end_date"] = pd.to_datetime(out["end_date"]).dt.normalize()
    return out.drop_duplicates(subset=["user", "start_date", "end_date"]).reset_index(drop=True)


def label_windows(events: pd.DataFrame,
                  answers: pd.DataFrame,
                  window_hours: int = 24,
                  time_col: str = "timestamp") -> pd.DataFrame:
    """Attach a malicious label to every (user, window) pair.

    A window is malicious for a user when the window overlaps any date range
    flagged for that user in the ground truth.

    Returns
    -------
    pandas.DataFrame
        Columns ``user, window_index, label``.
    """
    origin = events[time_col].min()
    delta = pd.Timedelta(hours=window_hours)
    ev = events.copy()
    off = (ev[time_col] - origin).dt.total_seconds()
    ev["window_index"] = (off // (window_hours * 3600.0)).astype("int64")
    ev["window_start"] = origin + pd.to_timedelta(ev["window_index"] * window_hours, unit="h")

    keys = ev[["user", "window_index", "window_start"]].drop_duplicates()
    keys["label"] = 0

    for _, row in answers.iterrows():
        user = row["user"]
        mask_user = keys["user"] == user
        if not mask_user.any():
            continue
        overlap = ((keys["window_start"] <= row["end_date"] + pd.Timedelta(days=1))
                   & (keys["window_start"] + delta > row["start_date"]))
        keys.loc[mask_user & overlap, "label"] = 1
    return keys.reset_index(drop=True)


def summarise(labels: pd.DataFrame) -> Dict[str, int]:
    """Counts of malicious windows and identities."""
    malicious = labels[labels["label"] == 1]
    return {
        "n_windows": int(len(labels)),
        "n_malicious_windows": int(len(malicious)),
        "n_malicious_identities": int(malicious["user"].nunique()),
    }
