"""Dynamic interaction graph construction (paper Section 3.2 and Algorithm 1).

For every window the organisation is represented as a graph

    G_t = (V_t, E_t)

where ``V_t`` holds user nodes and resource nodes and ``E_t`` holds an edge
``(u, r)`` whenever user ``u`` interacted with resource ``r`` during window
``t``.  The node feature matrix ``X_t`` stacks the fused behavioural
embeddings of Section 4.1 (Eq. 7).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


@dataclass
class WindowGraph:
    """A single window's dynamic interaction graph."""

    window_index: int
    users: List[str]
    resources: List[str]
    edges: np.ndarray            # (E, 2) int array of (user_idx, resource_idx)
    adjacency: np.ndarray       # (n_users, n_resources) binary adjacency
    user_features: np.ndarray   # (n_users, d) fused embeddings
    resource_features: np.ndarray  # (n_resources, d_res)

    @property
    def n_users(self) -> int:
        return len(self.users)

    @property
    def n_resources(self) -> int:
        return len(self.resources)


def build_window_graph(window_events: pd.DataFrame,
                       user_features: Optional[pd.DataFrame] = None,
                       feature_cols: Optional[Sequence[str]] = None,
                       resource_feature_dim: int = 32) -> WindowGraph:
    """Build the interaction graph for one window.

    Parameters
    ----------
    window_events:
        Events belonging to a single window, with ``user`` and ``resource``
        columns.
    user_features:
        Optional frame indexed by user holding the fused behavioural embedding
        (Eq. 16).  Users without a feature row get a zero vector.
    resource_feature_dim:
        Width of the resource-node feature vector.  Resource nodes are
        represented by their activity-frequency profile within the window.
    """
    users = sorted(window_events["user"].astype(str).unique().tolist())
    resources = sorted({str(r) for r in window_events["resource"].tolist() if str(r)})
    u_idx = {u: i for i, u in enumerate(users)}
    r_idx = {r: i for i, r in enumerate(resources)}

    ui = window_events["user"].astype(str).map(u_idx).to_numpy()
    ri = window_events["resource"].astype(str).map(r_idx).to_numpy()
    keep = np.array([str(r) in r_idx for r in window_events["resource"].tolist()], dtype=bool)
    ui, ri = ui[keep], ri[keep]

    adjacency = np.zeros((len(users), len(resources)), dtype=np.float32)
    if len(ui):
        adjacency[ui, ri] = 1.0

    if user_features is not None:
        cols = list(feature_cols) if feature_cols else [c for c in user_features.columns
                                                       if c != "user"]
        mat = np.zeros((len(users), len(cols)), dtype=np.float32)
        idx = user_features.set_index("user")
        for u, i in u_idx.items():
            if u in idx.index:
                row = idx.loc[u]
                vals = np.asarray([row[c] for c in cols], dtype=np.float32)
                if vals.ndim == 1:
                    mat[i] = np.nan_to_num(vals)
        user_feats = mat
    else:
        user_feats = np.zeros((len(users), 0), dtype=np.float32)

    res_feats = np.zeros((len(resources), resource_feature_dim), dtype=np.float32)
    if len(resources) and resource_feature_dim:
        counts = pd.Series(ri).value_counts()
        for r, c in counts.items():
            res_feats[r, 0] = float(c)

    edges = np.stack([ui, ri], axis=1) if len(ui) else np.zeros((0, 2), dtype=int)
    return WindowGraph(
        window_index=int(window_events["window_index"].iloc[0]) if "window_index" in window_events else 0,
        users=users,
        resources=resources,
        edges=edges.astype(np.int64),
        adjacency=adjacency,
        user_features=user_feats,
        resource_features=res_feats,
    )


def interaction_counts(events: pd.DataFrame) -> pd.DataFrame:
    """Count user-resource interactions across the whole corpus."""
    return (events.groupby(["user", "resource"], sort=False)
            .size().reset_index(name="n_interactions"))
