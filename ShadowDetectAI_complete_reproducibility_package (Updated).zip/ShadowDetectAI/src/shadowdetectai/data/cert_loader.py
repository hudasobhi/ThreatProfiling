"""Loader for the CMU CERT r6.2 insider threat corpus.

The corpus is distributed as one compressed archive per simulation day
(``cert.r6.2.<YYYY-MM-DD>.tar.bz2``), each containing five activity logs:

    logs/logon.csv   date, time, user, activity, resource
    logs/file.csv    date, time, user, activity, resource
    logs/email.csv   date, time, user, activity, resource, from, to, size
    logs/device.csv  date, time, user, activity, resource
    logs/http.csv    date, time, user, activity, resource

Official source (quoted from the paper's Data Availability statement):
    https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247

The loader deliberately exposes ONLY the five activity logs.  There is no
keystroke, pointer-coordinate or click-pressure field in the release, and
``tests/test_no_hardware_fields.py`` asserts that this module never reads one.
See paper Section 4.1 and Table 3.
"""
from __future__ import annotations

import bz2
import os
import tarfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Optional, Sequence

import numpy as np
import pandas as pd

#: The five CERT r6.2 activity logs, mapped to the three behavioural channels.
ACTIVITY_LOGS: Sequence[str] = ("logon", "file", "email", "device", "http")

#: Which log feeds which proxy channel (Table 3 of the paper).
CHANNEL_SOURCE: Dict[str, str] = {
    "keystroke_timing_proxy": "logon",
    "mouse_interaction_proxy": "device",
    "application_sequencing": "file+email+http",
}

#: Forbidden column fragments.  Their presence would break the proxy claim.
FORBIDDEN_FIELDS: Sequence[str] = ("press", "release", "keycode", "x_coord",
                                    "y_coord", "pointer", "pressure", "click_x",
                                    "click_y")

#: Columns of the unified event table produced by :func:`load_events`.
EVENT_COLUMNS: Sequence[str] = ("timestamp", "user", "activity", "resource", "channel")


@dataclass(frozen=True)
class CertPaths:
    """Locations of the extracted corpus on disk."""

    root: Path
    logs_dir: Path
    answers_dir: Optional[Path] = None

    @classmethod
    def discover(cls, root: str | os.PathLike) -> "CertPaths":
        """Locate ``logs/`` and ``answers/`` beneath ``root``."""
        root = Path(root)
        logs = root / "logs"
        if not logs.exists():
            # Some extractions nest the corpus one level deeper.
            candidates = sorted(p for p in root.glob("**/logs") if p.is_dir())
            if not candidates:
                raise FileNotFoundError(
                    f"No 'logs' directory found under {root}. Extract the CERT r6.2 "
                    "archives with data/extract.py first.")
            logs = candidates[0]
        answers = None
        for cand in sorted(root.glob("**/answers")):
            if cand.is_dir():
                answers = cand
                break
        return cls(root=root, logs_dir=logs, answers_dir=answers)


def _iter_daily_csvs(logs_dir: Path, name: str) -> Iterator[Path]:
    """Yield every ``<name>.csv`` under ``logs_dir`` in deterministic order."""
    yield from sorted(logs_dir.rglob(f"{name}.csv"), key=lambda p: str(p).lower())


def _to_timestamp(date: pd.Series, time: pd.Series) -> pd.Series:
    """Combine the CERT ``date`` and ``time`` columns into UTC timestamps."""
    combined = pd.to_datetime(date.astype(str).str.strip() + " " +
                              time.astype(str).str.strip(), errors="coerce")
    # CERT times are local to the simulation; treat them as naive local time.
    return combined


def _read_activity_csv(path: Path) -> Optional[pd.DataFrame]:
    """Read one activity CSV into the unified event frame."""
    try:
        df = pd.read_csv(path, low_memory=False)
    except Exception:
        return None
    if df.empty:
        return None
    df.columns = [str(c).strip().lower() for c in df.columns]
    required = {"date", "time", "user", "activity"}
    if not required.issubset(df.columns):
        return None
    df["timestamp"] = _to_timestamp(df["date"], df["time"])
    df["user"] = df["user"].astype(str).str.strip()
    df["activity"] = df["activity"].astype(str).str.strip()
    df["resource"] = (df["resource"].astype(str).str.strip()
                      if "resource" in df.columns else "")
    df = df.dropna(subset=["timestamp"])
    return df[["timestamp", "user", "activity", "resource"]].copy()


def load_events(cert_root: str | os.PathLike,
                activity_logs: Sequence[str] = ACTIVITY_LOGS,
                channels: Optional[Dict[str, str]] = None) -> pd.DataFrame:
    """Load the CERT r6.2 activity logs into a single event table.

    Parameters
    ----------
    cert_root:
        Directory holding the extracted corpus (see :class:`CertPaths`).
    activity_logs:
        Which of the five logs to read.  Defaults to all of them.
    channels:
        Mapping from activity-log name to behavioural channel label.  Defaults
        to :data:`CHANNEL_SOURCE`.  The channel label is what Table 3 calls
        the "channel name used throughout the manuscript".

    Returns
    -------
    pandas.DataFrame
        Columns ``timestamp, user, activity, resource, channel``.  Rows are
        sorted by ``(timestamp, user)``.
    """
    paths = CertPaths.discover(cert_root)
    channel_map = dict(channels or CHANNEL_SOURCE)
    frames: List[pd.DataFrame] = []
    for log_name in activity_logs:
        for csv_path in _iter_daily_csvs(paths.logs_dir, log_name):
            df = _read_activity_csv(csv_path)
            if df is None:
                continue
            df["channel"] = channel_map.get(log_name, log_name)
            df["source_log"] = log_name
            frames.append(df)
    if not frames:
        raise FileNotFoundError(f"No CERT activity logs found under {paths.logs_dir}")
    out = pd.concat(frames, ignore_index=True)
    out = out.sort_values(["timestamp", "user"], kind="mergesort").reset_index(drop=True)
    return out


def assert_no_hardware_fields(columns: Iterable[str]) -> None:
    """Raise if any column name looks like raw biometric hardware telemetry.

    This is the runtime half of ``tests/test_no_hardware_fields.py`` and the
    machine-checkable form of the paper's claim that no channel is derived
    from hardware-captured sensor data (Section 4.1, Table 3).
    """
    bad = [c for c in columns
           if any(f in str(c).lower() for f in FORBIDDEN_FIELDS)]
    if bad:
        raise AssertionError(
            "Forbidden hardware/biometric fields present in the event table: "
            f"{bad}. The CERT r6.2 release contains no such fields and the "
            "proxy channels must not depend on them.")


def extract_archive(archive: str | os.PathLike, dest: str | os.PathLike) -> Path:
    """Extract one ``.tar.bz2`` daily archive into ``dest``."""
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:bz2") as tar:
        tar.extractall(dest)
    return dest


def list_daily_archives(cert_root: str | os.PathLike) -> List[Path]:
    """Return every daily ``cert.r6.2.<date>.tar.bz2`` archive under ``root``."""
    root = Path(cert_root)
    return sorted(root.rglob("cert.r6.2.*.tar.bz2"), key=lambda p: p.name)
