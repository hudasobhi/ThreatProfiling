"""Fixed 24-hour windowing of the event stream (paper Section 6.1).

The paper states: "yielding 42 malicious windows in training, 9 in validation,
and 9 in test after applying a non-overlapping sliding window of Delta = 24
hours".  Windows are therefore non-overlapping and aligned to the start of the
simulation.
"""
from __future__ import annotations

from typing import Optional

import pandas as np
import pandas as pd

WINDOW_HOURS = 24


def assign_windows(events: pd.DataFrame,
                   window_hours: int = WINDOW_HOURS,
                   origin: Optional[pd.Timestamp] = None,
                   time_col: str = "timestamp") -> pd.DataFrame:
    """Assign a non-overlapping window index to every event.

    Parameters
    ----------
    origin:
        Anchor of the window grid.  Defaults to the earliest timestamp in the
        corpus, which makes the grid identical on every run.

    Returns
    -------
    pandas.DataFrame
        The input with added ``window_index`` and ``window_start`` columns.
    """
    df = events.copy()
    if origin is None:
        origin = df[time_col].min()
    origin = pd.Timestamp(origin)
    delta = pd.Timedelta(hours=window_hours)
    offset = (df[time_col] - origin).dt.total_seconds()
    df["window_index"] = np.floor(offset / (window_hours * 3600.0)).astype("int64")
    df["window_start"] = origin + pd.to_timedelta(df["window_index"] * window_hours, unit="h")
    return df


def window_grid(window_starts: pd.Series, window_hours: int = WINDOW_HOURS) -> pd.DataFrame:
    """Materialise a dense grid of window start times."""
    starts = pd.Series(sorted(pd.unique(window_starts))).sort_values()
    return pd.DataFrame({
        "window_index": np.arange(len(starts), dtype="int64"),
        "window_start": starts.values,
    })


def summarise_window(df: pd.DataFrame, window_col: str = "window_index") -> pd.DataFrame:
    """Per-window counts of records, users and distinct resources."""
    g = df.groupby(window_col, sort=True)
    out = pd.DataFrame({
        "n_records": g.size(),
        "n_users": g["user"].nunique(),
        "n_resources": g["resource"].nunique(),
    }).reset_index()
    return out
