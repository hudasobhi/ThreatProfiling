"""Data pipeline: CERT r6.2 loading, sessionisation, windowing, labelling,
partitioning, leave-one-insider-out folds and dynamic graph construction."""
