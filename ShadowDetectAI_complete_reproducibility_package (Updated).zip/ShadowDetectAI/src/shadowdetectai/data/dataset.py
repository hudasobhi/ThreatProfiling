"""PyTorch Dataset and DataLoader classes for the windowed CERT r6.2 data.

A *sample* is one user in one 24-hour window.  Each sample carries the three
channel feature blocks, the neighbourhood tensors required by the TGN, and the
binary label.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset

from ..utils.seeds import seed_worker


@dataclass
class WindowFrame:
    """The materialised tensors for one partition."""

    features: torch.Tensor            # (n, d_channel_total)
    labels: torch.Tensor              # (n,)
    node_features: torch.Tensor       # (n, d_fused)
    neighbour_features: torch.Tensor  # (n, N, d_fused)
    neighbour_mask: torch.Tensor      # (n, N) bool
    window_index: torch.Tensor        # (n,)
    user: List[str]
    partition: str


class WindowDataset(Dataset):
    """Dataset over the (user, window) rows of one partition."""

    def __init__(self, frame: WindowFrame, channel_slices: Dict[str, slice]):
        self.frame = frame
        self.channel_slices = channel_slices

    def __len__(self) -> int:
        return int(self.frame.labels.shape[0])

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        slices = self.channel_slices
        channels = {name: self.frame.features[idx, sl] for name, sl in slices.items()}
        return {
            "features": self.frame.features[idx],
            "node_features": self.frame.node_features[idx],
            "neighbour_features": self.frame.neighbour_features[idx],
            "neighbour_mask": self.frame.neighbour_mask[idx],
            "label": self.frame.labels[idx],
            "window_index": self.frame.window_index[idx],
            "channel_vectors": channels,
        }


def build_dataloader(frame: WindowFrame, channel_slices: Dict[str, slice],
                     batch_size: int = 256, shuffle: bool = True,
                     num_workers: int = 0) -> DataLoader:
    """Build the DataLoader for one partition (batch size 256 users per window)."""
    ds = WindowDataset(frame, channel_slices)
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle,
                      num_workers=num_workers, worker_init_fn=seed_worker,
                      drop_last=False)


def collate_channels(batch: Dict[str, Any]) -> Dict[str, Any]:
    """Stack the per-sample channel vectors into a ``(B, d_channel)`` tensor each."""
    out = dict(batch)
    names = list(batch["channel_vectors"].keys())
    out["channel_vectors"] = {n: torch.stack([b["channel_vectors"][n] for b in batch])
                              for n in names}
    return out
