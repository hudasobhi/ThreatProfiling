"""Session segmentation for the CERT r6.2 activity logs.

A *session* is a maximal run of records for one user within one activity
channel whose inter-record gaps do not exceed ``gap_seconds``.

``gap_seconds`` is **[NOT STATED IN PAPER]**.  The paper states only that the
keystroke timing proxy is derived from "the inter-record interval between the
timestamps of two consecutive log entries assigned to the same session"
(Section 4.1.1) and that windows are 24 h (Delta = 24 h, Section 6.1).  We
therefore use a 30-minute inactivity gap, which is the conventional
sessionisation threshold for enterprise audit logs, and expose it as a config
value (``data.session_gap_seconds``) so it can be swept.
"""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd

DEFAULT_GAP_SECONDS = 30 * 60


def sessionize(events: pd.DataFrame,
               gap_seconds: int = DEFAULT_GAP_SECONDS,
               user_col: str = "user",
               channel_col: str = "channel",
               time_col: str = "timestamp") -> pd.DataFrame:
    """Assign a ``session_id`` to every event.

    Parameters
    ----------
    events:
        Event table with at least the user, channel and timestamp columns.
    gap_seconds:
        Maximum gap (seconds) between consecutive records for a session to
        continue.  **[NOT STATED IN PAPER]** - default 1800 s.

    Returns
    -------
    pandas.DataFrame
        The input with an added ``session_id`` column (a globally unique
        string ``"<channel>|<user>|<index>"``) and a ``session_start`` flag.
    """
    df = events.sort_values([channel_col, user_col, time_col], kind="mergesort").copy()
    df["_gap"] = df.groupby([channel_col, user_col], sort=False)[time_col].diff()
    df["_new_session"] = df["_gap"].isna() | (df["_gap"] > pd.Timedelta(seconds=gap_seconds))
    grp = df.groupby([channel_col, user_col], sort=False)["_new_session"].cumsum()
    df["session_id"] = (df[channel_col].astype(str) + "|" + df[user_col].astype(str)
                        + "|" + grp.astype(str))
    df["session_start"] = df["_new_session"].fillna(True).astype(bool)
    df = df.drop(columns=["_gap", "_new_session"])
    return df.sort_values(["timestamp", "user"], kind="mergesort").reset_index(drop=True)


def session_statistics(sessions: pd.DataFrame,
                       time_col: str = "timestamp") -> pd.DataFrame:
    """Per-session start/end times and record counts."""
    grp = sessions.groupby("session_id", sort=False)
    out = pd.DataFrame({
        "session_start": grp[time_col].min(),
        "session_end": grp[time_col].max(),
        "n_records": grp.size(),
    }).reset_index()
    out["duration_seconds"] = (out["session_end"] - out["session_start"]).dt.total_seconds()
    return out
