"""Leave-one-insider-out (LOIO) cross-validation folds (paper Table 14).

The corpus contains five malicious insider identities.  Each fold holds out one
identity for testing and trains on the other four, giving the five-fold
AUC-ROC of 0.981 +/- 0.008 reported in Table 14.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Sequence

import pandas as pd

from .labeling import PAPER_MALICIOUS_IDENTITIES


def build_loio_folds(labels: pd.DataFrame,
                     identities: Sequence[str] = PAPER_MALICIOUS_IDENTITIES) -> List[Dict[str, object]]:
    """Build one fold per malicious identity.

    Each fold records the held-out identity, the training identities and the
    malicious windows belonging to the held-out identity.
    """
    folds: List[Dict[str, object]] = []
    malicious = labels[labels["label"] == 1]
    for i, held_out in enumerate(identities, start=1):
        train_ids = [u for u in identities if u != held_out]
        sub = malicious[malicious["user"] == held_out]
        folds.append({
            "fold": i,
            "held_out_identity": held_out,
            "train_identities": train_ids,
            "held_out_windows": sorted(int(w) for w in sub["window_index"].unique()),
        })
    return folds


def write_loio_folds(folds: Sequence[Dict[str, object]], path: str | Path) -> None:
    """Persist the folds to ``data/splits/loio_folds.json``."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(list(folds), indent=2) + "\n", encoding="utf-8")
