"""Attribution fidelity of a trained model (paper Section 4.3, Eq. 30).

The paper reports an **attribution fidelity** for the proposed model and for
the two baselines that produce an explanation (Table 8).  It is defined as

.. math:: 1 - \\frac{\\| \\phi_0 + \\sum_i \\phi_i - z \\|}{\\| z \\|}

where ``z`` is the model's logit for the flagged instance, ``phi_0`` is the
model's output on the background distribution and ``phi_i`` are the
KernelSHAP feature contributions.

This module is deliberately free of any deep-learning dependency: it takes a
plain scoring callable, so it can be unit-tested with NumPy alone.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Optional, Sequence

import numpy as np

from .fidelity import fidelity
from .kernel_shap import (
    KernelShapConfig, KernelShapExplainer, coalition_matrix)

#: A scoring callable maps a feature matrix ``(n, d)`` to ``(n,)`` outputs.
ScoreFn = Callable[[np.ndarray], np.ndarray]


def attribution_fidelity(score_fn: ScoreFn,
                         instances: np.ndarray,
                         background: np.ndarray,
                         n_background: int = 100,
                         n_coalitions: int = 512,
                         seed: Optional[int] = 0,
                         max_users: Optional[int] = None) -> Dict[str, object]:
    """Mean Eq. (30) fidelity over a set of flagged instances.

    Parameters
    ----------
    score_fn:
        The model's scoring function, mapping a feature matrix to a vector
        of outputs (the logits).
    instances:
        The flagged instances, shape ``(n, d)``.
    background:
        The benign background distribution, shape ``(n_bg, d)``.
    n_background, n_coalitions:
        The Table 6 settings: 100 background windows and 512 coalitions.
    max_users:
        Cap on the number of flagged instances, to bound the cost.

    Returns
    -------
    dict
        ``fidelity_mean``, ``fidelity_std``, ``n_users`` and the per-user
        values under ``per_user``.
    """
    instances = np.asarray(instances, dtype=np.float64)
    if instances.ndim == 1:
        instances = instances.reshape(1, -1)
    if max_users is not None:
        instances = instances[:max_users]

    d = instances.shape[1]
    config = KernelShapConfig(n_background=n_background,
                              n_coalitions=n_coalitions,
                              n_features=d, seed=seed)
    explainer = KernelShapExplainer(score_fn, config)
    explainer.set_background(np.asarray(background, dtype=np.float64))
    explainer.set_coalitions(coalition_matrix(d, n_coalitions, seed=seed))

    per_user: List[float] = []
    for x in instances:
        phi, baseline = explainer.explain(x, return_baseline=True)
        logit = float(np.asarray(score_fn(x.reshape(1, -1))).reshape(-1)[0])
        per_user.append(fidelity(float(phi.sum()), logit, baseline))

    arr = np.asarray(per_user, dtype=np.float64)
    return {
        "fidelity_mean": float(arr.mean()) if arr.size else float("nan"),
        "fidelity_std": float(arr.std(ddof=1)) if arr.size > 1 else 0.0,
        "n_users": int(arr.size),
        "per_user": per_user,
    }


def top_contributor_panel(phi: np.ndarray,
                          feature_names: Sequence[str],
                          top_k: int = 5) -> List[Dict[str, object]]:
    """Eq. (28): the ranked panel the analyst sees.

    Each entry carries the feature name, its Shapley contribution and the
    direction of the contribution, which is what the triage interface shows
    in the attribution condition.
    """
    phi = np.asarray(phi, dtype=np.float64).reshape(-1)
    k = min(int(top_k), phi.size)
    order = np.argsort(-np.abs(phi))[:k]
    panel: List[Dict[str, object]] = []
    for rank, idx in enumerate(order, start=1):
        value = float(phi[idx])
        panel.append({
            "rank": rank,
            "feature": (feature_names[idx] if idx < len(feature_names)
                        else f"f{idx}"),
            "shapley_value": value,
            "abs_shapley": abs(value),
            "direction": "increases risk" if value > 0 else "decreases risk",
        })
    return panel
