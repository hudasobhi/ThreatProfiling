"""Attribution assembly and the top-k ranking (paper Section 4.3, Eq. 28).

    Eq. (28)   phi_top = argsort(-|phi|)[1 .. K]

The ranked list is what the analyst panel shows.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np


@dataclass
class AttributionResult:
    """The attribution vector and its ranked contributors."""

    values: np.ndarray            # (d,) per-feature contributions
    top_indices: np.ndarray       # (K,) indices of the top contributors
    baseline: float = 0.0         # expected model output over the background
    logit: float = 0.0            # the decomposed logit

    def as_dict(self) -> Dict[str, object]:
        return {
            "values": self.values.tolist(),
            "top_indices": self.top_indices.tolist(),
            "baseline": float(self.baseline),
            "logit": float(self.logit),
        }


def rank_contributions(values: np.ndarray, top_k: int = 5) -> np.ndarray:
    """Eq. (28): the indices of the ``top_k`` largest-magnitude contributions."""
    values = np.asarray(values).reshape(-1)
    k = min(int(top_k), values.shape[0])
    order = np.argsort(-np.abs(values))[:k]
    return order


def build_attribution(values: np.ndarray, logit: float, baseline: float = 0.0,
                      top_k: int = 5) -> AttributionResult:
    """Assemble an :class:`AttributionResult` from raw Shapley values."""
    values = np.asarray(values, dtype=np.float64).reshape(-1)
    return AttributionResult(
        values=values,
        top_indices=rank_contributions(values, top_k),
        baseline=float(baseline),
        logit=float(logit),
    )


def attribution_to_frame(result: AttributionResult, feature_names: Sequence[str],
                          top_k: int = 5) -> "object":
    """Render an attribution as a tidy frame (one row per ranked feature)."""
    import pandas as pd

    rows = []
    for rank, idx in enumerate(result.top_indices[:top_k], start=1):
        rows.append({
            "rank": rank,
            "feature": feature_names[idx] if idx < len(feature_names) else f"f{idx}",
            "shapley_value": float(result.values[idx]),
            "abs_shapley": float(abs(result.values[idx])),
        })
    return pd.DataFrame(rows)
