"""Shapley attribution layer (paper Section 4.3, Eqs. 25-30)."""
