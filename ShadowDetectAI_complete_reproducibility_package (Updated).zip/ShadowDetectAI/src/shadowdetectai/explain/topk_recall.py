"""Top-k contribution recall (paper Section 6.2).

    top-k recall = |{ground-truth drivers in the top k} | / |{ground-truth drivers}|

The ground-truth behavioural drivers are manually annotated per flagged user.
When no annotation is available for a user the user is excluded from the
denominator rather than counted as a miss.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np


def topk_recall(ranked_indices: Sequence[int],
                ground_truth: Sequence[int],
                k: int = 3) -> float:
    """Recall of the ground-truth drivers inside the top ``k`` contributions."""
    gt = set(int(i) for i in ground_truth)
    if not gt:
        return float("nan")
    top = set(int(i) for i in list(ranked_indices)[:k])
    return len(gt & top) / float(len(gt))


def mean_topk_recall(ranked_per_user: Sequence[Sequence[int]],
                     ground_truth_per_user: Sequence[Sequence[int]],
                     k: int = 3) -> float:
    """Mean top-k recall across the flagged users that carry an annotation."""
    vals = []
    for ranked, gt in zip(ranked_per_user, ground_truth_per_user):
        if not gt:
            continue
        vals.append(topk_recall(ranked, gt, k))
    if not vals:
        return float("nan")
    return float(np.mean(vals))
