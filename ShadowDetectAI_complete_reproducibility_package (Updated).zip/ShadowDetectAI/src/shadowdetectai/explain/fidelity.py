"""Attribution fidelity (paper Section 4.3, Eq. 30).

    Eq. (30)   fidelity = 1 - | sum_j phi_j - z_{u,t} | / | z_{u,t} |

A fidelity approaching one confirms that the reported attribution closely
reconstructs the score the analyst is reviewing.

Three approximation sources produce the residual gap (Section 4.3):
  1. KernelSHAP coalition sampling (512 sampled coalitions per flagged user),
  2. the finite background reference distribution (100 benign windows),
  3. the aggregated neighbourhood treated as a single coalition player.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Optional

import numpy as np


def fidelity(attribution_sum: float, logit: float, baseline: float = 0.0) -> float:
    """Eq. (30): the fidelity of one attribution.

    .. math:: 1 - \\frac{\\| \\phi_0 + \\sum_i \\phi_i - z \\|}{\\| z \\|}

    The ``baseline`` is the model's output on the background distribution,
    i.e. the ``phi_0`` term of the KernelSHAP decomposition.  It defaults to
    zero, which is the right value when the attribution is already
    expressed relative to the baseline.
    """
    denom = abs(logit)
    if denom < 1e-12:
        return 1.0
    total = float(baseline) + float(attribution_sum)
    return float(1.0 - abs(total - logit) / denom)


def mean_fidelity(attribution_sums: Iterable[float], logits: Iterable[float]) -> float:
    """Mean fidelity over a set of flagged users."""
    a = np.asarray(list(attribution_sums), dtype=np.float64)
    z = np.asarray(list(logits), dtype=np.float64)
    if a.size == 0:
        return 0.0
    denom = np.where(np.abs(z) < 1e-12, 1.0, np.abs(z))
    return float(np.mean(1.0 - np.abs(a - z) / denom))


def attribution_report(attributions: List[np.ndarray], logits: List[float]) -> Dict[str, float]:
    """Summary fidelity statistics for a partition."""
    sums = [float(np.sum(a)) for a in attributions]
    return {
        "fidelity": mean_fidelity(sums, logits),
        "mean_abs_residual": float(np.mean([abs(s - z) for s, z in zip(sums, logits)]))
        if attributions else 0.0,
        "n_flagged": float(len(attributions)),
    }
