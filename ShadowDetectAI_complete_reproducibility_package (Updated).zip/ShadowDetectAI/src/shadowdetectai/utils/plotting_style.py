"""Matplotlib style shared by every figure script.

The paper's figures use Times New Roman, a 600 dpi raster fallback and the
palette recorded in :data:`PALETTE`.  Figure 9 of the paper uses blue
#1A73E8 (ShadowDetectAI), red #E53935 (LAN), cyan #00ACC1 (EXAI) and brown
#6D4C41 (Gaspar et al.); the same colours are reused in Figures 8, 12 and 13.
"""
from __future__ import annotations

from typing import Dict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

PALETTE: Dict[str, str] = {
    "blue": "#1A73E8",
    "red": "#E53935",
    "orange": "#F4A300",
    "cyan": "#00ACC1",
    "brown": "#6D4C41",
    "green": "#0F9D58",
    "grey": "#666666",
    "grid": "#E0E0E0",
}

FIG_DPI = 600


def apply_style() -> None:
    """Install the paper's matplotlib style."""
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "axes.titlesize": 10,
        "axes.labelsize": 10,
        "axes.edgecolor": "#000000",
        "axes.linewidth": 0.8,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 8,
        "legend.frameon": True,
        "legend.framealpha": 0.9,
        "grid.color": PALETTE["grid"],
        "grid.linewidth": 0.6,
        "grid.alpha": 0.9,
        "savefig.dpi": FIG_DPI,
        "savefig.bbox": "tight",
        "figure.dpi": 110,
    })


def save(fig, path: str, dpi: int = FIG_DPI) -> None:
    """Save a figure with the paper's DPI and a white (not transparent) background."""
    from pathlib import Path

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, facecolor="white", edgecolor="none")
    plt.close(fig)
