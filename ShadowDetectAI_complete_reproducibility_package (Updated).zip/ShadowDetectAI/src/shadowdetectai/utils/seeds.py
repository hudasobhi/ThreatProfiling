"""Deterministic seeding for Python, NumPy and PyTorch.

Implements the reproducibility requirement of the paper (Table 6): ten
independent runs with the fixed seed set
    {42, 123, 256, 512, 1024, 999, 777, 333, 111, 888}.
"""
from __future__ import annotations

import os
import random
from typing import List

import numpy as np

try:  # torch is optional for the pure-data utilities
    import torch
except ImportError:  # pragma: no cover
    torch = None  # type: ignore

#: The ten seeds used for every reported number in the paper (Table 6).
PAPER_SEEDS: List[int] = [42, 123, 256, 512, 1024, 999, 777, 333, 111, 888]


def set_seed(seed: int, deterministic: bool = True) -> None:
    """Seed every RNG the pipeline touches.

    Parameters
    ----------
    seed:
        The seed value.
    deterministic:
        When True (the default, and what the paper requires) cuDNN is put in
        deterministic mode and cuDNN benchmarking is disabled so that repeated
        runs with the same seed produce bit-identical results.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    if torch is None:
        return
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def seed_worker(worker_id: int) -> None:
    """DataLoader worker initialiser that keeps augmentation deterministic."""
    worker_seed = torch.initial_seed() % 2 ** 32 if torch is not None else 0
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def paper_seeds() -> List[int]:
    """Return the ten seeds reported in the paper."""
    return list(PAPER_SEEDS)
