"""YAML configuration loading with inheritance.

Every experiment reads its hyper-parameters from a YAML file; nothing is
hard-coded in the Python source.  A config may declare ``base: <path>`` to
inherit from another file, and the merge is shallow-with-dict-recursion.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

import yaml


def load_yaml(path: str | Path) -> Dict[str, Any]:
    """Load a single YAML file."""
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge ``override`` into ``base`` (``base`` is not mutated)."""
    out = dict(base)
    for key, value in (override or {}).items():
        if key in out and isinstance(out[key], dict) and isinstance(value, dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def load_config(path: str | Path) -> Dict[str, Any]:
    """Load a config, resolving a single level of ``base:`` inheritance."""
    p = Path(path)
    cfg = load_yaml(p)
    base_ref = cfg.pop("base", None)
    if base_ref:
        base_path = (p.parent / base_ref).resolve()
        base_cfg = load_config(base_path)
        cfg = deep_merge(base_cfg, cfg)
    return cfg


def get(cfg: Dict[str, Any], dotted: str, default: Any = None) -> Any:
    """Fetch a nested value with a dotted key, e.g. ``training.learning_rate``."""
    node: Any = cfg
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


def save_config(cfg: Dict[str, Any], path: str | Path) -> None:
    """Persist a resolved config next to its run outputs."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        yaml.safe_dump(cfg, fh, sort_keys=False, default_flow_style=False)
