"""Small IO helpers used across the pipeline (JSON/CSV/NPZ read-write)."""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence

import numpy as np


def ensure_dir(path: os.PathLike | str) -> Path:
    """Create ``path`` (and parents) if it does not exist and return it."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_json(path: os.PathLike | str, obj: Any, indent: int = 2) -> None:
    """Write ``obj`` as UTF-8 JSON."""
    ensure_dir(Path(path).parent)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=indent, ensure_ascii=False, sort_keys=False)
        fh.write("\n")


def read_json(path: os.PathLike | str) -> Any:
    """Read a UTF-8 JSON file."""
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def write_csv(path: os.PathLike | str, header: Sequence[str], rows: Iterable[Sequence[Any]]) -> None:
    """Write a CSV with a header row."""
    ensure_dir(Path(path).parent)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(list(header))
        for row in rows:
            writer.writerow(list(row))


def read_csv(path: os.PathLike | str) -> List[Dict[str, str]]:
    """Read a CSV into a list of dictionaries."""
    with open(path, "r", encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def write_csv_dicts(path: os.PathLike | str, rows: Sequence[Dict[str, Any]],
                    header: Sequence[str] | None = None) -> None:
    """Write a list of dictionaries as CSV."""
    if not rows:
        write_csv(path, header or [], [])
        return
    header = header or list(rows[0].keys())
    write_csv(path, header, [[r.get(k, "") for k in header] for r in rows])


def save_npz(path: os.PathLike | str, **arrays: np.ndarray) -> None:
    """Save named arrays to a compressed ``.npz`` archive."""
    ensure_dir(Path(path).parent)
    np.savez_compressed(path, **arrays)


def load_npz(path: os.PathLike | str) -> Dict[str, np.ndarray]:
    """Load a ``.npz`` archive into a plain dictionary."""
    with np.load(path, allow_pickle=False) as data:
        return {k: data[k] for k in data.files}


def sha256(path: os.PathLike | str, chunk_size: int = 1 << 20) -> str:
    """Return the SHA256 hex digest of a file."""
    import hashlib

    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()
