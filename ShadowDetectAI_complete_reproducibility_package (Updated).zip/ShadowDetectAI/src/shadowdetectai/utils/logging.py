"""CSV + console logging for every training run."""
from __future__ import annotations

import csv
import logging
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional, Sequence


def get_logger(name: str = "shadowdetectai", log_file: Optional[str] = None,
               level: int = logging.INFO) -> logging.Logger:
    """Return a logger that writes to stdout and optionally to a file."""
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(level)
    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s", "%Y-%m-%d %H:%M:%S")
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


class CSVLogger:
    """Append rows to a CSV file; used for per-epoch training curves."""

    def __init__(self, path: str, header: Sequence[str]):
        self.path = Path(path)
        self.header = list(header)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            with open(self.path, "w", encoding="utf-8", newline="") as fh:
                csv.writer(fh).writerow(self.header)

    def append(self, row: Dict[str, Any]) -> None:
        with open(self.path, "a", encoding="utf-8", newline="") as fh:
            csv.writer(fh).writerow([row.get(k, "") for k in self.header])

    def append_many(self, rows: Sequence[Dict[str, Any]]) -> None:
        for row in rows:
            self.append(row)


class Timer:
    """Context manager returning elapsed wall-clock seconds."""

    def __enter__(self) -> "Timer":
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.elapsed = time.perf_counter() - self.t0

    @property
    def seconds(self) -> float:
        return time.perf_counter() - self.t0
