"""Shared utilities: determinism, IO, logging and plotting style."""
