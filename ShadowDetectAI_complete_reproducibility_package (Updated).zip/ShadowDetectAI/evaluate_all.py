#!/usr/bin/env python3
"""Run every trained checkpoint and write every results table.

Produces the ``results/reproduced/`` directory that ``compare_results.py``
diffs against the paper's reported numbers in ``results/tables/``.

Two assembly steps happen here, because no single script can produce them
alone:

* **Table 8** is written by ``05_evaluate.py`` (the proposed model) and
  ``06_run_baselines.py`` (the six comparison methods).  This script merges
  their wide rows into one table in the paper's row order.
* **The Wilcoxon table** needs the *paired* per-seed AUC-ROC of the proposed
  model and of LAN, which only exist once both have been evaluated over the
  same ten seeds.  This script pairs them up.
"""
from __future__ import annotations

import argparse
import csv
import subprocess
import sys
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parent

STEPS = [
    ("05_evaluate.py", ["--config", "configs/default.yaml"]),
    ("06_run_baselines.py", []),
    ("07_grid_search_baselines.py", []),
    ("08_shap_sensitivity.py", []),
    ("09_channel_contribution.py", []),
    ("10_ablation.py", []),
    ("11_loio_cv.py", []),
    ("12_drift_and_calibration.py", []),
    ("13_scalability.py", []),
    ("14_triage_alert_pool.py", []),
    ("15_triage_analysis.py", []),
]

#: The row order the paper prints Table 8 in.
TABLE8_ORDER = [
    "Gaspar et al.",
    "EXAI",
    "VGGM",
    "Double Layer Detection",
    "GraphCH",
    "LAN",
    "ShadowDetectAI (proposed)",
]


def read_csv(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: List[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fields})


def assemble_table8(out_dir: Path) -> None:
    """Merge the proposed model's row with the six baseline rows."""
    proposed = read_csv(out_dir / "table08_detection_performance.csv")
    baselines = read_csv(out_dir / "table08_baselines.csv")
    if not proposed and not baselines:
        print("[warn] neither table08 file was produced; skipping the merge")
        return
    merged: Dict[str, Dict[str, object]] = {}
    for row in proposed + baselines:
        merged[str(row.get("method", ""))] = dict(row)
    ordered = [merged[m] for m in TABLE8_ORDER if m in merged]
    ordered += [row for name, row in merged.items() if name not in TABLE8_ORDER]
    write_csv(out_dir / "table08_detection_performance.csv", ordered)
    print(f"[ok] merged Table 8: {len(ordered)} methods")


def assemble_wilcoxon(out_dir: Path) -> None:
    """Pair the per-seed AUC-ROC of the proposed model and of LAN."""
    mine = {str(r["seed"]): r["auc_roc"]
            for r in read_csv(out_dir / "table08_shadowdetectai_per_seed.csv")}
    lan = {str(r["seed"]): r["auc_roc"]
           for r in read_csv(out_dir / "table08_baseline_per_seed.csv")
           if r.get("method") == "LAN"}
    shared = sorted(set(mine) & set(lan), key=lambda s: int(s))
    if not shared:
        print("[warn] no seeds in common between the proposed model and LAN; "
              "the Wilcoxon table was not written")
        return
    rows = [{"seed": seed,
             "shadowdetectai_auc": mine[seed],
             "lan_auc": lan[seed]} for seed in shared]
    write_csv(out_dir / "table08_wilcoxon_shadowdetectai_vs_lan.csv", rows)
    print(f"[ok] wrote the paired Wilcoxon table over {len(rows)} seeds")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--reproduced", default=str(ROOT / "results" / "reproduced"))
    ap.add_argument("--only", nargs="*", default=None,
                    help="run only the named steps, e.g. 05_evaluate.py")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    out_dir = Path(args.reproduced)
    out_dir.mkdir(parents=True, exist_ok=True)

    failures = []
    for script, extra in STEPS:
        if args.only and script not in args.only:
            continue
        cmd = [sys.executable, str(ROOT / "scripts" / script),
               "--out", str(out_dir)] + extra
        print(f"\n=== {script} ===")
        if args.dry_run:
            print("  " + " ".join(cmd))
            continue
        rc = subprocess.call(cmd)
        if rc != 0:
            failures.append((script, rc))
            print(f"[warn] {script} exited with {rc}")

    if not args.dry_run:
        assemble_table8(out_dir)
        assemble_wilcoxon(out_dir)

    if failures:
        print("\n[FAIL] steps that did not complete:")
        for script, rc in failures:
            print(f"  {script} -> {rc}")
        return 1
    print("\n[ok] all evaluation steps completed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
