#!/usr/bin/env python3
"""Build Figures 7-14 of the paper from the result tables.

Every figure in this script is drawn from a CSV, never from a hard-coded
array, so a figure cannot drift away from the table it illustrates.  The
tables under ``results/tables/`` hold the paper's reported values; the tables
under ``results/reproduced/`` hold what a run of this code produced.  With
``--source auto`` (the default) the reproduced table is used when it exists
and the paper's table otherwise, so the script always produces the full set
of figures.

Usage::

    python figures/make_figures.py                    # auto source, 600 dpi PNG
    python figures/make_figures.py --source tables    # force the paper's values
    python figures/make_figures.py --dpi 150 --format pdf
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from shadowdetectai.utils.plotting_style import PALETTE, apply_style, save  # noqa: E402

FIGURES = ROOT / "results" / "figures"


# --------------------------------------------------------------------------- #
# source resolution
# --------------------------------------------------------------------------- #
class Sources:
    """Locate a result table, preferring the reproduced copy over the target."""

    def __init__(self, mode: str) -> None:
        self.mode = mode
        self.reproduced = ROOT / "results" / "reproduced"
        self.tables = ROOT / "results" / "tables"
        self.used: Dict[str, str] = {}

    def find(self, name: str) -> Optional[Path]:
        """Return the path of the best available copy of ``name``."""
        if self.mode in ("auto", "reproduced"):
            candidate = self.reproduced / name
            if candidate.exists():
                self.used[name] = "reproduced"
                return candidate
        if self.mode in ("auto", "tables"):
            candidate = self.tables / name
            if candidate.exists():
                self.used[name] = "tables"
                return candidate
        return None

    def frame(self, name: str) -> Optional[pd.DataFrame]:
        path = self.find(name)
        if path is None:
            return None
        return pd.read_csv(path)


def _bar_labels(ax, bars, fmt: str = "{:.3f}") -> None:
    for bar in bars:
        height = bar.get_height()
        ax.annotate(fmt.format(height),
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3), textcoords="offset points",
                    ha="center", va="bottom", fontsize=7)


# --------------------------------------------------------------------------- #
# Figure 7 - ROC curves
# --------------------------------------------------------------------------- #
def figure07_roc(src: Sources) -> Optional[str]:
    """ROC curves of the seven methods, read from the evaluated scores."""
    frame = src.frame("figure07_roc_curves.csv")
    if frame is None:
        print("[skip] figure 7: no figure07_roc_curves.csv "
              "(produced by scripts/05_evaluate.py)")
        return None

    fig, ax = plt.subplots(figsize=(3.4, 3.4))
    order = ["ShadowDetectAI (proposed)", "LAN", "GraphCH",
             "Double Layer Detection", "VGGM", "EXAI", "Gaspar et al."]
    colours = [PALETTE["blue"], PALETTE["red"], PALETTE["orange"],
               PALETTE["cyan"], PALETTE["green"], PALETTE["brown"],
               PALETTE["grey"]]
    for method, colour in zip(order, colours):
        part = frame[frame["method"] == method]
        if part.empty:
            continue
        part = part.sort_values("fpr")
        ax.plot(part["fpr"], part["tpr"], color=colour, lw=1.4,
                label=f"{method} (AUC {part['auc_roc'].iloc[0]:.3f})")
    ax.plot([0, 1], [0, 1], color="#999999", ls="--", lw=0.8)
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("Fig. 7  Test-partition ROC curves")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.grid(True, alpha=0.5)
    ax.legend(loc="lower right", fontsize=6)
    out = FIGURES / "figure07_roc_curves.png"
    save(fig, str(out))
    return out.name


# --------------------------------------------------------------------------- #
# Figure 8 - per-channel attribution
# --------------------------------------------------------------------------- #
def figure08_channel_contribution(src: Sources) -> Optional[str]:
    frame = src.frame("table10_channel_attribution.csv")
    if frame is None:
        print("[skip] figure 8: no table10_channel_attribution.csv")
        return None
    frame = frame[frame["channel"] != "Total"].copy()

    fig, ax = plt.subplots(figsize=(3.6, 2.6))
    names = ["Application usage\nsequencing",
             "Keystroke timing\nproxy channel",
             "Mouse interaction\nproxy channel"]
    colours = [PALETTE["blue"], PALETTE["orange"], PALETTE["cyan"]]
    bars = ax.bar(range(len(frame)), frame["mean_abs_shapley_proportion"],
                  color=colours, width=0.58, edgecolor="black", lw=0.6)
    ax.set_xticks(range(len(frame)))
    ax.set_xticklabels(names, fontsize=7)
    _bar_labels(ax, bars)
    ax.set_ylabel("Mean absolute Shapley contribution")
    ax.set_title("Fig. 8  Per-channel attribution magnitude")
    ax.set_ylim(0, max(0.5, float(frame["mean_abs_shapley_proportion"].max()) * 1.25))
    ax.grid(True, axis="y", alpha=0.5)
    out = FIGURES / "figure08_channel_contribution.png"
    save(fig, str(out))
    return out.name


# --------------------------------------------------------------------------- #
# Figure 9 - detection accuracy under drift
# --------------------------------------------------------------------------- #
def figure09_drift(src: Sources) -> Optional[str]:
    frame = src.frame("figure09_drift_accuracy.csv")
    if frame is None:
        print("[skip] figure 9: no figure09_drift_accuracy.csv")
        return None

    fig, ax = plt.subplots(figsize=(4.2, 2.8))
    for method, colour in (("ShadowDetectAI (proposed)", PALETTE["blue"]),
                           ("LAN", PALETTE["red"]),
                           ("EXAI", PALETTE["cyan"]),
                           ("Gaspar et al.", PALETTE["brown"])):
        part = frame[frame["method"] == method].sort_values("window")
        if part.empty:
            continue
        ax.plot(part["window"], 100.0 * part["accuracy"], color=colour,
                lw=1.4, marker="o", ms=2.4, label=method)
    ax.set_xlabel("Test-partition window index")
    ax.set_ylabel("Detection accuracy (%)")
    ax.set_title("Fig. 9  Detection accuracy under behavioural drift")
    ax.grid(True, alpha=0.5)
    ax.legend(loc="lower left", fontsize=7)
    out = FIGURES / "figure09_drift_accuracy.png"
    save(fig, str(out))
    return out.name


# --------------------------------------------------------------------------- #
# Figure 10 - alert volume, fixed vs adaptive threshold
# --------------------------------------------------------------------------- #
def figure10_alert_volume(src: Sources) -> Optional[str]:
    frame = src.frame("figure10_alert_volume.csv")
    if frame is None:
        print("[skip] figure 10: no figure10_alert_volume.csv")
        return None

    fig, ax = plt.subplots(figsize=(4.2, 2.8))
    ax.plot(frame["window"], frame["fixed_threshold_alerts"], color=PALETTE["red"],
            lw=1.2, label="Fixed threshold")
    ax.plot(frame["window"], frame["adaptive_threshold_alerts"],
            color=PALETTE["blue"], lw=1.2, label="Adaptive threshold (Eq. 33)")
    ax.set_xlabel("Test-partition window index")
    ax.set_ylabel("Alerts raised")
    ax.set_title("Fig. 10  Alert volume under drift")
    ax.grid(True, alpha=0.5)
    ax.legend(loc="upper right", fontsize=7)
    out = FIGURES / "figure10_alert_volume.png"
    save(fig, str(out))
    return out.name


# --------------------------------------------------------------------------- #
# Figure 11 - scalability
# --------------------------------------------------------------------------- #
def figure11_scalability(src: Sources) -> Optional[str]:
    frame = src.frame("figure11_scalability.csv")
    if frame is None:
        print("[skip] figure 11: no figure11_scalability.csv")
        return None

    fig, ax = plt.subplots(figsize=(3.8, 2.7))
    ax.plot(frame["active_users"], frame["total_inference_ms_per_user"],
            color=PALETTE["blue"], marker="o", ms=3.4, lw=1.4,
            label="Inference + attribution")
    ax.set_xlabel("Active users per window")
    ax.set_ylabel("Latency per user (ms)")
    ax.set_title("Fig. 11  Scalability")
    ax.grid(True, alpha=0.5)
    ax.legend(loc="upper left", fontsize=7)
    out = FIGURES / "figure11_scalability.png"
    save(fig, str(out))
    return out.name


# --------------------------------------------------------------------------- #
# Figure 12 - attribution fidelity across the methods
# --------------------------------------------------------------------------- #
def figure12_fidelity(src: Sources) -> Optional[str]:
    frame = src.frame("table08_detection_performance.csv")
    if frame is None:
        print("[skip] figure 12: no table08_detection_performance.csv")
        return None
    frame = frame[frame["fidelity"].notna()].copy()
    if frame.empty:
        print("[skip] figure 12: no method reports a fidelity value")
        return None

    fig, ax = plt.subplots(figsize=(3.6, 2.6))
    colours = [PALETTE["blue"] if "Shadow" in m else PALETTE["cyan"]
               for m in frame["method"]]
    bars = ax.bar(range(len(frame)), frame["fidelity"], color=colours,
                  width=0.55, edgecolor="black", lw=0.6)
    _bar_labels(ax, bars)
    ax.set_xticks(range(len(frame)))
    ax.set_xticklabels(frame["method"], rotation=25, ha="right", fontsize=7)
    ax.set_ylabel("Attribution fidelity")
    ax.set_ylim(0, 1.0)
    ax.set_title("Fig. 12  Attribution fidelity by method")
    ax.grid(True, axis="y", alpha=0.5)
    out = FIGURES / "figure12_attribution_fidelity.png"
    save(fig, str(out))
    return out.name


# --------------------------------------------------------------------------- #
# Figure 13 - ablation
# --------------------------------------------------------------------------- #
def figure13_ablation(src: Sources) -> Optional[str]:
    frame = src.frame("table11_ablation.csv")
    if frame is None:
        print("[skip] figure 13: no table11_ablation.csv")
        return None

    fig, ax = plt.subplots(figsize=(5.4, 3.1))
    labels = [
        "Full",
        "No keystroke proxy",
        "No mouse proxy",
        "No application channel",
        "No keystroke and mouse",
        "No smoothness regulariser",
        "Uniform attention",
        "No Shapley layer",
    ]
    if len(frame) != len(labels):
        labels = [str(v).split(" (")[0] for v in frame["configuration"]]
    values = frame["auc_roc_mean"].to_numpy()
    errors = frame["auc_roc_std"].fillna(0.0).to_numpy()
    bars = ax.bar(range(len(values)), values, yerr=errors, capsize=2.5, width=0.62,
                  color=PALETTE["blue"], edgecolor="black", lw=0.6,
                  error_kw={"elinewidth": 0.7, "ecolor": "#444444"})
    ax.set_xticks(range(len(values)))
    ax.set_xticklabels(labels, rotation=32, ha="right", fontsize=6.8)
    ax.axhline(0.987, color=PALETTE["red"], ls="--", lw=0.9,
               label="Full model (0.987)")
    ax.set_ylabel("AUC-ROC")
    ax.set_ylim(0.93, 1.0)
    ax.set_title("Fig. 13  Ablation study")
    ax.grid(True, axis="y", alpha=0.5)
    ax.legend(loc="lower right", fontsize=7)
    out = FIGURES / "figure13_ablation.png"
    save(fig, str(out))
    return out.name


# --------------------------------------------------------------------------- #
# Figure 14 - analyst triage time
# --------------------------------------------------------------------------- #
def figure14_triage(src: Sources) -> Optional[str]:
    frame = src.frame("table13_triage_results.csv")
    if frame is None:
        print("[skip] figure 14: no table13_triage_results.csv")
        return None
    frame = frame[frame["mean_triage_time_min"].notna()].copy()
    frame = frame[~frame["condition"].astype(str).str.startswith("Difference")]
    if frame.empty:
        print("[skip] figure 14: no triage timing rows")
        return None

    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    names = ["No attribution", "With Shapley attribution"]
    values = frame["mean_triage_time_min"].to_numpy()
    errors = frame["sd_across_participants"].fillna(0.0).to_numpy()
    bars = ax.bar(names, values, yerr=errors, capsize=3, width=0.52,
                  color=[PALETTE["red"], PALETTE["blue"]],
                  edgecolor="black", lw=0.6,
                  error_kw={"elinewidth": 0.8, "ecolor": "#444444"})
    _bar_labels(ax, bars, fmt="{:.1f}")
    ax.set_ylabel("Mean triage time (min)")
    ax.set_title("Fig. 14  Analyst triage time")
    ax.grid(True, axis="y", alpha=0.5)
    out = FIGURES / "figure14_triage_time.png"
    save(fig, str(out))
    return out.name


# --------------------------------------------------------------------------- #
def main(argv: Optional[List[str]] = None) -> int:
    global FIGURES
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--source", choices=["auto", "reproduced", "tables"],
                        default="auto",
                        help="which result tables to draw from (default: auto)")
    parser.add_argument("--out", default=str(FIGURES),
                        help="output directory for the PNG files")
    parser.add_argument("--dpi", type=int, default=600,
                        help="raster DPI (the paper uses 600)")
    parser.add_argument("--format", default="png", choices=["png", "pdf"],
                        help="output format")
    args = parser.parse_args(argv)

    apply_style()
    FIGURES = Path(args.out)
    FIGURES.mkdir(parents=True, exist_ok=True)

    src = Sources(args.source)
    builders = [figure07_roc, figure08_channel_contribution, figure09_drift,
                figure10_alert_volume, figure11_scalability,
                figure12_fidelity, figure13_ablation, figure14_triage]

    made: List[str] = []
    for builder in builders:
        try:
            name = builder(src)
        except Exception as exc:  # a missing table must not stop the rest
            print(f"[error] {builder.__name__}: {exc}")
            continue
        if name:
            made.append(name)

    print(f"[ok] wrote {len(made)} figure(s) to {FIGURES}")
    if src.used:
        print("     sources used:")
        for name, origin in sorted(src.used.items()):
            print(f"       {origin:>9}  {name}")
    if args.format == "pdf":
        # Regenerate as PDF by re-running with a .pdf suffix handled inside
        # each builder would be invasive; instead convert what was produced.
        import subprocess
        for name in made:
            stem = Path(name).stem
            subprocess.run(["convert", str(FIGURES / f"{stem}.png"),
                            str(FIGURES / f"{stem}.pdf")], check=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
