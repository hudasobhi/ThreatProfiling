#!/usr/bin/env python3
"""Check evidence/provenance files without implying model reproduction."""
import csv, json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "results/raw_runs/evidence_manifest.json").read_text())
assert manifest["training_runs_performed_for_this_package"] == 0
assert manifest["participant_level_triage_results_available_from_manuscript"] is False
with (ROOT / "results/raw_runs/paper_reported_seed_level_auc.csv").open(newline="") as f:
    rows = list(csv.DictReader(f))
assert len(rows) == 10
assert all(r["evidence_status"] == "transcribed_from_paper_not_raw_run" for r in rows)
assert all(r["shadowdetectai_auc_roc"] and r["lan_auc_roc"] for r in rows)
assert all(not r["precision"] and not r["confusion_tp"] for r in rows)
with (ROOT / "results/raw_runs/per_seed_results_template.csv").open(newline="") as f:
    template = list(csv.DictReader(f))
assert [int(r["seed"]) for r in template] == manifest["paper_random_seeds"]
assert all(r["evidence_status"] == "not_supplied_in_original_archive" for r in template)
assert all(not r["auc_roc"] and not r["precision"] for r in template)
for name, field in [("per_participant_times.csv", "seconds"), ("per_participant_accuracy.csv", "correct")]:
    with (ROOT / "triage_study/results" / name).open(newline="") as f:
        triage = list(csv.DictReader(f))
    assert triage and all(not row[field] for row in triage), f"Unexpected filled template: {name}"
print("Evidence audit passed: published AUC pairs are provenance-labeled; all ten seed templates are present; unavailable raw and participant data remain unfilled.")
