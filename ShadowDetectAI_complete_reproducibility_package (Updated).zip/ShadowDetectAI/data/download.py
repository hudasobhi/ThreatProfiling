"""Download the CMU CERT r6.2 insider threat corpus.

Official source (the paper's Data Availability statement):

    https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247

The KiltHub record requires a user to accept the dataset terms before the
archive is served, so the script supports two routes:

  1. ``--url`` - point at the direct archive URL that the KiltHub download
     button resolves to.  The script then downloads it with resume support and
     SHA256 verification.
  2. ``--local`` - point at an archive that was downloaded manually.  The
     script verifies the checksum (when known) and copies it into
     ``data/raw/``.

Checksum
--------
The paper does not publish a SHA256 digest for the corpus, and this
repository will not invent one.  ``data/checksums.sha256`` holds the entry
with the digest marked ``[UNVERIFIED]``.  Record the digest of your own copy
there; the verification step then becomes meaningful for every later run::

    sha256sum data/raw/cert.r6.2.zip >> data/checksums.sha256

Usage
-----
    python data/download.py --local /path/to/cert.r6.2.zip
    python data/download.py --url <direct archive url>
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import sys
import urllib.request
from pathlib import Path
from typing import Optional

REPO_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = REPO_ROOT / "data" / "raw"
CHECKSUM_FILE = REPO_ROOT / "data" / "checksums.sha256"

#: The official record URL, quoted from the paper.
RECORD_URL = ("https://kilthub.cmu.edu/articles/dataset/"
               "Insider_Threat_Test_Dataset/12841247")

#: Filename the corpus archive is stored under inside data/raw.
ARCHIVE_NAME = "cert.r6.2.zip"

CHUNK = 1 << 20


def sha256(path: Path) -> str:
    """Return the SHA256 hex digest of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def expected_checksum(name: str = ARCHIVE_NAME) -> Optional[str]:
    """Look up the expected digest in ``data/checksums.sha256``.

    Returns ``None`` when the entry is missing or still marked
    ``[UNVERIFIED]``, in which case verification is skipped with a warning
    rather than being silently faked.
    """
    if not CHECKSUM_FILE.exists():
        return None
    for line in CHECKSUM_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) != 2:
            continue
        digest, fname = parts
        if fname.lstrip("*") == name:
            if "[UNVERIFIED]" in digest:
                return None
            return digest
    return None


def verify(path: Path, name: str = ARCHIVE_NAME) -> bool:
    """Verify a downloaded file against the recorded digest.

    Returns True when the digest matches or when no digest is recorded (in
    which case a warning is printed).
    """
    expected = expected_checksum(name)
    if expected is None:
        print(f"[warn] no verified SHA256 recorded for {name}; "
              "see data/checksums.sha256", file=sys.stderr)
        return True
    actual = sha256(path)
    ok = actual.lower() == expected.lower()
    print(f"[{'ok' if ok else 'FAIL'}] sha256 {name}: {actual}")
    return ok


def download(url: str, dest: Path, resume: bool = True) -> Path:
    """Download ``url`` to ``dest`` with HTTP range resume support."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    mode = "wb"
    headers = {}
    if resume and dest.exists() and dest.stat().st_size > 0:
        headers["Range"] = f"bytes={dest.stat().st_size}-"
        mode = "ab"
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req) as resp, open(dest, mode) as fh:
        if resp.status == 200 and mode == "ab":
            # Server ignored the range request; restart from scratch.
            fh.close()
            mode = "wb"
        total = 0
        while True:
            chunk = resp.read(CHUNK)
            if not chunk:
                break
            fh.write(chunk)
            total += len(chunk)
            print(f"\r  downloaded {total/1e6:.1f} MB", end="", flush=True)
    print()
    return dest


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--url", help="direct archive URL served by the KiltHub record")
    src.add_argument("--local", help="path to an archive downloaded manually")
    ap.add_argument("--no-verify", action="store_true",
                    help="skip the SHA256 check")
    args = ap.parse_args(argv)

    RAW_DIR.mkdir(parents=True, exist_ok=True)
    dest = RAW_DIR / ARCHIVE_NAME

    if args.local:
        src_path = Path(args.local)
        if not src_path.exists():
            print(f"[FAIL] {src_path} does not exist", file=sys.stderr)
            return 1
        if src_path.resolve() != dest.resolve():
            print(f"[..] copying {src_path} -> {dest}")
            shutil.copy2(src_path, dest)
    else:
        print(f"[..] downloading from {args.url}")
        download(args.url, dest)

    if not args.no_verify:
        if not verify(dest):
            return 1

    size = dest.stat().st_size / 1e6
    print(f"[ok] {dest} ready ({size:.1f} MB)")
    print(f"[..] next: python data/extract.py --input {dest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
