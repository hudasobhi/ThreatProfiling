# Data

The CMU CERT r6.2 insider threat corpus is **not** redistributed here.  This
directory contains the scripts that fetch, extract and preprocess it, and the
manifests that record how the split was made.

## The corpus

| | |
|---|---|
| Name | CMU CERT r6.2 insider threat test dataset |
| Official record | <https://kilthub.cmu.edu/articles/dataset/Insider_Threat_Test_Dataset/12841247> |
| DOI | `[UNVERIFIED]` — the paper gives no DOI for the dataset |
| Licence | `[UNVERIFIED]` — the KiltHub record's terms are not quoted in the paper; read them before downloading |
| SHA256 | `[UNVERIFIED]` — no digest is published.  `checksums.sha256` carries a placeholder; record your own copy's digest so the check becomes meaningful |
| Span | 18 months, 4,000 employee identities, 5 malicious insider identities |
| Logs used | `logon`, `file`, `email`, `device`, `http` |
| Hardware telemetry | none exists in the release and none is read |

## Getting it

```bash
python data/download.py --local /path/to/cert.r6.2.zip
# or: python data/download.py --url <direct-archive-url-from-KiltHub>
python data/extract.py --input data/raw/cert.r6.2.zip --dest data/extracted
python data/preprocess.py --input data/extracted --out data/processed
```

`download.py` accepts either a local archive path or a direct archive URL
resolved from the official KiltHub record. Because no digest is published, the
placeholder entry is skipped rather than failed; compute and record a digest
for your own copy before sharing experimental results. You must accept the
dataset terms yourself at the KiltHub record.

## What preprocessing produces

```
data/processed/
├── events.csv                  the union of the five activity logs, normalised
├── sessions.csv                sessionised activity
├── windows.csv                 the 24-hour window assignment
├── labels.csv                  the weak labels and the malicious identities
├── graphs/                     one graph per window (see scripts/03_build_graphs.py)
├── keystroke_timing_proxy.csv  the Eq. (11)-(13) features
├── mouse_interaction_proxy.csv the Eq. (14) features
└── application_events.csv      the Eq. (15) inputs
```

## The split

`data/splits/partition_manifest.json` and `data/splits/loio_folds.json`
record the split.  Both are **reference copies**: the month ranges, the
window length, the cold-start policy and the identity list are fixed by the
paper, while the absolute calendar bounds and the per-identity window
indices are derived from the corpus at run time.  `data/preprocess.py`
rewrites both files with the resolved values when it runs.

| Partition | Months from origin | Malicious windows | Malicious identities | Node entries |
|---|---|---|---|---|
| train | 1–13 | 42 | 3 | 3,200 |
| validation | 14–15 | 9 | 1 | 690 |
| test | 16–18 | 9 | 1 | 690 |

The partitions are contiguous — **no gap month** — which the paper states as
a limitation in Section 6.1.

## The five logs, and the fields that are never read

`cert_loader.py` reads the five activity logs and normalises them to a common
schema: `timestamp`, `user`, `activity`, `resource`, `channel`.

`assert_no_hardware_fields` raises if the event table contains any column
whose name looks like hardware telemetry — `press`, `release`, `keycode`,
`x_coord`, `y_coord`, `pointer`, `pressure`, `click_x`, `click_y`.  This is
not a formality: the paper's construct-validity claim rests on the pipeline
never touching a device-level sensor, and the check makes that claim
mechanically true rather than merely stated.  `tests/test_no_hardware_fields.py`
additionally verifies that the proxy computation is **invariant** to the
presence of such columns.

## Licence and redistribution

The corpus is not covered by this repository's MIT licence.  Do not commit
anything under `data/raw/`, `data/extracted/` or `data/processed/` — the
`.gitignore` already excludes them, and the derived files are still derived
from personal-data-shaped records.
