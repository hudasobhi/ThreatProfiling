"""Extract the CERT r6.2 archive into ``data/raw/cert.r6.2``.

The corpus ships as a zip containing one compressed archive per simulation
day (``cert.r6.2.<YYYY-MM-DD>.tar.bz2``), each holding the five activity
logs under ``cert.r6.2.<date>/logs/`` and, for some releases, the insider
threat ground truth under ``answers/``.

Usage
-----
    python data/extract.py --input data/raw/cert.r6.2.zip
"""
from __future__ import annotations

import argparse
import bz2
import shutil
import tarfile
import zipfile
from pathlib import Path
from typing import Optional

REPO_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = REPO_ROOT / "data" / "raw"
DEST_DIR = RAW_DIR / "cert.r6.2"


def extract_zip(archive: Path, dest: Path) -> int:
    """Extract a zip archive and return the number of members written."""
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zf:
        members = zf.namelist()
        zf.extractall(dest)
    return len(members)


def extract_daily_tars(root: Path) -> int:
    """Extract every ``cert.r6.2.*.tar.bz2`` found under ``root``."""
    n = 0
    for tar_path in sorted(root.rglob("cert.r6.2.*.tar.bz2")):
        out_dir = tar_path.parent / tar_path.name.replace(".tar.bz2", "")
        if out_dir.exists() and any(out_dir.iterdir()):
            continue
        out_dir.mkdir(parents=True, exist_ok=True)
        with tarfile.open(tar_path, "r:bz2") as tar:
            tar.extractall(out_dir)
        n += 1
    return n


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", default=str(RAW_DIR / "cert.r6.2.zip"))
    ap.add_argument("--dest", default=str(DEST_DIR))
    ap.add_argument("--keep-daily-tars", action="store_true",
                    help="do not delete the per-day .tar.bz2 files after extraction")
    args = ap.parse_args(argv)

    archive = Path(args.input)
    if not archive.exists():
        print(f"[FAIL] {archive} not found. Run data/download.py first.")
        return 1
    dest = Path(args.dest)
    dest.mkdir(parents=True, exist_ok=True)

    print(f"[..] extracting {archive} -> {dest}")
    if archive.suffix == ".zip":
        n = extract_zip(archive, dest)
        print(f"[ok] {n} members extracted")
    else:
        print(f"[FAIL] unsupported archive type {archive.suffix}; expected .zip")
        return 1

    n_tars = extract_daily_tars(dest)
    print(f"[ok] {n_tars} daily archives expanded")

    if not args.keep_daily_tars:
        for tar_path in sorted(dest.rglob("cert.r6.2.*.tar.bz2")):
            tar_path.unlink(missing_ok=True)
        print("[..] daily .tar.bz2 files removed (use --keep-daily-tars to keep them)")

    logs = list(dest.rglob("logs"))
    print(f"[ok] 'logs' directories found: {len(logs)}")
    print(f"[..] next: python data/preprocess.py --input {dest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
