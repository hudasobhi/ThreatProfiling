"""Build the processed feature tables from the extracted CERT r6.2 corpus.

The pipeline mirrors the paper's Section 6.1 and Section 4.1:

  1. load the five activity logs and assert that no hardware biometric field
     is present (Table 3, Ethical Considerations);
  2. sessionise each (user, channel) stream;
  3. assign the non-overlapping 24-hour windows;
  4. compute the three behavioural proxy channels;
  5. label malicious windows from the corpus ground truth;
  6. write the chronological partition manifest.

Usage
-----
    python data/preprocess.py --input data/raw/cert.r6.2
"""
from __future__ import annotations

import argparse
import sys

import pandas as pd
from pathlib import Path
from typing import Optional

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from shadowdetectai.data.cert_loader import (  # noqa: E402
    CHANNEL_SOURCE, assert_no_hardware_fields, load_events)
from shadowdetectai.data.labeling import label_windows, load_answers, summarise  # noqa: E402
from shadowdetectai.data.partition import (  # noqa: E402
    partition_manifest, partition_report, split_windows, write_manifest)
from shadowdetectai.data.sessionize import sessionize  # noqa: E402
from shadowdetectai.data.windowing import assign_windows  # noqa: E402
from shadowdetectai.features.keystroke_timing_proxy import (  # noqa: E402
    user_window_keystroke_features)
from shadowdetectai.features.mouse_interaction_proxy import (  # noqa: E402
    user_window_mouse_features)
from shadowdetectai.utils.io import ensure_dir, write_csv_dicts  # noqa: E402


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", default=str(REPO_ROOT / "data" / "raw" / "cert.r6.2"))
    ap.add_argument("--out", default=str(REPO_ROOT / "data" / "processed"))
    ap.add_argument("--splits", default=str(REPO_ROOT / "data" / "splits"))
    ap.add_argument("--tables", default=str(REPO_ROOT / "results" / "reproduced"),
                    help="where the reproduced Table 5 is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--window-hours", type=int, default=24)
    ap.add_argument("--session-gap-seconds", type=int, default=1800)
    args = ap.parse_args(argv)

    out_dir = ensure_dir(Path(args.out))
    splits_dir = ensure_dir(Path(args.splits))

    print("[1/6] loading CERT r6.2 activity logs")
    events = load_events(args.input)
    assert_no_hardware_fields(events.columns)
    print(f"      {len(events):,} events, {events['user'].nunique():,} users")

    print("[2/6] sessionising")
    sessions = sessionize(events, gap_seconds=args.session_gap_seconds)
    print(f"      {sessions['session_id'].nunique():,} sessions")

    print("[3/6] assigning 24-hour windows")
    windows = assign_windows(sessions, window_hours=args.window_hours)

    print("[4/6] computing behavioural proxy channels")
    ks = windows[windows["channel"] == "keystroke_timing_proxy"]
    mouse = windows[windows["channel"] == "mouse_interaction_proxy"]
    app = windows[windows["channel"] == "application_sequencing"]
    ks_feats = user_window_keystroke_features(ks)
    mouse_feats = user_window_mouse_features(mouse)
    write_csv_dicts(out_dir / "keystroke_timing_proxy.csv", ks_feats.to_dict("records"))
    write_csv_dicts(out_dir / "mouse_interaction_proxy.csv", mouse_feats.to_dict("records"))
    write_csv_dicts(out_dir / "application_events.csv", app.to_dict("records"))
    print(f"      keystroke rows {len(ks_feats):,} | mouse rows {len(mouse_feats):,}")

    print("[5/6] labelling malicious windows")
    answers = load_answers(args.input)
    labels = label_windows(windows, answers, window_hours=args.window_hours)
    stats = summarise(labels)
    print(f"      {stats}")

    print("[6/6] writing the partition manifest")
    manifest = partition_manifest(windows, window_hours=args.window_hours)
    write_manifest(manifest, splits_dir / "partition_manifest.json")
    report = partition_report(labels, manifest, window_hours=args.window_hours)

    # Tag every table with the partition each row belongs to, so the
    # training-partition analyses (Table 10a) can select the right rows.
    parts = split_windows(labels["window_index"], manifest,
                           window_hours=args.window_hours)
    labels = labels.copy()
    labels["partition"] = parts.values
    write_csv_dicts(out_dir / "labels.csv", labels.to_dict("records"))
    for name in ("keystroke_timing_proxy.csv", "mouse_interaction_proxy.csv",
                 "application_events.csv"):
        path = out_dir / name
        if not path.exists():
            continue
        frame = pd.read_csv(path)
        if "partition" in frame.columns:
            continue
        merged = frame.merge(labels[["user", "window_index", "partition"]],
                             on=["user", "window_index"], how="left")
        write_csv_dicts(path, merged.to_dict("records"))

    # Table 5 belongs with the result tables, not with the processed data.
    tables_dir = Path(args.tables)
    tables_dir.mkdir(parents=True, exist_ok=True)
    write_csv_dicts(tables_dir / "table05_dataset_partitions.csv",
                    report.to_dict("records"))
    print(report.to_string(index=False))
    print(f"[ok] processed artefacts written to {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
