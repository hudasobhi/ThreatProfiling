# Triage result files: evidence status

The two CSV files in this directory are **collection templates, not observed participant data**. Their `seconds` and `correct` cells are blank because the supplied manuscript and repository archive do not contain participant-level records. Do not treat blanks as zero or fill them by reverse-engineering the Table 13 aggregates.

The manuscript reports only group-level summaries in Table 13: no attribution, mean 4.7 min/alert (SD 1.1), accuracy 0.73 ± 0.09; with attribution, mean 2.1 min/alert (SD 0.6), accuracy 0.81 ± 0.07. These summaries do not uniquely determine the ten participants' times or correctness values.

To release actual participant-level records, obtain the original de-identified study export from the authors and confirm that ethics approval/exemption permits release. Preserve a copy of the received source file and record its provenance, collection date, and checksum before analysis. `scripts/15_triage_analysis.py` should only be run on completed, verified observations.
