#!/usr/bin/env python3
"""The analyst-triage interface (paper Section 6.4, Table 13).

A dependency-free local web application that presents the twenty-alert pool
to a participant one alert at a time, records the elapsed time and the
analyst's disposition, and appends both to the de-identified per-participant
CSVs.

It uses only the Python standard library so that a study session needs
nothing beyond a checkout of this repository.

Usage::

    python triage_study/interface/triage_app.py --participant 1
    python triage_study/interface/triage_app.py --participant 7 --port 8080

Then open http://127.0.0.1:8000/ in a browser.

The two conditions differ in exactly one respect: the **attribution**
condition also shows the top-five behavioural features with their
contributions, while the **no-attribution** condition shows the aggregate
anomaly score only.  Everything else - the alert set, the order, the wording
and the timing - is identical.  See ``protocol/decision_rubric.md``.

Only the standard library is used, so this file runs anywhere Python does.
"""
from __future__ import annotations

import argparse
import csv
import html
import json
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import parse_qs, urlparse

STUDY = Path(__file__).resolve().parents[1]
ALERTS = STUDY / "alerts" / "alert_pool_20.csv"
PRACTICE = STUDY / "alerts" / "practice_block_5.csv"
SCHEDULE = STUDY / "protocol" / "counterbalancing_schedule.csv"
RESULTS = STUDY / "results"

TIMES_CSV = RESULTS / "per_participant_times.csv"
ACCURACY_CSV = RESULTS / "per_participant_accuracy.csv"

DERIVED = "[DERIVED AT RUN TIME]"


# --------------------------------------------------------------------------- #
# loading
# --------------------------------------------------------------------------- #
def load_alerts(path: Path) -> Dict[str, Dict[str, str]]:
    with open(path, "r", encoding="utf-8", newline="") as fh:
        return {row["alert_id"]: row for row in csv.DictReader(fh)}


def load_schedule(path: Path, participant: int) -> Dict[str, object]:
    with open(path, "r", encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            if int(row["participant_id"]) == participant:
                return {
                    "condition_order": row["condition_order"].split(" then "),
                    "attribution_alerts": row["attribution_alerts"].split(),
                    "no_attribution_alerts": row["no_attribution_alerts"].split(),
                    "practice_alerts": row["practice_alerts"].split(),
                }
    raise SystemExit(f"participant {participant} is not in {path}")


class Session:
    """The state of one participant's session."""

    def __init__(self, participant: int) -> None:
        self.participant = participant
        self.alerts = load_alerts(ALERTS)
        self.practice = load_alerts(PRACTICE)
        self.schedule = load_schedule(SCHEDULE, participant)
        self.queue: List[Dict[str, object]] = []
        for condition in self.schedule["condition_order"]:
            ids = (self.schedule["attribution_alerts"] if condition == "attribution"
                   else self.schedule["no_attribution_alerts"])
            for alert_id in ids:
                self.queue.append({"alert_id": alert_id, "condition": condition,
                                   "practice": False})
        for alert_id in self.schedule["practice_alerts"] or list(self.practice):
            self.queue.append({"alert_id": alert_id, "condition": "practice",
                               "practice": True})
        self.index = 0
        self.shown_at: Optional[float] = None
        self.results: List[Dict[str, object]] = []

    @property
    def current(self) -> Optional[Dict[str, object]]:
        if self.index < len(self.queue):
            return self.queue[self.index]
        return None

    def record(self, disposition: str) -> None:
        item = self.current
        if item is None:
            return
        elapsed = 0.0 if self.shown_at is None else time.time() - self.shown_at
        alert = self.alerts.get(item["alert_id"], {})
        truth = alert.get("ground_truth_label", "")
        correct = ""
        if truth not in ("", None, DERIVED):
            correct = int((disposition == "malicious") == (truth == "1"))
        self.results.append({
            "participant_id": self.participant,
            "condition": item["condition"],
            "alert_id": item["alert_id"],
            "seconds": round(elapsed, 3) if not item["practice"] else "",
            "correct": correct,
        })
        self.index += 1
        self.shown_at = None


def write_results(session: Session) -> None:
    """Append the session's rows to the two de-identified CSVs."""
    RESULTS.mkdir(parents=True, exist_ok=True)
    for path, field in ((TIMES_CSV, "seconds"), (ACCURACY_CSV, "correct")):
        exists = path.exists()
        with open(path, "a", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            if not exists:
                writer.writerow(["participant_id", "condition", "alert_id", field])
            for row in session.results:
                writer.writerow([row["participant_id"], row["condition"],
                                 row["alert_id"], row[field]])


# --------------------------------------------------------------------------- #
# rendering
# --------------------------------------------------------------------------- #
PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<title>Triage study - participant {pid}</title>
<style>
 body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif;
        margin: 2rem auto; max-width: 46rem; color: #1a1a1a; }}
 .card {{ border: 1px solid #d0d0d0; border-radius: 8px; padding: 1.2rem 1.4rem;
          margin-bottom: 1rem; }}
 .meta {{ color: #555; font-size: .9rem; }}
 .score {{ font-size: 2.4rem; font-weight: 600; }}
 table {{ border-collapse: collapse; width: 100%; margin-top: .6rem; }}
 th, td {{ text-align: left; padding: .35rem .5rem; border-bottom: 1px solid #eee; }}
 .up {{ color: #b3261e; font-weight: 600; }}
 .down {{ color: #1b5e20; font-weight: 600; }}
 button {{ font-size: 1rem; padding: .6rem 1.2rem; margin-right: .6rem;
           border-radius: 6px; border: 1px solid #999; cursor: pointer; }}
 .malicious {{ background: #b3261e; color: #fff; border-color: #b3261e; }}
 .benign {{ background: #1b5e20; color: #fff; border-color: #1b5e20; }}
 .bar {{ height: 6px; background: #e0e0e0; border-radius: 3px; overflow: hidden; }}
 .bar > div {{ height: 100%; background: #1a73e8; }}
</style></head><body>
{body}
</body></html>"""


def _contributors_html(alert: Dict[str, str]) -> str:
    """Render the top-five attribution panel.

    The panel is the *only* difference between the two conditions.  The
    contribution values live in the run-derived alert pool; when they are not
    available the panel is rendered with a clear placeholder rather than with
    invented numbers.
    """
    rows = []
    for i in range(1, 6):
        feature = alert.get(f"top{i}_feature", "")
        value = alert.get(f"top{i}_value", "")
        if not feature:
            feature = f"behavioural_feature_{i}"
        if not value or value == DERIVED:
            value = "-"
        direction = ""
        try:
            if float(value) > 0:
                direction = "up"
            elif float(value) < 0:
                direction = "down"
        except (TypeError, ValueError):
            pass
        span = ""
        try:
            width = min(100.0, abs(float(value)) * 100.0)
            span = f'<div class="bar"><div style="width:{width:.1f}%"></div></div>'
        except (TypeError, ValueError):
            pass
        rows.append(f"<tr><td>{html.escape(feature)}</td>"
                    f"<td class='{direction}'>{html.escape(str(value))}</td>"
                    f"<td style='width:45%'>{span}</td></tr>")
    return ("<h3>Top five behavioural contributions</h3>"
            "<table><tr><th>Feature</th><th>Contribution</th><th></th></tr>"
            + "".join(rows) + "</table>")


def render(session: Session) -> str:
    item = session.current
    if item is None:
        write_results(session)
        return PAGE.format(pid=session.participant, body="""
<h1>Session complete</h1>
<p>Thank you. Your responses have been recorded. You may close this window.</p>""")

    alert = session.alerts.get(item["alert_id"], {})
    if item["practice"]:
        header = ("<h1>Practice block</h1>"
                  "<p class='meta'>These five alerts are <strong>not</strong> timed "
                  "and <strong>not</strong> scored. They are there so you can learn "
                  "the interface.</p>")
    else:
        total = len([q for q in session.queue if not q["practice"]])
        done = len([q for q in session.queue[:session.index] if not q["practice"]])
        header = (f"<h1>Alert {done + 1} of {total}</h1>"
                  f"<p class='meta'>Participant {session.participant} &middot; "
                  f"condition: {html.escape(str(item['condition']))}</p>")

    score = alert.get("score", DERIVED)
    try:
        score = f"{float(score):.4f}"
    except (TypeError, ValueError):
        score = str(score)

    panel = ""
    if item["condition"] == "attribution" and not item["practice"]:
        panel = _contributors_html(alert)

    action = f"/decide?d=malicious" if not item["practice"] else "/decide?d=skip"
    return PAGE.format(pid=session.participant, body=f"""
{header}
<div class="card">
  <p class="meta">User <strong>{html.escape(str(alert.get('user', '-')))}</strong>
     &middot; window <strong>{html.escape(str(alert.get('window_index', '-')))}</strong></p>
  <p class="meta">Aggregate anomaly score</p>
  <p class="score">{html.escape(score)}</p>
  {panel}
</div>
<form method="get" action="{action}">
  <button class="malicious" type="submit" name="x" value="1">Escalate for investigation</button>
  <button class="benign" type="submit" name="x" value="1">Dismiss as benign</button>
</form>""")


# --------------------------------------------------------------------------- #
# server
# --------------------------------------------------------------------------- #
class Handler(BaseHTTPRequestHandler):
    session: Session = None  # type: ignore[assignment]

    def _send(self, body: str, status: int = 200) -> None:
        payload = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path == "/decide":
            params = parse_qs(parsed.query)
            disposition = (params.get("d") or [""])[0]
            if disposition in ("malicious", "benign"):
                self.session.record(disposition)
            else:
                self.session.index += 1
                self.session.shown_at = None
            self._send(render(self.session))
            return
        if parsed.path == "/state":
            state = {"participant": self.session.participant,
                     "index": self.session.index,
                     "total": len(self.session.queue),
                     "current": self.session.current}
            self._send(json.dumps(state, default=str))
            return
        if self.session.current is not None and self.session.shown_at is None:
            self.session.shown_at = time.time()
        self._send(render(self.session))

    def log_message(self, fmt: str, *args) -> None:  # quieter console
        return


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--participant", type=int, required=True,
                        help="participant number, 1-10")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()

    session = Session(args.participant)
    Handler.session = session
    server = HTTPServer((args.host, args.port), Handler)
    print(f"[triage] participant {args.participant}: "
          f"{len(session.queue)} alerts, condition order "
          f"{' -> '.join(session.schedule['condition_order'])}")
    print(f"[triage] open http://{args.host}:{args.port}/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[triage] stopped")
    finally:
        write_results(session)
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
