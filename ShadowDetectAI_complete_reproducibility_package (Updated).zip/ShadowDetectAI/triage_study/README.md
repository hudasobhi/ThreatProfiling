# Analyst-triage study

The harness for the analyst-triage evaluation of Section 6.4, reported in
Table 13 and Figure 14.

## What the study asks

Does showing an analyst **why** a user was flagged — the top five
behavioural features that drove the anomaly score — change how fast and how
accurately they dispose of alerts?

* **Condition A (with attribution).**  The panel shows the aggregate anomaly
  score *and* the top five behavioural features with the magnitude and
  direction of each contribution.
* **Condition B (no attribution).**  The panel shows the aggregate anomaly
  score only.

Everything else is identical: the same twenty alerts, the same wording, the
same one-at-a-time presentation, the same timing.

## Design

| | |
|---|---|
| Participants | 10 (graduate researchers acting as analyst proxies) |
| Alerts per participant | 20 — every alert in the pool, seen exactly once |
| Design | within-subject; every participant completes both conditions, each on a different set of ten alerts, so a participant never sees an alert in both conditions |
| Practice block | 5 alerts, drawn from the validation partition, untimed and unscored |
| Order | counterbalanced 5/5; half do attribution first, half do no-attribution first |
| Counterbalancing | every alert appears in the attribution condition for 5 participants and in the no-attribution condition for 5 |
| Difficulty mix | each condition holds 5 true-positive and 5 false-positive alerts |
| Primary outcomes | mean triage time (minutes) and disposition accuracy |

## Layout

```
triage_study/
├── README.md
├── alerts/
│   ├── alert_pool_20.csv        the 20 timed alerts
│   └── practice_block_5.csv     the 5 untimed practice alerts
├── protocol/
│   ├── decision_rubric.md       the instruction sheet given to participants
│   └── counterbalancing_schedule.csv   each participant's order and alert list
├── interface/
│   └── triage_app.py            the study interface (standard library only)
└── results/
    ├── per_participant_times.csv    <- fill these in after the study
    └── per_participant_accuracy.csv <- and these
```

## The alert pool

The pool is **exhaustive, not sampled**: it contains every confirmed
detection of the seed-42 test-partition run, topped up from the validation
partition until the target composition of ten true-positive and ten
false-positive alerts is reached.

| Source | True positives | False positives | Total |
|---|---|---|---|
| test partition (seed 42) | 8 | 1 | 9 |
| validation partition | 2 | 9 | 11 |
| **pool** | **10** | **10** | **20** |

The test-partition counts are the confusion matrix of Table 9.  All
validation-partition stimuli derive from the single malicious insider
identity assigned to that partition, which the paper states as a limitation
of the stimulus pool.

`scripts/14_triage_alert_pool.py` rebuilds the pool from a real run and
overwrites these two CSVs.

## Running a session

```bash
python triage_study/interface/triage_app.py --participant 1
# then open http://127.0.0.1:8000/
```

The interface reads the participant's assignment from
`protocol/counterbalancing_schedule.csv`; it does not choose the order
itself.  It writes the session's rows to the two CSVs in `results/`.

The alert pool's `user`, `window_index`, `score` and `deviation_count`
fields — and the `top{1..5}_feature` / `top{1..5}_value` fields that fill
the attribution panel — are produced by the model run.  The shipped copies
carry `[DERIVED AT RUN TIME]` in those cells, and the interface renders
them as such rather than showing a fabricated number.  Run
`scripts/14_triage_alert_pool.py` to populate them.

## Producing Table 13 and Figure 14

Fill in `results/per_participant_times.csv` (`seconds` per alert) and
`results/per_participant_accuracy.csv` (`correct`: 1 or 0 per alert), then:

```bash
python scripts/15_triage_analysis.py
```

which writes `results/tables/table13_triage_results.csv` and Figure 14 from
those numbers, including the paired two-sided Wilcoxon signed-rank test
(W = 0, n = 10, p = 0.002 in the paper).

## Releasing the data

The original participant-level files are not present in this archive. The manuscript says they are available from the authors upon request, subject to ethics constraints. Do not invent them from Table 13 summaries. Any released files must be de-identified: participant number, condition,
alert identifier, elapsed seconds and the correctness flag.  No user
identifier, no alert content and no free text.  Confirm that your ethics
approval or exemption covers the release before publishing anything from
this directory.

## Limitations

* The participants are graduate researchers acting as analyst proxies, not
  trained SOC analysts with operational context.  The result is a proof of
  concept, not an operationally validated benchmark.
* The validation-partition stimuli come from a single malicious identity.
* The study is a proxy for a real triage workflow that also involves case
  management, escalation and retrospective review, none of which is modelled.
