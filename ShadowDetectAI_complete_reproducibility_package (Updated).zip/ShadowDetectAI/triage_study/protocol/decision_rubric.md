# Analyst decision rubric

The triage study asks an analyst to make one binary decision per alert:
**escalate the alert for investigation, or dismiss it as benign.**  The
rubric is the written instruction sheet given to every participant, and its
wording is identical in both conditions.

---

## 1. What is shown

| Field | No-attribution condition | Attribution condition |
|---|---|---|
| the user identifier | yes | yes |
| the window identifier | yes | yes |
| the aggregate anomaly score | yes | yes |
| the ranked top-five Shapley attribution panel (top five contributing feature values, with magnitude and direction) | no | yes |

The deviation count is **not displayed** by the triage interface in either
condition.  The only difference between the two conditions is the presence of
the ranked Shapley attribution panel.  The alert set, the order, the number of
alerts and the wording are otherwise identical.

## 2. Escalation criterion

The written criterion is the same in both conditions: escalate a flagged
session in which at least two behavioral deviations exceeded 1.5 standard
deviations from that user's 30-day baseline, consistent with the operational
threshold definition in the manuscript.

## 3. Your task

For each alert choose one of:

| Disposition | Meaning |
|---|---|
| **Escalate for investigation** | the alert warrants investigation |
| **Dismiss as benign** | the alert reflects a legitimate working pattern |

There is no third option and no abstention.  If you are unsure, make your
best judgement.

## 4. Timing

* The timer starts when the alert panel is first displayed and stops when a
  disposition is submitted.
* One alert is shown at a time; a previous alert cannot be revisited.
* The five-alert practice block is neither timed nor scored.
* If the connection is lost, the elapsed time for the current alert is
  recorded as missing and the alert is re-presented at the end of the session.

## 5. Ground truth for scoring

Each alert carries a hidden label.  A disposition is correct when it matches
that label:

| Hidden label | Correct disposition |
|---|---|
| true positive (malicious activity) | Escalate for investigation |
| false positive (legitimate activity) | Dismiss as benign |

Disposition accuracy is the fraction of a participant's alerts in a condition
that were disposed correctly, computed per condition and then averaged across
the ten participants.

## 6. Design and order

Ten participants each complete all twenty alerts exactly once: ten with the
attribution panel and ten without it, in a within-subject counterbalanced
design.

* Five participants complete the attribution condition first.
* Five complete the no-attribution condition first.
* Every alert appears in the attribution condition for five participants and
  in the no-attribution condition for five participants.
* Each condition holds five true-positive and five false-positive alerts.

Each participant's order and alert list are in
`protocol/counterbalancing_schedule.csv`, which the interface reads.

## 7. Conduct

* No external tool is used; the study measures the time the panel alone takes
  to interpret.
* User identifiers are synthetic and are not looked up.
* No alert is skipped; a skipped alert is recorded as a missing trial.
* Alerts are not discussed with other participants until the session is
  complete.

## 8. Consent and data

Participation is voluntary and may stop at any point.  Recorded: an arbitrary
participant number, the condition, the alert identifier, the elapsed seconds
per alert, the disposition and whether it matched the hidden label.  Not
recorded: names, contact details and free text.  The de-identified data files
are `results/per_participant_times.csv` and
`results/per_participant_accuracy.csv`.
