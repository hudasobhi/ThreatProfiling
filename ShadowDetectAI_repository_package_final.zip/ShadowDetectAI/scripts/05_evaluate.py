#!/usr/bin/env python3
"""Step 5 - evaluate the trained checkpoints and write Table 8 and Table 9.

Table 8 is written in the **wide** form the paper prints, so that
``compare_results.py`` can diff it value by value against
``results/tables/table08_detection_performance.csv``:

    method, auc_roc, auc_roc_std, precision, precision_std, recall,
    recall_std, f1, f1_std, fidelity

The operating threshold is the one of Eq. (33): the base threshold is fitted
on the **validation** partition at the target false-positive rate and then
widened by the population stability index between the validation and test
score distributions.  It is not a constant 0.5.

Table 9 is the confusion matrix of the **seed-42** run, which is the run the
paper reports.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch  # noqa: E402

from shadowdetectai.data.dataset import build_dataloader  # noqa: E402
from shadowdetectai.data.materialize import build_window_frame, channel_slices  # noqa: E402
from shadowdetectai.evaluation.confusion import confusion_matrix  # noqa: E402
from shadowdetectai.evaluation.metrics import classification_metrics, mean_std  # noqa: E402
from shadowdetectai.evaluation.operating_point import fit_operating_point  # noqa: E402
from shadowdetectai.evaluation.attribution_eval import (  # noqa: E402
    model_attribution_fidelity)
from shadowdetectai.training.checkpoints import load_checkpoint  # noqa: E402
from shadowdetectai.utils.config import get, load_config  # noqa: E402
from shadowdetectai.utils.io import write_csv_dicts  # noqa: E402
from shadowdetectai.models.build import make_model  # noqa: E402

METHOD = "ShadowDetectAI (proposed)"


@torch.no_grad()
def predict(model, loader, device):
    """Collect logits, labels and window indices from a loader."""
    model.eval()
    logits, labels, windows = [], [], []
    for batch in loader:
        batch = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}
        out = model(batch)
        logits.extend(out["logit"].detach().cpu().numpy().tolist())
        labels.extend(batch["label"].detach().cpu().numpy().astype(int).tolist())
        windows.extend(batch["window_index"].detach().cpu().numpy().tolist())
    return (np.asarray(logits, dtype=np.float64),
            np.asarray(labels, dtype=int),
            np.asarray(windows, dtype=int))


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60.0, 60.0)))


def mean_row(metrics: List[Dict[str, float]], name: str,
             fidelity: Optional[float] = None) -> Dict[str, object]:
    """Build one wide Table 8 row from the per-seed metrics."""
    row: Dict[str, object] = {"method": name}
    for key in ("auc_roc", "precision", "recall", "f1"):
        stats = mean_std([m[key] for m in metrics])
        row[key] = round(stats["mean"], 4)
        row[f"{key}_std"] = round(stats["std"], 4)
    row["fidelity"] = "" if fidelity is None else round(fidelity, 4)
    return row


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--calibration-config", default=str(ROOT / "configs" / "calibration.yaml"))
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--checkpoints", default=str(ROOT / "results" / "raw_runs"))
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    ap.add_argument("--fidelity", dest="fidelity", action="store_true", default=True,
                    help="compute the Eq. (30) attribution fidelity (default: on)")
    ap.add_argument("--no-fidelity", dest="fidelity", action="store_false")
    ap.add_argument("--max-fidelity-users", type=int, default=20,
                    help="cap on the flagged users used for the fidelity estimate")
    args = ap.parse_args()

    cfg = load_config(args.config)
    cal = load_config(args.calibration_config)
    dims = cfg["encoder"]["channel_dims"]
    order = list(cfg["encoder"]["channel_order"])
    slices = channel_slices(dims, order)

    val_frame = build_window_frame(args.processed, args.config, "validation")
    test_frame = build_window_frame(args.processed, args.config, "test")
    val_loader = build_dataloader(val_frame, slices, shuffle=False,
                                  batch_size=int(get(cfg, "training.batch_size", 256)))
    test_loader = build_dataloader(test_frame, slices, shuffle=False,
                                   batch_size=int(get(cfg, "training.batch_size", 256)))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = make_model(cfg).to(device)

    target_fpr = float(get(cal, "drift.target_fpr", 0.01))
    n_bins = int(get(cal, "drift.n_bins", 10))
    lambda_drift = float(get(cal, "drift.lambda_drift", 0.1))

    seeds = list(get(cfg, "seeds.list", [42]))
    ckpt_dir = Path(args.checkpoints)
    per_seed: List[Dict[str, float]] = []
    per_seed_rows: List[Dict[str, object]] = []
    thresholds: List[float] = []
    first_seed_payload = None

    for seed in seeds:
        path = ckpt_dir / f"seed{seed}_best.pt"
        if not path.exists():
            print(f"[warn] {path} missing, skipping")
            continue
        load_checkpoint(path, model)

        val_logits, val_labels, _ = predict(model, val_loader, device)
        test_logits, test_labels, test_windows = predict(model, test_loader, device)

        op = fit_operating_point(_sigmoid(val_logits), _sigmoid(test_logits),
                                 target_fpr=target_fpr, n_bins=n_bins,
                                 lambda_drift=lambda_drift)
        threshold = op["threshold"]
        thresholds.append(threshold)

        metrics = classification_metrics(test_labels, _sigmoid(test_logits),
                                         threshold=threshold)
        metrics["seed"] = seed
        per_seed.append(metrics)
        per_seed_rows.append({
            "seed": seed,
            "auc_roc": round(metrics["auc_roc"], 4),
            "precision": round(metrics["precision"], 4),
            "recall": round(metrics["recall"], 4),
            "f1": round(metrics["f1"], 4),
            "threshold": round(threshold, 4),
            "tau_0": round(op["tau_0"], 4),
            "psi": round(op["psi"], 4),
        })
        print(f"  seed {seed}: AUC {metrics['auc_roc']:.4f}  F1 {metrics['f1']:.4f}  "
              f"tau {threshold:.4f} (tau_0 {op['tau_0']:.4f}, PSI {op['psi']:.4f})")

        if seed == seeds[0]:
            first_seed_payload = (test_logits, test_labels, threshold)

    if not per_seed:
        print("[FAIL] no checkpoints found; run scripts/04_train.py first")
        return 1

    # ---- the attribution fidelity of Eq. (30) -------------------------- #
    fidelity_value = None
    if args.fidelity:
        try:
            train_frame = build_window_frame(args.processed, args.config, "train")
            fidelity_value = model_attribution_fidelity(
                model, test_frame, train_frame, device,
                n_background=int(get(cfg, "shap.n_background", 100)),
                n_coalitions=int(get(cfg, "shap.n_coalitions", 512)),
                max_users=args.max_fidelity_users)
        except Exception as exc:  # a missing graph must not lose the metrics
            print(f"[warn] attribution fidelity could not be computed: {exc}")
            fidelity_value = None

    row = mean_row(per_seed, METHOD, fidelity_value)
    write_csv_dicts(Path(args.out) / "table08_detection_performance.csv", [row])
    write_csv_dicts(Path(args.out) / "table08_shadowdetectai_per_seed.csv", per_seed_rows)

    # ---- Table 9: the confusion matrix of the seed-42 run -------------- #
    if first_seed_payload is not None:
        test_logits, test_labels, threshold = first_seed_payload
        cm = confusion_matrix(test_labels, _sigmoid(test_logits), threshold=threshold)
        write_csv_dicts(Path(args.out) / "table09_confusion_matrix.csv",
                        [{"cell": k, "count": v} for k, v in cm.items()])
        _write_alerts(Path(args.out), model, val_frame, test_frame, device,
                      threshold, args)

    # ---- the Wilcoxon table needs the per-seed AUC of the proposed model,
    #      which is written above; evaluate_all.py pairs it with LAN.

    print(f"[ok] wrote Table 8 (ShadowDetectAI row) and Table 9 to {args.out}")
    return 0


def _write_alerts(out_dir: Path, model, val_frame, test_frame, device,
                  threshold: float, args) -> None:
    """Write the confirmed alerts that seed the triage pool (Table 12).

    The paper builds the pool from the confirmed detections of the seed-42
    test-partition run, topped up from the validation partition.  The two
    CSVs written here are what ``scripts/14_triage_alert_pool.py`` reads.
    """
    for frame, name in ((test_frame, "test"), (val_frame, "validation")):
        loader = build_dataloader(frame, {}, shuffle=False, batch_size=512)
        users = list(frame.user)
        rows: List[Dict[str, object]] = []
        cursor = 0
        with torch.no_grad():
            for batch in loader:
                batch = {k: (v.to(device) if torch.is_tensor(v) else v)
                         for k, v in batch.items()}
                out = model(batch)
                scores = _sigmoid(out["logit"].detach().cpu().numpy())
                labels = batch["label"].detach().cpu().numpy().astype(int)
                windows = batch["window_index"].detach().cpu().numpy()
                for i in range(len(scores)):
                    row = cursor + i
                    cursor += 1
                    if scores[i] < threshold:
                        continue
                    truth = int(labels[i])
                    rows.append({
                        "alert_id": f"{name}_{len(rows) + 1:03d}",
                        "partition": name,
                        "is_true_positive": int(truth == 1),
                        "user": users[row] if row < len(users) else "",
                        "window_index": int(windows[i]),
                        "score": round(float(scores[i]), 6),
                        "deviation_count": 0,
                        "ground_truth_label": truth,
                    })
        write_csv_dicts(out_dir / f"triage_{name}_alerts.csv", rows)
        print(f"[ok] wrote {len(rows)} {name}-partition alerts")


if __name__ == "__main__":
    raise SystemExit(main())
