#!/usr/bin/env python3
"""Step 15 - analyse the triage study and write Table 13 and Figure 14.

Figure 14 must be generated from the per-participant CSV, never hand-built.
This script computes the mean triage time, its standard deviation, the
absolute and relative reduction, the disposition accuracies and the paired
two-sided Wilcoxon signed-rank test from
``triage_study/results/per_participant_times.csv`` and
``triage_study/results/per_participant_accuracy.csv``, and writes both
Table 13 and Figure 14 from those same numbers.
"""
from __future__ import annotations

import argparse
import csv
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from shadowdetectai.triage.analysis import (  # noqa: E402
    reduction, summarise_accuracy, summarise_times, table13_rows, wilcoxon_test)
from shadowdetectai.utils.io import write_csv_dicts, write_json  # noqa: E402
from shadowdetectai.utils.plotting_style import PALETTE, apply_style, save  # noqa: E402


def read_times(path: Path):
    """Group the per-trial times by participant and condition."""
    grouped = defaultdict(lambda: defaultdict(list))
    with open(path, "r", encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            pid = int(row["participant_id"])
            cond = row["condition"]
            grouped[cond][pid].append(float(row["seconds"]))
    return {c: [v[p] for p in sorted(v)] for c, v in grouped.items()}


def read_accuracy(path: Path):
    grouped = defaultdict(lambda: defaultdict(list))
    with open(path, "r", encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            pid = int(row["participant_id"])
            cond = row["condition"]
            grouped[cond][pid].append(float(row["correct"]))
    return {c: [v[p] for p in sorted(v)] for c, v in grouped.items()}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--study", default=str(ROOT / "triage_study"))
    ap.add_argument("--out", default=str(ROOT / "results" / "reproduced"),
                    help="where the regenerated table is written; the paper's "
                         "reported values in results/tables/ are never touched")
    args = ap.parse_args()

    study = Path(args.study)
    times_path = study / "results" / "per_participant_times.csv"
    acc_path = study / "results" / "per_participant_accuracy.csv"
    if not times_path.exists():
        print(f"[FAIL] {times_path} not found. The triage study must be run and its "
              "de-identified per-participant CSVs released before this script can "
              "produce Table 13 and Figure 14.")
        return 1

    times = read_times(times_path)
    acc = read_accuracy(acc_path) if acc_path.exists() else {}

    no_attr = summarise_times(times["no_attribution"])
    with_attr = summarise_times(times["attribution"])
    no_acc = summarise_accuracy(acc.get("no_attribution", [[]] * len(no_attr["per_participant"])))
    with_acc = summarise_accuracy(acc.get("attribution", [[]] * len(with_attr["per_participant"])))
    red = reduction(no_attr, with_attr)
    test = wilcoxon_test(no_attr, with_attr)

    rows = table13_rows(no_attr, with_attr, no_acc, with_acc, red)
    write_csv_dicts(Path(args.out) / "table13_triage_results.csv", rows)
    write_json(Path(args.out) / "table13_triage_results.json", {
        "no_attribution": no_attr, "with_attribution": with_attr,
        "no_attribution_accuracy": no_acc, "with_attribution_accuracy": with_acc,
        "reduction": red, "wilcoxon": test,
    })
    print(f"[ok] Table 13 written: {rows}")

    # Figure 14, generated from the same numbers as the table.
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    apply_style()
    fig, ax = plt.subplots(figsize=(5.0, 3.4))
    labels = ["No attribution\n(aggregate anomaly score only)",
              "With Shapley attribution\n(top-five panel)"]
    means = [no_attr["mean"], with_attr["mean"]]
    sds = [no_attr["sd"], with_attr["sd"]]
    bars = ax.bar(labels, means, yerr=sds, capsize=5,
                  color=[PALETTE["grey"], PALETTE["blue"]], width=0.55)
    for bar, m, s in zip(bars, means, sds):
        ax.text(bar.get_x() + bar.get_width() / 2, m + s + 0.12,
                f"{m:.1f} ± {s:.1f}", ha="center", va="bottom", fontsize=9)
    ax.annotate(f"−{red['difference_minutes']:.1f} min\n(−{red['reduction_percent']:.1f} %)",
                xy=(0.5, max(means)), xytext=(0.5, max(means) + 1.2),
                ha="center", fontsize=9, color=PALETTE["red"])
    ax.set_ylabel("Mean triage time per alert (minutes)")
    ax.set_title("Simulated analyst triage time per alert")
    ax.set_ylim(0, max(means) + max(sds) * 2 + 1.6)
    ax.grid(axis="y", alpha=0.6)
    save(fig, str(Path(args.out).parent / "figures" / "fig14_triage_time.pdf"))
    print(f"[ok] Figure 14 written")
    print(f"[ok] Wilcoxon: W = {test['statistic']}, p = {test['p_value']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
