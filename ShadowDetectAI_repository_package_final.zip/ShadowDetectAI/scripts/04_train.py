#!/usr/bin/env python3
"""Step 4 - train ShadowDetectAI for the ten seeds of Table 6.

    python scripts/04_train.py --config configs/default.yaml
    python scripts/04_train.py --config configs/default.yaml --seeds 42 123
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import torch  # noqa: E402

from shadowdetectai.data.dataset import build_dataloader, collate_channels  # noqa: E402
from shadowdetectai.data.materialize import build_window_frame, channel_slices  # noqa: E402
from shadowdetectai.models.build import make_model  # noqa: E402
from shadowdetectai.training.trainer import TrainConfig, Trainer  # noqa: E402
from shadowdetectai.utils.config import get, load_config  # noqa: E402
from shadowdetectai.utils.seeds import set_seed  # noqa: E402



def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default=str(ROOT / "configs" / "default.yaml"))
    ap.add_argument("--processed", default=str(ROOT / "data" / "processed"))
    ap.add_argument("--seeds", type=int, nargs="*", default=None)
    ap.add_argument("--epochs", type=int, default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    seeds = args.seeds or list(get(cfg, "seeds.list", [42]))
    train_cfg = TrainConfig.from_dict(get(cfg, "training", {}) or {})
    train_cfg.output_dir = str(ROOT / get(cfg, "experiment.output_dir",
                                          "results/raw_runs"))

    dims = cfg["encoder"]["channel_dims"]
    order = list(cfg["encoder"]["channel_order"])
    slices = channel_slices(dims, order)

    print(f"[..] building frames from {args.processed}")
    train_frame = build_window_frame(args.processed, args.config, "train")
    val_frame = build_window_frame(args.processed, args.config, "validation")

    loader_kwargs = {"batch_size": train_cfg.batch_size, "shuffle": True,
                      "num_workers": train_cfg.num_workers}
    train_loader = build_dataloader(train_frame, slices, **loader_kwargs)
    val_loader = build_dataloader(val_frame, slices, **{**loader_kwargs, "shuffle": False})

    model = make_model(cfg)
    print(f"[..] model parameters: {sum(p.numel() for p in model.parameters()):,}")

    for seed in seeds:
        set_seed(seed)
        cfg_seed = TrainConfig.from_dict(get(cfg, "training", {}) or {})
        cfg_seed.seed = seed
        cfg_seed.output_dir = train_cfg.output_dir
        if args.epochs:
            cfg_seed.epochs = args.epochs
        trainer = Trainer(model, cfg_seed)
        summary = trainer.fit(train_loader, val_loader)
        print(f"[ok] seed {seed}: best epoch {summary['best_epoch']}, "
              f"val AUC {summary['best'].get('auc_roc')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
