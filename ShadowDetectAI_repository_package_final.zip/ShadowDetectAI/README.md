# ShadowDetectAI

Reference implementation of

> **Explainable Deep Learning for Insider Threat Profiling Using Log-Derived
> Behavioral Proxies and Temporal Graph Networks**

This repository is a **reproducibility package**: it contains the data
pipeline, the model, the six comparison baselines, the ablations, the
calibration and drift machinery, the analyst-triage study harness, and the
target tables that the code is compared against.

Every hyper-parameter lives in a YAML file. Nothing is hard-coded in Python.
Where the paper does not state a value, the repository says so explicitly
(`[NOT STATED IN PAPER]`) and names the default it uses and why — see
[`docs/reproducibility.md`](docs/reproducibility.md).

---

## Status of this repository

Read this before you draw conclusions from it.  The full evidence — every
command that was run, every result, and the twenty defects that were found
and fixed while assembling this package — is in
[`VERIFICATION.md`](VERIFICATION.md).

| | |
|---|---|
| Code complete | Yes — 66 library modules, 17 scripts, 19 configs, 11 test modules, 4 notebooks |
| Tests executed | **63 pass, 0 fail**; 2 test modules require PyTorch and were **not** executed (see below) |
| Trained on CERT r6.2 | **No** — the corpus was not available in the build environment |
| Numbers in `results/tables/` | The **paper's reported values**, used as comparison targets |
| Numbers in `results/reproduced/` | Written by the pipeline; **empty until you run it** |

> **What was and was not run.**  The build environment for this package had
> NumPy, pandas and matplotlib but **no PyTorch, SciPy, scikit-learn, PyYAML
> or pytest, and no network access to install them**.  The unit tests that
> depend only on NumPy were executed: **63 passed, 0 failed**.  The two
> PyTorch-dependent test modules (`test_baselines.py`, `test_memory_reset.py`)
> and every script that trains a model **could not be executed here** and are
> therefore unverified at runtime.  Every Python file was at least
> syntax-checked, and every shell script was checked with `bash -n`.  Four
> figures were generated from the target tables and inspected.  No number in
> this repository was produced by a run on the corpus — every number is
> either quoted from the paper or marked as unknown.

---

## Quick start

```bash
git clone <this-repository> && cd ShadowDetectAI

python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt          # or: conda env create -f environment.yml

# 1. fetch the CMU CERT r6.2 corpus (you must accept the dataset terms)
python data/download.py --out data/raw

# 2. extract, checksum, preprocess
bash scripts/00_download_cert.sh
python data/extract.py  --src data/raw --out data/extracted
python data/preprocess.py --src data/extracted --out data/processed

# 3. train the model with the paper's ten seeds
python train.py --config configs/default.yaml --seeds all

# 4. evaluate and write results/reproduced/
python test.py --config configs/default.yaml --split test

# 5. regenerate every table and figure, then compare against the paper
python evaluate_all.py
python figures/make_figures.py
python compare_results.py --tolerance 0.02
```

`bash scripts/99_reproduce_all.sh` runs the whole chain end to end.

**Every script writes into `results/reproduced/`.**  The paper's reported
values in `results/tables/` are the comparison targets and are never
overwritten by a run.

---

## Repository layout

```
ShadowDetectAI/
├── train.py                 train the model over the paper's seeds
├── test.py                  evaluate a checkpoint and write results/reproduced/
├── evaluate_all.py          regenerate every table and figure from the outputs
├── compare_results.py       diff results/reproduced/ against results/tables/
├── configs/                 every hyper-parameter lives here
│   ├── default.yaml         the main configuration
│   ├── data.yaml            dataset, windowing, partitioning
│   ├── encoder.yaml         the three proxy channels and the fusion
│   ├── tgnn.yaml            memory, attention, classifier
│   ├── shap.yaml            KernelSHAP
│   ├── calibration.yaml     Platt, PSI, adaptive threshold, fusion
│   ├── ablation/            the seven ablations of Table 11
│   └── baselines/           the six baselines of Table 8
├── src/shadowdetectai/      the library
│   ├── data/                loading → sessionise → window → label → partition → graph
│   ├── features/            Eqs. (11)–(16), the three proxy channels
│   ├── models/              Eqs. (17)–(24), (36)–(37)
│   ├── explain/             Eqs. (25)–(30)
│   ├── calibration/         Eqs. (31)–(35)
│   ├── baselines/           GraphCH, LAN, Double Layer, VGGM, EXAI, Gaspar
│   ├── training/            trainer, checkpoints, seeds
│   ├── evaluation/          Eq. (38), confusion, channel analysis, drift, scalability
│   ├── triage/              alert pool, counterbalanced allocation, analysis
│   └── utils/               seeds, IO, logging, config, plotting style
├── scripts/                 00 … 15, then 99_reproduce_all.sh
├── data/                    download, extract, preprocess, checksums
├── results/
│   ├── tables/              the paper's reported values — the comparison targets
│   ├── reproduced/          written by the pipeline
│   ├── figures/             generated from the result CSVs
│   ├── checkpoints/         one checkpoint per seed
│   └── raw_runs/            the per-seed training logs
├── tests/                   11 test modules + conftest.py
├── notebooks/               four walk-through notebooks
├── triage_study/            the analyst-triage harness
├── docs/                    architecture, data mapping, reproducibility, ethics
├── VERIFICATION.md          what was executed, what was not, and what was fixed
├── Dockerfile, Makefile, environment.yml, requirements.txt, pyproject.toml
└── .github/workflows/ci.yml
```

---

## The two result directories

`results/tables/` and `results/reproduced/` are deliberately separate.

* `results/tables/` holds **the numbers printed in the paper**.  They are
  inputs, never outputs.  Nothing writes to this directory.
* `results/reproduced/` holds what **this code produced**.  It is empty on a
  fresh clone.

`compare_results.py` diffs the two and reports every metric outside a
tolerance (default 0.02, the same order as the standard deviations the paper
itself reports).  This is what makes the package checkable rather than
merely runnable.

A value that the reproduced table does not carry is reported as **MISSING**,
not skipped — so a table whose columns fail to line up with the target
cannot pass by accident.  `tests/test_compare_results.py` locks that
behaviour in.

---

## The model in one paragraph

Each 24-hour window becomes a dynamic interaction graph whose nodes are
users and the resources they touched, and whose edges are the resource
accesses of that window.  Three proxy channels summarise each user's
behaviour from the activity logs alone — inter-record interval statistics
(Eqs. 11–13), device-event entropy and interval statistics (Eq. 14), and a
GRU over resource embeddings with session-position encoding (Eq. 15) — and
are fused into a 128-dimensional embedding (Eq. 16).  A temporal graph
neural network propagates messages through a GRU memory (Eqs. 17–18) under
multi-head temporal attention (Eqs. 19–21) and produces a per-user risk logit
(Eqs. 22–23).  KernelSHAP then attributes that logit to the individual
behavioural features (Eqs. 25–28), and Platt scaling, population-stability
drift and an adaptive threshold turn the score into an analyst-facing alert
with a fused multi-channel severity (Eqs. 31–35).

---

## Results reproduced by this repository

| Paper item | What it is |
|---|---|
| Table 4 | KernelSHAP sensitivity: fidelity, top-3 recall and latency against background and coalition counts |
| Table 5 | dataset partition composition |
| Table 7 | baseline grid search and the selected configuration |
| Table 8 | detection performance of all seven methods, with the paired Wilcoxon test against LAN |
| Table 9 | the confusion matrix at the operating threshold of Eq. (33) |
| Table 10 | per-channel attribution magnitude and inter-channel correlation |
| Table 11 | the seven ablations |
| Table 12 | the triage alert pool and the counterbalanced allocation |
| Table 13 | analyst triage time and disposition accuracy |
| Table 14 | leave-one-insider-out cross-validation over the five malicious identities |
| Figures 7–14 | generated *from* the result CSVs, so a figure cannot drift from its table |

---

## Known issues in the paper

Found while writing the code, listed rather than quietly smoothed over.  The
full list is in [`docs/reproducibility.md` §10](docs/reproducibility.md).

1. **Table 7, Gaspar et al. row** — the printed learning-rate grid is
   `{0.0001, 0.001}` but the selected value `0.0003` is not in it.  The grid
   is extended to include `0.0003` so the reported selection is reachable;
   the reported selection is kept.
2. **Table 5's note vs. Section 6.1** — the note quotes time-based split
   fractions of 72.2 / 11.1 / 16.7 %, which Section 6.1 does not state.
3. **Table 5 user counts** — 3,200 + 690 + 690 = 4,580 node entries against
   4,000 employees; treated as node *occurrences*, not distinct identities.
4. **Eqs. (11)/(12) vs. the surrounding prose** — the equations were already
   inter-record intervals; the prose was aligned to them.

---

## Ethical use

The pipeline reads **no hardware telemetry**: no key press, key release,
pointer-coordinate or click-pressure data is read at any stage, because the
CERT release contains none.  That is enforced by a runtime guard and by a
test that verifies the feature computation is invariant to any such column.
The Shapley layer must not be used as the sole basis for punitive action.
See [`docs/ethics_and_privacy.md`](docs/ethics_and_privacy.md).

---

## Citation

See [`CITATION.cff`](CITATION.cff).  If you use this package, please cite
the paper it implements.

## Licence

Code: MIT (see [`LICENSE`](LICENSE)).  The CMU CERT r6.2 corpus is **not**
redistributed under this licence and remains subject to its own terms; see
[`data/README.md`](data/README.md).

## Paper figures

`figures/paper_figures/fig01.png` to `fig14.png` are the figures exactly as they
appear in the manuscript, numbered by figure.  `figures/make_figures.py`
regenerates the data-driven figures from the tables in `results/tables/`.
