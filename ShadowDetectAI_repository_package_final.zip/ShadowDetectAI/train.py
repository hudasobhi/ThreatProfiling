#!/usr/bin/env python3
"""Top-level training entry point.

Equivalent to ``scripts/04_train.py``; provided because the reproducibility
specification lists ``train.py`` at the repository root.

    python train.py --config configs/default.yaml
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> int:
    cmd = [sys.executable, str(ROOT / "scripts" / "04_train.py")] + sys.argv[1:]
    return subprocess.call(cmd)


if __name__ == "__main__":
    raise SystemExit(main())
