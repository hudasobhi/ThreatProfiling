# Changelog

All notable changes to this package are documented here.  The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-10-25

### Changed

- `triage_study/protocol/decision_rubric.md` and `triage_study/interface/triage_app.py`
  now use the dispositions "Escalate for investigation" and "Dismiss as benign",
  state that the deviation count is not displayed, and describe the
  within-subject counterbalanced design.
- Test, script and module counts in `README.md` and `VERIFICATION.md` corrected.

### Added

- `figures/paper_figures/`: the fourteen manuscript figures.

## [1.0.0] - 2026-10-23

First public release of the reproducibility package.

### Added

- **Data pipeline** — `src/shadowdetectai/data/`: CERT r6.2 loader restricted
  to the five activity logs, sessionisation, 24-hour windowing, weak
  labelling, chronological partitioning (months 1–13 / 14–15 / 16–18),
  leave-one-insider-out folds, dynamic interaction graph construction and
  materialisation.
- **Proxy channels** — `src/shadowdetectai/features/`: keystroke timing
  proxy (Eqs. 11–13), mouse interaction proxy (Eq. 14), application usage
  sequencing (Eq. 15) and the fusion of Eq. (16).
- **Model** — `src/shadowdetectai/models/`: multi-channel encoder, TGN
  message function and GRU memory (Eqs. 17–18), multi-head temporal
  attention (Eqs. 19–21), interpretable risk score (Eqs. 22–23, 29),
  smoothness regulariser (Eq. 24) and the composite loss (Eqs. 36–37).
- **Explainability** — `src/shadowdetectai/explain/`: KernelSHAP (Eqs. 25–26),
  contribution ranking (Eq. 28), attribution fidelity (Eq. 30) and top-k
  contribution recall.
- **Calibration and drift** — `src/shadowdetectai/calibration/`: Platt
  scaling (Eq. 31), population stability index (Eq. 32), adaptive threshold
  (Eq. 33) and role-conditioned multi-channel alert fusion (Eqs. 34–35).
- **Baselines** — `src/shadowdetectai/baselines/`: GraphCH, LAN, Double Layer
  Detection, VGGM, EXAI and Gaspar et al., all implemented from scratch with
  no third-party model code.
- **Training and evaluation** — `src/shadowdetectai/training/` and
  `src/shadowdetectai/evaluation/`: trainer, checkpointing, the ten paper
  seeds, the Eq. (38) metrics with the paired Wilcoxon test, the confusion
  matrix, channel analysis, drift robustness, scalability and the leakage
  checks.
- **Analyst triage** — `src/shadowdetectai/triage/`: the 20-alert pool
  (Table 12), the counterbalanced allocation, and the timing and disposition
  analysis (Table 13), plus the study harness under `triage_study/`.
- **Configuration** — 20 YAML files covering the main run, the data,
  encoder, TGN, SHAP and calibration settings, the seven ablations of
  Table 11 and the six baselines of Table 7.
- **Scripts** — `scripts/00` to `scripts/15` and
  `scripts/99_reproduce_all.sh`, driven by the four root-level entry points
  `train.py`, `test.py`, `evaluate_all.py` and `compare_results.py`.
- **Target tables** — `results/tables/` holds the paper's reported values for
  Tables 4, 5, 7, 8, 9, 10, 11, 12, 13 and 14 and the Wilcoxon test, as the
  inputs to `compare_results.py`.
- **Tests** — 11 test modules covering the equations, the partition
  invariants, the leakage guards, the config integrity, the metrics, the
  calibration, the explanation fidelity, the triage allocation and the
  comparison against the paper's tables.
- **Documentation** — `docs/architecture.md`, `docs/data_and_proxy_mapping.md`,
  `docs/reproducibility.md`, `docs/ethics_and_privacy.md` and
  `docs/paper_to_code_map.md`.
- **Verification report** — `VERIFICATION.md` records every command that was
  executed, the results, the twenty defects found and fixed while
  assembling the package, and what could not be run and why.

### Known limitations

- The package was assembled in an environment without PyTorch, SciPy,
  scikit-learn or PyYAML and without network access.  The NumPy-only unit
  tests pass (63 passed, 0 failed); the two PyTorch-dependent test modules
  and every training script are unverified at runtime here.  See the Status
  table in `README.md`.
- The CMU CERT r6.2 corpus is not redistributed.  `data/checksums.sha256`
  carries an `[UNVERIFIED]` placeholder because no digest is published.
- The analyst-triage study's participant-level measurements and the manual
  behavioural-driver annotations are not redistributed, so Table 13's
  per-participant CSV and the top-3 recall annotations must be supplied by
  the user.
- Table 7's Gaspar et al. learning-rate grid is inconsistent with its own
  reported selection; the grid is extended to include `0.0003` and the
  inconsistency is documented rather than silently resolved.
