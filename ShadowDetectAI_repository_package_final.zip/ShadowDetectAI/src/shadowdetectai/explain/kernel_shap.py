"""KernelSHAP attribution (paper Section 4.3, Eqs. 25-26).

The attribution layer decomposes the logit ``z_{u,t}`` into per-feature
contributions using the Shapley value from cooperative game theory [25],
operationalised through the KernelSHAP algorithm of Lundberg and Lee [26]:

    Eq. (25)   phi_j = sum_{S subset F \ {j}} |S|!(M-|S|-1)!/M! [ v(S u {j}) - v(S) ]

with the weighted linear regression of KernelSHAP used to approximate the sum
over coalitions.

Configuration (Table 6 and Table 4):
  * background distribution : 100 benign training windows, fixed for all
    inference calls
  * coalition samples        : 512 per flagged user
  * player set               : the d = 128 fused behavioural feature dimensions
    plus one aggregated player for the full neighbourhood embedding
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np


@dataclass
class KernelShapConfig:
    """KernelSHAP configuration (Table 4 / Table 6)."""

    n_background: int = 100
    n_coalitions: int = 512
    n_features: int = 128
    include_neighbourhood_player: bool = True
    seed: Optional[int] = None


def _shapley_weights(coalitions: np.ndarray, n_players: int) -> np.ndarray:
    """KernelSHAP's linear-regression weight for each sampled coalition.

    For a coalition ``S`` of size ``k`` among ``n`` players the weight is

    .. math:: w(S) = \\frac{n-1}{\\binom{n}{k}\\, k\\, (n-k)}

    which is the probability of drawing that coalition under the Shapley
    kernel.  The size ``k`` is read from the coalition itself, not sampled
    independently of it.
    """
    n_samples = coalitions.shape[0]
    sizes = coalitions.sum(axis=1).astype(np.int64)
    weights = np.zeros(n_samples, dtype=np.float64)
    for k in range(n_players + 1):
        mask = sizes == k
        if not np.any(mask):
            continue
        if k == 0 or k == n_players:
            # The empty and the full coalition each have weight 1/(n+1).
            weights[mask] = 1.0 / (n_players + 1)
            continue
        comb = _factorial(n_players) / (_factorial(k) * _factorial(n_players - k))
        weights[mask] = (n_players - 1) / (comb * k * (n_players - k))
    return weights


def _factorial(n: int) -> float:
    out = 1.0
    for i in range(2, n + 1):
        out *= i
    return out


def coalition_matrix(n_features: int, n_samples: int,
                     seed: Optional[int] = None) -> np.ndarray:
    """Sample the coalition matrix ``Z`` of shape ``(n_samples, n_features)``."""
    rng = np.random.default_rng(seed)
    return rng.integers(0, 2, size=(n_samples, n_features)).astype(np.float64)


def kernel_shap(values: np.ndarray,
                coalitions: np.ndarray,
                feature_mask: Optional[np.ndarray] = None,
                return_baseline: bool = False):
    """Weighted linear regression of KernelSHAP.

    The model fitted is

    .. math:: v(z) \\approx \\phi_0 + \\sum_{i=1}^{d} \\phi_i z_i

    where ``v`` is the value function evaluated on each sampled coalition,
    ``z`` is the coalition's binary mask and the regression is weighted by
    the Shapley kernel.  The intercept ``phi_0`` is the model's output on the
    background distribution; the feature contributions satisfy
    ``sum(phi) + phi_0 = v(all features present)`` in the exact case.

    Parameters
    ----------
    values:
        Model output for each sampled coalition, shape ``(n_samples,)``.
    coalitions:
        Binary coalition matrix, shape ``(n_samples, n_features)``.
    feature_mask:
        Optional matrix marking which features are switched on per row, used
        when a background distribution is substituted per row.
    return_baseline:
        When true, return ``(contributions, baseline)`` instead of just the
        contributions.

    Returns
    -------
    numpy.ndarray
        The Shapley value of each feature, shape ``(n_features,)``.  When
        ``return_baseline`` is true a tuple of ``(contributions, baseline)``
        is returned instead.
    """
    n_samples, n_features = coalitions.shape
    if values.shape[0] != n_samples:
        raise ValueError("values and coalitions must have the same number of rows")
    z = coalitions if feature_mask is None else (feature_mask * coalitions)
    w = _shapley_weights(z, n_features)
    total = w.sum()
    if total <= 0:
        w = np.ones(n_samples, dtype=np.float64)
        total = float(n_samples)
    w = w / total

    # Weighted least squares with an intercept, so the background value is
    # not forced into the feature coefficients.
    design = np.column_stack([np.ones(n_samples), z])
    sw = np.sqrt(w)[:, None]
    try:
        beta = np.linalg.lstsq(design * sw, values * sw[:, 0], rcond=None)[0]
    except np.linalg.LinAlgError:
        beta = np.zeros(n_features + 1, dtype=np.float64)
    contributions = beta[1:]
    if return_baseline:
        return contributions, float(beta[0])
    return contributions


class KernelShapExplainer:
    """Explainer used by the attribution layer.

    Parameters
    ----------
    value_function:
        Callable mapping a feature matrix ``(n_players, d)`` to model outputs.
    config:
        :class:`KernelShapConfig`.
    """

    def __init__(self, value_function: Callable[[np.ndarray], np.ndarray],
                 config: Optional[KernelShapConfig] = None):
        self.value_function = value_function
        self.config = config or KernelShapConfig()
        self._background: Optional[np.ndarray] = None
        self._coalitions: Optional[np.ndarray] = None

    def set_background(self, background: np.ndarray) -> None:
        """Fix the background distribution of benign training windows."""
        if background.shape[0] < self.config.n_background:
            raise ValueError(
                f"background has {background.shape[0]} rows, need "
                f"{self.config.n_background}")
        self._background = background[: self.config.n_background]

    def set_coalitions(self, coalitions: np.ndarray) -> None:
        """Fix the sampled coalition space (so all users share it)."""
        self._coalitions = coalitions

    def explain(self, instance: np.ndarray,
                return_baseline: bool = False):
        """Compute the Shapley values for one instance.

        Parameters
        ----------
        instance:
            The feature vector of the flagged user, shape ``(d,)``.
        return_baseline:
            When true, return ``(contributions, baseline)`` instead of just
            the contributions.  The baseline is the model's output on the
            background distribution, so that

            .. math:: \\phi_0 + \\sum_i \\phi_i = f(x)

            holds for the flagged instance - which is what Eq. (30)'s
            fidelity compares against the model's logit.

        Returns
        -------
        numpy.ndarray
            Per-feature contributions, shape ``(d,)``.  With
            ``return_baseline`` a tuple of ``(contributions, baseline)``.
        """
        d = instance.shape[0]
        if self._background is None:
            raise RuntimeError("set_background must be called before explain")
        if self._coalitions is None:
            self._coalitions = coalition_matrix(
                d, self.config.n_coalitions, self.config.seed)
        coalitions = self._coalitions
        n_samples = coalitions.shape[0]

        # Each coalition row is evaluated with the absent features replaced by
        # the mean of the background distribution.
        bg_mean = self._background.mean(axis=0)
        masked = np.tile(instance, (n_samples, 1))
        absent = coalitions == 0
        masked[absent] = np.tile(bg_mean, (n_samples, 1))[absent]
        values = np.asarray(self.value_function(masked), dtype=np.float64).reshape(-1)
        return kernel_shap(values, coalitions, return_baseline=return_baseline)

    @property
    def background_mean(self) -> np.ndarray:
        """The per-feature mean of the background distribution."""
        if self._background is None:
            raise RuntimeError("set_background must be called first")
        return self._background.mean(axis=0)

    def baseline_value(self) -> float:
        """The model's output on the background distribution.

        This is the value of the ``phi_0`` term of the KernelSHAP
        decomposition: the part of the score that the features do not
        explain.
        """
        if self._background is None:
            raise RuntimeError("set_background must be called first")
        bg_mean = self._background.mean(axis=0).reshape(1, -1)
        return float(np.asarray(self.value_function(bg_mean)).reshape(-1)[0])
