"""GraphCH [5] baseline: cyber-human graph neural network.

Roy and Chen, "GraphCH: a deep framework for assessing cyber human aspects in
insider threat detection", IEEE TDSC 21(5) (2024) 4495-4509.  GraphCH
combines host activity logs with psychological survey data.  In this
repository the survey input is unavailable, so it is replaced by the
log-derived behavioural proxy features, exactly as the paper describes in
Section 4.6.

Table 7 grid: learning rate in {0.0001, 0.0003, 0.001}, layers in {2, 3},
hidden dimension in {64, 128, 256}.  Selected configuration: LR = 0.0003,
Layers = 2, Dim = 128.
"""
from __future__ import annotations

from typing import Dict, Optional

import torch
from torch import nn
from torch.nn import functional as F


class GraphCH(nn.Module):
    """Relational GNN over the user-resource graph with a human-factor head.

    The cyber-human aspect is modelled by a joint embedding of the graph
    representation and the behavioural proxy features, which stands in for the
    psychological survey vector of the original method.
    """

    def __init__(self, feature_dim: int, hidden_dim: int = 128, num_layers: int = 2):
        super().__init__()
        self.feature_dim = int(feature_dim)
        self.hidden_dim = int(hidden_dim)
        self.num_layers = int(num_layers)

        self.embed = nn.Linear(feature_dim, hidden_dim)
        self.graph_layers = nn.ModuleList([
            nn.Linear(hidden_dim, hidden_dim) for _ in range(num_layers)])
        self.human_head = nn.Sequential(
            nn.Linear(hidden_dim + feature_dim, hidden_dim), nn.ReLU())
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, 1))

    def _pool(self, x: torch.Tensor, mask: Optional[torch.Tensor]) -> torch.Tensor:
        """Mean-pool the neighbourhood, honouring an optional validity mask."""
        if mask is None:
            return x.mean(dim=1)
        denom = mask.sum(dim=1, keepdim=True).clamp(min=1).unsqueeze(-1)
        return (x * mask.unsqueeze(-1)).sum(dim=1) / denom

    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        node_feat = batch["node_features"]              # (B, F)
        neighbour_feat = batch.get("neighbour_features")  # (B, N, F)
        mask = batch.get("neighbour_mask")

        h = F.relu(self.embed(node_feat))
        if neighbour_feat is not None and neighbour_feat.shape[1] > 0:
            nb = F.relu(self.embed(neighbour_feat))
            agg = self._pool(nb, mask)
            for layer in self.graph_layers:
                h = F.relu(layer(h + agg))
        else:
            for layer in self.graph_layers:
                h = F.relu(layer(h))

        joint = torch.cat([h, node_feat], dim=-1)
        out = self.classifier(self.human_head(joint)).squeeze(-1)
        return {"logit": out, "probability": torch.sigmoid(out)}
