# Verification report

What was actually executed when this package was assembled, and what was not.
Everything below is reproducible from the repository.

## Environment

| | |
|---|---|
| Python | 3.11 |
| Available | numpy 2.4.6, pandas 3.0.2, matplotlib 3.10.9 |
| **Not available** | torch, scipy, sklearn, yaml, pytest, requests |
| Network | none — `pip` could not install anything (`No matching distribution found`) |
| GPU | none |
| CERT r6.2 corpus | **not present** — the KiltHub record requires manual acceptance of the dataset terms |

## What was executed

| Check | Command | Result |
|---|---|---|
| Syntax of every Python file | `ast.parse` over all 102 `.py` files | **102/102 parse** |
| Shell script syntax | `bash -n` over all `.sh` files | **all parse** |
| Config parsing | `yaml.safe_load` over all 19 configs | **19/19 load** |
| CSV parsing | `csv.DictReader` over 17 result/study CSVs | **17/17 parse** |
| Unit tests | the 9 torch-free test modules (11 test modules in total, 2 of which need PyTorch) | **63 passed, 0 failed** |
| Import of every torch-free module | `importlib` over 59 modules | **59/59 import** |
| Comparison machinery | `compare_results.py` against a simulated reproduction | **274 values compared, 0 deviations, 0 missing** |
| Missing-value detection | same, with one column dropped | **3 values correctly reported MISSING** |
| Figure generation | `figures/make_figures.py` | **4 figures rendered and visually inspected** |

The two PyTorch-dependent test modules (`test_baselines.py`,
`test_memory_reset.py`) were **not** executed, because PyTorch is not
installed and could not be installed.  They are reported as skipped, not as
passing.

## What was not executed

* **No model was trained.**  The corpus is not present, and PyTorch is not
  installed.
* **No script under `scripts/` was run against real data.**  `05`–`15` are
  wired and syntax-checked but unexecuted.
* **Figures 7, 9, 10 and 11 were not rendered**, because they need the
  evaluated scores, the drift curve, the alert volumes and the scalability
  timings, all of which need a trained model.  The script reports them as
  skipped rather than emitting a placeholder.
* **The triage interface was not exercised in a browser session.**  The
  allocation, the schedule and the alert pool were generated and verified
  programmatically.

## Consequence for the numbers

**No number in this repository was produced by a run on the corpus.**  Every
numeric value in `results/tables/` is quoted from the paper.  Every numeric
value in `results/reproduced/` is absent, because the pipeline has not been
run.  Where the paper does not state a value, the repository says
`[NOT STATED IN PAPER]` and names the default it uses and the reason — see
[`docs/reproducibility.md`](docs/reproducibility.md).

## Defects found and fixed while assembling this package

Recorded because they are the kind of thing that silently produces wrong
numbers rather than errors.

| # | Where | Defect | Fix |
|---|---|---|---|
| 1 | `features/keystroke_timing_proxy.py`, `features/mouse_interaction_proxy.py` | `astype("int64")` on a datetime column returns **microseconds** under pandas 3, so every interval was 1000× too small | force `datetime64[ns]` explicitly |
| 2 | `features/keystroke_timing_proxy.py` | Eq. (11) returned `T_u − 2` dwell values instead of `T_u − 1` | `np.diff(t)` |
| 3 | `explain/kernel_shap.py` | the Shapley regression **weights were computed and then discarded** — the fit was an unweighted least squares | weighted least squares with the Shapley kernel |
| 4 | `explain/kernel_shap.py` | the weights were derived from a *randomly sampled* subset size rather than the coalition's own size | read the size from the coalition |
| 5 | `explain/kernel_shap.py` | the regression had **no intercept**, so the background value was forced into the feature coefficients | add the intercept; `explain()` now returns the baseline |
| 6 | `explain/fidelity.py` | Eq. (30) compared `Σφ` against the logit, but `Σφ` excludes the baseline | `fidelity(Σφ, z, φ_0)` |
| 7 | `scripts/08_shap_sensitivity.py` | the fidelity expression was `1 − \|Σφ\|/\|Σφ\|`, which is **always 0** | compute Eq. (30) against the model's own logit |
| 8 | `scripts/08_shap_sensitivity.py` | the KernelSHAP value function returned **zeros** instead of the model's predictions | use the trained model |
| 9 | `scripts/08_shap_sensitivity.py` | it read `data/processed/fused_features.npz`, a file **nothing creates** | build the instances and the background from the materialised frames |
| 10 | `compare_results.py` | a value the reproduced table did not carry was **skipped silently**, so a mismatched table passed as a reproduction | report it as **MISSING**; `tests/test_compare_results.py` locks this in |
| 11 | `scripts/05`–`15` | they wrote into `results/tables/`, **overwriting the paper's target values** on a run | every script now defaults to `results/reproduced/` |
| 12 | `scripts/05`–`11` | the tables were written in a long format that the target tables do not use, so the comparison would have compared nothing | all tables are now written in the paper's own layout |
| 13 | `scripts/05`, `scripts/10` | the operating threshold was a hard-coded `0.5` | the threshold of Eq. (33), fitted on the validation partition |
| 14 | `scripts/14` | wrote no Table 12 | it now writes it, and self-checks the counterbalancing |
| 15 | `triage/allocation.py` | the condition assignment was sampled per participant, so an alert could appear in the attribution condition zero or ten times | a balanced cyclic rotation: each alert appears in each condition exactly five times |
| 16 | `data/materialize.py` | an unbalanced parenthesis (a syntax error) | fixed; caught by the full-tree syntax sweep |
| 17 | `data/materialize.py` | the new `partition` tag would have been read as a numeric feature column | the feature columns are selected by dtype |
| 18 | `scripts/14` | the alert CSVs it reads were **never written by anything** | `scripts/05` now writes them |
| 19 | `data/preprocess.py` | the partition tag was missing from the feature tables | added, so the training-partition analyses can select their rows |
| 20 | `scripts/12` | it read the checkpoint from `results/checkpoints/` while the trainer writes to `results/raw_runs/` | the path is corrected and its existence is reported |

## How to verify this package yourself

```bash
pip install -r requirements.txt
python -m pytest tests -q                       # the full suite
python -m compileall -q src scripts tests *.py  # every file parses
bash scripts/99_reproduce_all.sh --skip-download # the full pipeline
python compare_results.py --tolerance 0.02      # the comparison
```

On a machine with the corpus and a GPU, the last two commands are the real
test of this package: they replace the paper's reported numbers with the
numbers this code produces, and report the difference.
